#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/readme-benchmark-refresh-2026-11-07"
repo="$root/work/deepj-qwen-thinking"
python="$root/outputs/cpu-throughput/reference-env/bin/python"
export JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
export VECLIB_MAXIMUM_THREADS=10
export PYTORCH_ENABLE_MPS_FALLBACK=0
export TOKENIZERS_PARALLELISM=false
export PYTHONPATH="$repo/src/test/python"
fixture="$root/outputs/gemma-video-gap-2026-11-07/tiny-gemma"
guard="$out/cpu-retry"
cd "$guard"
/bin/ps -axo pid,rss,comm | /usr/bin/sort -nrk2 | /usr/bin/head -12 > preflight-processes.txt || true
/usr/bin/memory_pressure -Q > preflight-memory.txt
run_prefill() {
 local engine="$1";local pair="$2"
 if [[ "$engine" == deepj ]]; then
  cmd=("$JAVA_HOME/bin/java" -Xmx8g --enable-native-access=ALL-UNNAMED -cp "$out/candidate.jar:$repo/target/test-classes" io.github.kirstenali.deepj.nn.transformer.qwen3.Qwen3Benchmark /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B cpu FLOAT32 "$out/prefill-input.json" 10 8 5)
 else cmd=("$python" -B "$out/matched_reference.py" /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B cpu "$out/prefill-input.json"); fi
 "$python" run_guarded.py --stop-file "$guard/STOP" --log "$guard/prefill-$engine-$pair.jsonl" --timeout 60 --rss-gib 11 --swap-mib 64 -- "${cmd[@]}"
 sleep 3
}
for pair in 1 2; do
 if (( pair % 2 )); then order=(deepj pytorch); else order=(pytorch deepj); fi
 for engine in "${order[@]}"; do run_prefill "$engine" "$pair"; done
done
echo MATCHED_REFRESH_COMPLETE
