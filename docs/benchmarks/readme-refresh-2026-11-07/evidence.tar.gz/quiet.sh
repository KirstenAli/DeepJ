#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/readme-benchmark-refresh-2026-11-07"
for attempt in {1..120}; do
 if ! /bin/ps -axo comm | /usr/bin/awk '/IntelliJ IDEA.app/{found=1} END{exit !found}'; then break; fi
 sleep 1
done
if /bin/ps -axo comm | /usr/bin/awk '/IntelliJ IDEA.app/{found=1} END{exit !found}'; then exit 3; fi
/bin/ps -axo pid,user,pcpu,comm | /usr/bin/awk '$2=="kirstenali" && $4 ~ /\/(mediaanalysisd|spotlightknowledged|mdworker_shared)$/' > "$out/paused-jobs.txt"
paused_jobs=($(/usr/bin/awk '{print $1}' "$out/paused-jobs.txt"))
resume_jobs() {
 for pid in "${paused_jobs[@]}"; do /bin/kill -CONT "$pid" 2>/dev/null || true; done
 /bin/ps -axo pid,state,pcpu,comm | /usr/bin/awk '$4 ~ /\/(mediaanalysisd|spotlightknowledged|mdworker_shared)$/' > "$out/resumed-state.txt"
 echo BACKGROUND_JOBS_RESUMED
 if [[ -n "${watchdog_pid:-}" ]]; then /bin/kill -TERM "$watchdog_pid" 2>/dev/null || true; fi
}
trap resume_jobs EXIT
trap 'exit 130' INT TERM HUP
if (( ${#paused_jobs[@]} )); then
 # Independent, bounded fallback also resumes jobs if this launcher is killed.
 nohup "$root/outputs/cpu-throughput/reference-env/bin/python" -B "$out/resume_watchdog.py" \
  "${paused_jobs[@]}" > "$out/resume-watchdog.log" 2>&1 < /dev/null &
 watchdog_pid=$!
 echo "AUTO_RESUME_WATCHDOG $watchdog_pid"
 for pid in "${paused_jobs[@]}"; do /bin/kill -STOP "$pid" 2>/dev/null || true; done
fi
/bin/ps -axo pid,state,pcpu,comm | /usr/bin/awk '$4 ~ /\/(mediaanalysisd|spotlightknowledged|mdworker_shared)$/' > "$out/paused-state.txt"
echo BACKGROUND_JOBS_PAUSED
sleep 5
bash "${1:-$out/matched-full.sh}"
echo QUIET_MATCHED_COMPLETE
