import io.github.kirstenali.deepj.autograd.GradMode;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;
import java.util.*;

public final class CachedAttentionProbe {
    public static void main(String[] args) {
        var backend = new MetalBackend();
        Tensor.setBackend(backend);
        try (var ignored = GradMode.noGrad()) {
            for (var dtype : new DType[]{DType.FLOAT16, DType.BFLOAT16}) {
                for (int length : new int[]{1, 65, 129, 512}) {
                    for (int width : new int[]{32, 128}) { compare(backend, dtype, length, width); }
                }
            }
        } finally { backend.releaseResources(); }
    }

    private static void compare(MetalBackend backend, DType dtype, int length, int width) {
        Tensor q = Tensor.random(dtype, new Random(1), 16, width).retainDeviceBuffer();
        Tensor k = Tensor.random(dtype, new Random(2), 8 * (length + 16), width).retainDeviceBuffer();
        Tensor v = Tensor.random(dtype, new Random(3), k.matrixRows(), width).retainDeviceBuffer();
        q.toFloatArray(); k.toFloatArray(); v.toFloatArray();
        double[] old = new double[21], fused = new double[21];
        for (int i = -10; i < old.length; i++) {
            double first = time(backend, q, k, v, length, i % 2 == 0);
            double second = time(backend, q, k, v, length, i % 2 != 0);
            if (i >= 0) { old[i] = i % 2 == 0 ? second : first; fused[i] = i % 2 == 0 ? first : second; }
        }
        Arrays.sort(old); Arrays.sort(fused);
        System.out.printf(Locale.ROOT, "%s length=%d width=%d old_us=%.3f fused_us=%.3f%n",
                dtype, length, width, old[10], fused[10]);
        q.releaseDeviceBufferRetention(); k.releaseDeviceBufferRetention(); v.releaseDeviceBufferRetention();
    }

    private static double time(MetalBackend backend, Tensor q, Tensor k, Tensor v, int length, boolean fused) {
        long start = System.nanoTime();
        Tensor output = null;
        for (int call = 0; call < 20; call++) {
        if (fused) output = backend.cachedAttention(q, k, v, 8, length, .125f);
        else {
            Tensor scores = backend.headPrefixMatmul(q, k, 8, length, true);
            output = backend.headPrefixMatmul(backend.softmaxRows(scores.multiplyScalar(.125f)), v, 8, length, false);
        }
        }
        output.toFloatArray();
        double micros = (System.nanoTime() - start) / 20000.0;
        backend.releaseTemporaryResources();
        return micros;
    }
}
