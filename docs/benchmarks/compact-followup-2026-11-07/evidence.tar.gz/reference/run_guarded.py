"""Bound a benchmark process without changing any model or training process."""
import argparse
import json
import os
from pathlib import Path
import re
import resource
import sys
import signal
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--log', type=Path, required=True)
parser.add_argument('--timeout', type=float, default=180)
parser.add_argument('--rss-gib', type=float, default=11)
parser.add_argument('--swap-mib', type=float, default=512)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[0] == '--' else args.command

def swap_used():
    output = subprocess.check_output(['/usr/bin/vm_stat'], text=True)
    page_size = int(re.search(r'page size of (\d+) bytes', output)[1])
    pages = int(re.search(r'Swapouts:\s*(\d+)', output)[1])
    return pages * page_size / (1024 * 1024)

start = time.monotonic()
swap_before = swap_used()
peak_rss = 0
reason = None
with args.log.open('w') as output:
    child = subprocess.Popen(command, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    while child.poll() is None:
        time.sleep(1)
        try:
            result = subprocess.run(['/bin/ps', '-o', 'rss=', '-p', str(child.pid)], text=True, capture_output=True)
            rss = int(result.stdout.strip() or 0)
        except PermissionError:
            rss = 0
        peak_rss = max(peak_rss, rss)
        elapsed = time.monotonic() - start
        if rss > args.rss_gib * 1024 * 1024:
            reason = 'RSS limit'
        elif swap_used() - swap_before > args.swap_mib:
            reason = 'swap growth limit'
        elif elapsed > args.timeout:
            reason = 'time limit'
        if reason:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
            break
    status = child.wait()
peak_rss = max(peak_rss, resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss / (1024 if sys.platform == "darwin" else 1))
summary = dict(returncode=status, elapsed_seconds=time.monotonic()-start, peak_rss_kib=peak_rss,
               swap_out_before_mib=swap_before, swap_out_after_mib=swap_used(), stopped_for=reason)
args.log.with_suffix('.metrics.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary), flush=True)
raise SystemExit(0 if status == 0 else 1)
