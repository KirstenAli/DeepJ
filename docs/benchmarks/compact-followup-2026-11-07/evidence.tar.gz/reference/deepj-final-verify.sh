#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
export JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
export VECLIB_MAXIMUM_THREADS=10
cd "$root/work/deepj-qwen-thinking"
/opt/homebrew/bin/mvn -o -Pfull-coverage -Ddeepj.qwen3.requireMetal=true -Dsana.test.metal=true -Dsanavideo.test.metal=true -Dgemma.test.metal=true verify > "$root/outputs/compact-followup/final-verify.log" 2>&1
echo FINAL_FULL_VERIFY_PASSED
/opt/homebrew/bin/mvn -o surefire:test -Djacoco.skip=true -Ddeepj.cpu.javaOnly=true -Dtest=CpuHalfMatrixTest,CpuCompactNormalizationTest,CpuCompactPointwiseTest,CpuCompactSoftmaxTest,CpuCompactRotaryTest,TensorValuesCopyTest > "$root/outputs/compact-followup/final-fallback-tests.log" 2>&1
echo FINAL_JAVA_ONLY_CHECKS_PASSED
