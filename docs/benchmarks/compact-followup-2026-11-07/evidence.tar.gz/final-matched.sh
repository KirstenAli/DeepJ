#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/compact-followup"
old="$root/outputs/compact-performance"
python="$root/outputs/cpu-throughput/reference-env/bin/python"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
export VECLIB_MAXIMUM_THREADS=10
export PYTHONPATH="$root/work/deepj-qwen-thinking/src/test/python"
export PYTORCH_ENABLE_MPS_FALLBACK=0
for attempt in {1..120}; do
 if ! /bin/ps -axo comm | /usr/bin/awk '/IntelliJ IDEA.app/{found=1} END{exit !found}'; then break; fi
 sleep 1
done
if /bin/ps -axo comm | /usr/bin/awk '/IntelliJ IDEA.app/{found=1} END{exit !found}'; then exit 3; fi
sleep 3
"$python" "$root/outputs/cpu-throughput/run_guarded.py" --log "$out/final-attention-micro.log" \
 --timeout 60 --rss-gib 2 --swap-mib 128 -- "$java" -Xmx512m --enable-native-access=ALL-UNNAMED \
 -cp "$out/classes:$out/final-candidate.jar" CachedAttentionProbe
for backend in cpu metal; do
 for dtype in FLOAT16 BFLOAT16; do
  device="$backend"; if [[ "$backend" == metal ]]; then device=mps; fi
  for engine in deepj pytorch; do
   if [[ "$engine" == deepj ]]; then
    command=("$java" -Xmx6g --enable-native-access=ALL-UNNAMED -Dprobe.compact=true
     "-Dprobe.logits=$out/final-$backend-$dtype-$engine.bin" -cp "$old/classes:$out/final-candidate.jar"
     io.github.kirstenali.deepj.nn.transformer.qwen3.FullPrecisionProbe
     /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B "$backend" "$dtype"
     "$root/outputs/qwen3-1p7b/benchmark-input.json" 10 5 5)
   else
    command=("$python" -B "$old/full_reference.py" /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B "$device"
     "$root/outputs/qwen3-1p7b/benchmark-input.json" "$dtype" "$out/final-$backend-$dtype-$engine.bin")
   fi
   "$python" "$root/outputs/cpu-throughput/run_guarded.py" --log "$out/final-$backend-$dtype-$engine.jsonl" \
    --timeout 90 --rss-gib 9 --swap-mib 128 -- "${command[@]}"
   echo "MATCHED_FULL_COMPLETE $backend $dtype $engine"
  done
 done
done
echo MATCHED_FULL_FINISHED
for backend in cpu metal; do
 for model in qwen loop prism; do
  for variant in baseline candidate; do
   jar="$old/release.jar"
   if [[ "$variant" == candidate ]]; then jar="$out/native-half-candidate.jar"; fi
   "$python" "$root/outputs/cpu-throughput/run_guarded.py" --log "$out/final-control-$backend-$model-$variant.json" \
    --timeout 60 --rss-gib 3 --swap-mib 128 -- "$java" --enable-native-access=ALL-UNNAMED -Xmx1g \
    -Xbatch -XX:CompileThresholdScaling=0.1 -Dprobe.warmups=100 -Dprobe.samples=30 \
    -cp "$root/outputs/qwen-inference-optimizations:$jar" QuickProbe "$backend" "$model" training
  done
  echo "FINAL_FP32_CONTROL_COMPLETE $backend $model"
 done
done
