#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/gemma-cpu-followup-2026-11-07"
python="$root/outputs/cpu-throughput/reference-env/bin/python"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
fixture="$root/outputs/gemma-video-gap-2026-11-07/tiny-gemma"
export JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
cd "$out"
run_java() {
 local label="$1"; local jar="$2"
 "$python" run_guarded.py --log "$out/$label.jsonl" --timeout 40 --rss-gib 3 --swap-mib 128 -- "$java" -Xmx1g --enable-native-access=ALL-UNNAMED -cp "classes:$jar" GemmaTrainingProbe cpu "$fixture" "$out/$label.safetensors"
}
run_torch() {
 local label="$1"
 "$python" run_guarded.py --log "$out/$label.jsonl" --timeout 40 --rss-gib 3 --swap-mib 128 -- "$python" -B gemma_training.py "$fixture" cpu "$out/$label.safetensors"
}
run_java cpu-baseline-final-1 baseline.jar
run_java cpu-candidate-final-1 candidate.jar
run_torch cpu-torch-final-1
run_torch cpu-torch-final-2
run_java cpu-candidate-final-2 candidate.jar
run_java cpu-baseline-final-2 baseline.jar
for backend in cpu metal; do
 for model in qwen loop prism; do
  for version in baseline candidate; do
   "$java" -Xmx1g -Dprobe.threads=1 -Ddeepj.probe.warmups=5 -Ddeepj.probe.runs=5 --enable-native-access=ALL-UNNAMED -cp "classes:$version.jar" TinyTrainingProbe "$backend" "$model" > "control-$backend-$model-$version.jsonl" 2>&1
  done
 done
done
cd "$root/work/deepj-qwen-thinking"
/opt/homebrew/bin/mvn -o verify -Pcli -Dgemma.test.metal=true > "$out/verify.log" 2>&1
