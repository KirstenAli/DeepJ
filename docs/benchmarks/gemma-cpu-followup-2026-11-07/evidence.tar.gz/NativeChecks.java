package io.github.kirstenali.deepj.tensor;
import java.util.*;
public class NativeChecks {
 public static void main(String[] args) {
  Random random=new Random(120);int count=65539,mismatches=0;float max=0;
  for(float decay:new float[]{0,.01f}) {
   float[] w=new float[count],g=new float[count],m=new float[count],v=new float[count];
   for(int i=0;i<count;i++){w[i]=random.nextFloat()-.5f;g[i]=(random.nextFloat()-.5f)*3;m[i]=random.nextFloat()*.01f;v[i]=random.nextFloat()*.01f;}
   float[] ew=w.clone(),em=m.clone(),ev=v.clone();float lr=.0001f,b1=.9f,b2=.999f,bc1=.91f,bc2=.003f,eps=1e-8f;
   for(int step=0;step<10;step++) {
    for(int i=0;i<count;i++) {
     float first=b1*em[i]+(1-b1)*g[i],second=b2*ev[i]+(1-b2)*(g[i]*g[i]);em[i]=first;ev[i]=second;
     float update=(lr*(first/bc1))/((float)Math.sqrt(second/bc2)+eps);if(decay!=0)update+=lr*decay*ew[i];ew[i]-=update;
    }
    if(!CpuBlas.adamW(w,0,g,0,m,0,v,0,count,lr,b1,b2,eps,decay,bc1,bc2))throw new AssertionError();
   }
   for(int i=0;i<count;i++) {
    if(Float.floatToIntBits(w[i])!=Float.floatToIntBits(ew[i])||Float.floatToIntBits(m[i])!=Float.floatToIntBits(em[i])||Float.floatToIntBits(v[i])!=Float.floatToIntBits(ev[i])){mismatches++;max=Math.max(max,Math.abs(w[i]-ew[i]));}
   }
  }
  System.out.println("ADAM_MISMATCHES "+mismatches+" MAX "+max);
  float[] values=new float[1_247_488];double reference=0;float serial=0;
  for(int i=0;i<values.length;i++){values[i]=(random.nextFloat()-.5f)*.0001f;reference+=(double)values[i]*values[i];serial+=values[i]*values[i];}
  float result=CpuBlas.sumSquares(values,0);System.out.println("NORM reference "+reference+" scalar "+serial+" native "+result+" relerror "+Math.abs(result-reference)/reference);
 }
}
