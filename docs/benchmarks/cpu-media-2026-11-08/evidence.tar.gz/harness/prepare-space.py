from pathlib import Path
import gzip,hashlib,json,shutil
root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
manifest=[]
def digest(path,opener=open):
 h=hashlib.sha256()
 with opener(path,'rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
for folder in ['compact-followup','compact-performance']:
 for p in (root/'outputs'/folder).glob('*.bin'):
  target=p.with_suffix('.bin.gz')
  if target.exists():continue
  before=digest(p)
  with p.open('rb') as source,gzip.open(target,'wb',compresslevel=1) as destination:shutil.copyfileobj(source,destination)
  assert digest(target,gzip.open)==before,str(p)
  manifest.append({'source':str(p),'compressed':str(target),'sha256':before,'bytes':p.stat().st_size})
  (out/'archived-generated-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
  p.unlink()
for p in (root/'outputs').rglob('*.jar'):
 if p.name not in {'candidate.jar','baseline.jar','final.jar','fixed.jar','before.jar','after.jar','control.jar'}:continue
 if any(v in p.parts for v in ['assets','previous-assets','model','models','reference-env']):continue
 manifest.append({'rebuildable_jar':str(p),'sha256':digest(p),'bytes':p.stat().st_size})
 p.unlink()
for p in [root/'work/deepj-qwen-thinking/target/reports',root/'work/deepj-qwen-thinking/target/surefire-reports',root/'work/qwen3-implementation/target']:
 if p.exists():shutil.rmtree(p)
(out/'archived-generated-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Archived',sum('compressed' in row for row in manifest),'old binary traces losslessly; removed',sum('rebuildable_jar' in row for row in manifest),'rebuildable candidate JARs.')
print('Free MiB:',shutil.disk_usage(root).free//1048576)
