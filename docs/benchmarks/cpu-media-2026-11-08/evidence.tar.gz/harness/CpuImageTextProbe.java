import io.github.kirstenali.deepj.concurrent.DeepJExecutor;
import io.github.kirstenali.deepj.autograd.GradMode;
import io.github.kirstenali.deepj.nn.diffusion.sana.SanaSprint;
import io.github.kirstenali.deepj.tensor.Tensor;
import io.github.kirstenali.deepj.tensor.cpu.CpuBackend;
import java.nio.*;
import java.nio.file.*;
public final class CpuImageTextProbe {
 public static void main(String[] args) throws Exception {
  Tensor.setBackend(new CpuBackend()); DeepJExecutor.setNumThreads(10);
  try(var ignored=GradMode.noGrad()) {
   var m=SanaSprint.class.getDeclaredMethod("encode",String.class);m.setAccessible(true);
   Object features=m.invoke(new SanaSprint(Path.of(args[0])),"A red fox in a snowy forest, soft morning light, detailed wildlife photograph");
   var values=features.getClass().getDeclaredMethod("values");values.setAccessible(true);
   float[] data=(float[])values.invoke(features);
   ByteBuffer bytes=ByteBuffer.allocate(data.length*4).order(ByteOrder.LITTLE_ENDIAN);
   bytes.asFloatBuffer().put(data);Files.write(Path.of(args[1]),bytes.array());
   System.out.println("saved prompt features: "+data.length);
  }
  DeepJExecutor.shutdown();
 }
}
