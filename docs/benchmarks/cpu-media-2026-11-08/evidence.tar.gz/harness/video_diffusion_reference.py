"""Bounded staged Diffusers SANA-Video benchmark with DeepJ's exact prompt IDs and starting noise."""
import gc,json,sys,time
from pathlib import Path
import numpy as np
from PIL import Image
import torch,diffusers,transformers
from safetensors import safe_open
from reference_common import stream_gemma,stream_video,stable_half_video
from diffusers import SanaVideoTransformer3DModel,AutoencoderKLWan,DPMSolverMultistepScheduler
from diffusers.models.transformers.transformer_sana_video import WanRotaryPosEmbed
from transformers import Gemma2Config,Gemma2Model
from transformers.models.gemma2.modeling_gemma2 import Gemma2RotaryEmbedding
root=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
inputs=json.loads((out/'video-input.json').read_text());dtype={'FLOAT32':torch.float32,'FLOAT16':torch.float16,'BFLOAT16':torch.bfloat16}[sys.argv[3]]
torch.set_num_threads(10);torch.set_num_interop_threads(1)

def sync():None
def clear():gc.collect();None;sync()
def load(model,directory,kind):
    from reference_common import load as resident
    return resident(model,directory,kind)
def stage(name,start):
    sync();elapsed=time.perf_counter()-start;stages.append(dict(stage=name,seconds=elapsed));print(json.dumps(stages[-1]),flush=True)
import torch.nn.functional as functional
def separate_bias(module, value):
    result=functional.linear(value,module.weight,None)
    return result if module.bias is None else result+module.bias
if '--split-bias' in sys.argv:torch.nn.Linear.forward=separate_bias
start_all=time.perf_counter();stages=[]
part='diffusion'
with torch.inference_mode():
    data=np.load(out/'features.npz')
    features={name:torch.from_numpy(data[name]).to(dtype) for name in ['positive','negative']}
    masks={name:torch.tensor([inputs[name]['mask']]) for name in features}
    start=time.perf_counter();cfg=json.loads((root/'transformer/config.json').read_text())
    with torch.device('meta'):model=SanaVideoTransformer3DModel.from_config(cfg)
    stream_video(model,root/'transformer',dtype)
    model.rope=WanRotaryPosEmbed(cfg['attention_head_dim'],cfg['patch_size'],cfg['rope_max_seq_len']).to('cpu')
    if dtype==torch.float16 and '--safe-fp16' in sys.argv:stable_half_video(model)
    load_time=time.perf_counter()-start
    scheduler=DPMSolverMultistepScheduler.from_pretrained(root/'scheduler',local_files_only=True);scheduler.set_timesteps(1)
    latent=torch.from_numpy(np.fromfile(out/'noise.f32',dtype='<f4').reshape(inputs['shape'])).to('cpu')
    embeds=torch.cat([features['negative'],features['positive']]);mask=torch.cat([masks['negative'],masks['positive']])
    for raw_time in scheduler.timesteps:
        timestep=raw_time.clone().to('cpu')
        prediction=model(torch.cat([latent]*2).to(dtype),timestep=timestep.expand(2),encoder_hidden_states=embeds,
            encoder_attention_mask=mask,return_dict=False)[0].float()
        negative,positive=prediction.chunk(2);flow=negative+6*(positive-negative)
        latent=scheduler.step(flow.cpu(),raw_time,latent.cpu(),return_dict=False)[0].to('cpu')
        if not torch.isfinite(latent).all():raise RuntimeError('Non-finite video latent')
    del model,prediction,positive,negative,features,embeds,masks,mask,flow;clear();stage('Transformer load and one guided step',start)
    stages[-1]['load_seconds']=load_time
    saved=latent.float().cpu().numpy()
elapsed=time.perf_counter()-start_all
(out/('python-'+part+'-result.json')).write_text(json.dumps(dict(stage=part,seconds=elapsed,stages=stages),indent=2))
print(part,elapsed,flush=True)
np.save(out/'latent.npy',saved)
