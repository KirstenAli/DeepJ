set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/cpu-media-2026-11-08"
repo="$root/work/deepj-qwen-thinking"
py="$out/reference-env/bin/python"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export VECLIB_MAXIMUM_THREADS=10 OMP_NUM_THREADS=10 PYTORCH_ENABLE_MPS_FALLBACK=0
"$py" -B - <<'WAIT'
import psutil,time
for attempt in range(180):
 names={p.info['name'] for p in psutil.process_iter(['name'])}
 if not names.intersection({'idea','Google Chrome'}):break
 time.sleep(1)
else:raise RuntimeError('Benchmark waits for IntelliJ and Chrome to close')
WAIT
for kind in image video; do
 if [[ "$kind" == image ]]; then dtype=FLOAT32; model="$root/outputs/sana-sprint-readme/model"; else dtype=FLOAT16; model="$root/outputs/sana-video-model"; fi
 trial="$out/diagnostic-$kind-$dtype-deepj"
 mkdir -p "$trial"
 printf '%s %s diagnostic\n' "$kind" "$dtype"
 "$py" -B "$out/run_guarded.py" --timeout 60 --rss-gib 9 --swap-mib 32 --stop-file "$out/STOP" --log "$trial.log" -- "$java" -Xms256m -Xmx8g --enable-native-access=ALL-UNNAMED -Djava.awt.headless=true -XX:StartFlightRecording=filename="$trial/profile.jfr",settings=profile,dumponexit=true -cp "$out/candidate-classes:$repo/target/classes:$out/classes" CpuMediaProbe "$kind" "$model" "$trial" "$dtype"
done
printf 'CPU_MEDIA_DIAGNOSTIC_COMPLETE\n'
