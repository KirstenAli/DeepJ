from pathlib import Path
import subprocess,json
out=Path(__file__).resolve().parent
with (out/'diagnostic-host.log').open('w') as log:
 process=subprocess.Popen(['/bin/bash',str(out/'diagnostic-host.sh')],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(out/'diagnostic-supervisor.json').write_text(json.dumps({'pid':process.pid,'script':str(out/'diagnostic-host.sh')}))
print('Started bounded CPU benchmark supervisor',process.pid,flush=True)
