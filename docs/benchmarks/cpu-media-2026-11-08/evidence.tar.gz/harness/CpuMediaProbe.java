import io.github.kirstenali.deepj.concurrent.DeepJExecutor;
import io.github.kirstenali.deepj.nn.diffusion.sana.SanaSprint;
import io.github.kirstenali.deepj.nn.diffusion.sanavideo.SanaVideo;
import io.github.kirstenali.deepj.persistence.qwen3.Qwen3Json;
import io.github.kirstenali.deepj.tensor.DType;
import io.github.kirstenali.deepj.tensor.Tensor;
import io.github.kirstenali.deepj.tensor.cpu.CpuBackend;
import java.awt.image.BufferedImage;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.imageio.ImageIO;

public final class CpuMediaProbe {
    private static final String IMAGE = "A red fox in a snowy forest, soft morning light, detailed wildlife photograph";
    private static final String VIDEO = "A small red fox walks slowly through a sunny green meadow. "
            + "Clear natural daylight, detailed fur, steady camera. motion score: 30.";
    private static final List<Map<String, Object>> STAGES = new ArrayList<>();
    private static long start, previous;
    private static String last = "setup";
    private CpuMediaProbe() {}

    public static void main(String[] args) throws Exception {
        Tensor.setBackend(new CpuBackend());
        DeepJExecutor.setNumThreads(10);
        requireNativeCpu();
        Path output = Path.of(args[2]);
        Files.createDirectories(output);
        DType dtype = DType.valueOf(args[3]);
        start = previous = System.nanoTime();
        List<BufferedImage> frames = generate(args[0], Path.of(args[1]), dtype);
        stage("complete");
        double elapsed = (System.nanoTime() - start) / 1e9;
        for (int i = 0; i < frames.size(); i++) {
            ImageIO.write(frames.get(i), "png", output.resolve("frame-" + i + ".png").toFile());
        }
        report(output, args[0], dtype, elapsed, frames);
        Tensor.backend().releaseTemporaryResources();
        DeepJExecutor.shutdown();
    }

    private static void requireNativeCpu() throws Exception {
        var available = Class.forName("io.github.kirstenali.deepj.tensor.CpuBlas").getDeclaredField("AVAILABLE");
        available.setAccessible(true);
        if (!available.getBoolean(null)) throw new IllegalStateException("CPU native library is unavailable");
    }

    private static List<BufferedImage> generate(String kind, Path model, DType dtype) throws Exception {
        if (kind.equals("image")) {
            return List.of(new SanaSprint(model, CpuMediaProbe::stage).generate(IMAGE,
                    new SanaSprint.Options(64, 64, 2, 4.5f, 42, dtype)));
        }
        return new SanaVideo(model, CpuMediaProbe::stage).generate(VIDEO,
                new SanaVideo.Options(32, 32, 5, 1, 6, 42, dtype));
    }

    private static void report(Path output, String kind, DType dtype, double elapsed,
                               List<BufferedImage> frames) throws Exception {
        var data = new LinkedHashMap<String, Object>();
        data.put("engine", "DeepJ");
        data.put("kind", kind);
        data.put("backend", "cpu");
        data.put("dtype", dtype.name());
        data.put("generation_seconds", elapsed);
        data.put("frames", frames.size());
        data.put("width", frames.get(0).getWidth());
        data.put("height", frames.get(0).getHeight());
        data.put("stages", STAGES);
        String json = Qwen3Json.stringify(data);
        Files.writeString(output.resolve("result.json"), json);
        System.out.println(json);
    }

    private static void stage(String name) {
        long now = System.nanoTime();
        var record = Map.<String, Object>of("stage", last, "seconds", (now - previous) / 1e9,
                "next", name, "elapsed_seconds", (now - start) / 1e9);
        STAGES.add(record);
        System.out.println(Qwen3Json.stringify(record));
        previous = now;
        last = name;
    }
}
