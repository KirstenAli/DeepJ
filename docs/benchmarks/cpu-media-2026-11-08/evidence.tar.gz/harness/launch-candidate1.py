from pathlib import Path
import subprocess,json
out=Path(__file__).resolve().parent
with (out/'candidate1-host.log').open('w') as log:
 process=subprocess.Popen(['/bin/bash',str(out/'candidate1-host.sh')],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(out/'candidate1-supervisor.json').write_text(json.dumps({'pid':process.pid,'script':str(out/'candidate1-host.sh')}))
print('Started bounded CPU benchmark supervisor',process.pid,flush=True)
