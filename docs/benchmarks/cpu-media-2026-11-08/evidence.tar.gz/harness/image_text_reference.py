"""Staged official Diffusers models and scheduler, using DeepJ's exact prompt IDs and noises."""
import sys,time,json,os
from pathlib import Path
import numpy as np
from PIL import Image
import torch,diffusers,transformers
from diffusers import SanaTransformer2DModel,AutoencoderDC,SCMScheduler
from diffusers.schedulers import scheduling_scm
from transformers import Gemma2Config,Gemma2Model
from transformers.models.gemma2.modeling_gemma2 import Gemma2RotaryEmbedding
from reference_common import load,clear,sync,stage,stages
device='cpu'
root=Path(sys.argv[1]);inputs_root=Path(sys.argv[2]);out=Path(sys.argv[3]);out.mkdir(parents=True,exist_ok=True)
dtype={'FLOAT32':torch.float32,'FLOAT16':torch.float16,'BFLOAT16':torch.bfloat16}[sys.argv[4]]
inputs=json.loads((inputs_root/'image-input.json').read_text())
torch.set_num_threads(10);torch.set_num_interop_threads(1)

def noise(index):return torch.from_numpy(np.fromfile(inputs_root/f'image-noise-{index}.f32',dtype='<f4').reshape(1,32,2,2)).to(device)
start_all=time.perf_counter()
with torch.inference_mode():
 start=time.perf_counter();cfg=Gemma2Config.from_pretrained(root/'text_encoder',local_files_only=True);cfg._attn_implementation='eager'
 with torch.device('meta'):model=Gemma2Model(cfg)
 load(model,root/'text_encoder',torch.bfloat16);model.rotary_emb=Gemma2RotaryEmbedding(cfg).to(device)
 if hasattr(model.embed_tokens,'embed_scale'):model.embed_tokens.embed_scale=torch.tensor(cfg.hidden_size**.5,device=device,dtype=torch.bfloat16)
 hidden=model(torch.tensor([inputs['tokens']],device=device),attention_mask=torch.tensor([inputs['valid']],device=device),use_cache=False).last_hidden_state
 text=hidden[:,inputs['selected']].to(dtype);mask=torch.tensor([inputs['mask']],device=device)
 del hidden,model;clear();stage('Gemma load and encode',start)
 text.float().cpu().numpy().tofile(out/"python-text.f32")
print("text saved",flush=True)
