"""Bounded staged Diffusers SANA-Video benchmark with DeepJ's exact prompt IDs and starting noise."""
import gc,json,sys,time
from pathlib import Path
import numpy as np
from PIL import Image
import torch,diffusers,transformers
from safetensors import safe_open
from reference_common import stream_gemma,stream_video,stable_half_video
from diffusers import SanaVideoTransformer3DModel,AutoencoderKLWan,DPMSolverMultistepScheduler
from diffusers.models.transformers.transformer_sana_video import WanRotaryPosEmbed
from transformers import Gemma2Config,Gemma2Model
from transformers.models.gemma2.modeling_gemma2 import Gemma2RotaryEmbedding
root=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
inputs=json.loads((out/'video-input.json').read_text());dtype={'FLOAT32':torch.float32,'FLOAT16':torch.float16,'BFLOAT16':torch.bfloat16}[sys.argv[3]]
torch.set_num_threads(10);torch.set_num_interop_threads(1)

def sync():None
def clear():gc.collect();None;sync()
def load(model,directory,kind):
    from reference_common import load as resident
    return resident(model,directory,kind)
def stage(name,start):
    sync();elapsed=time.perf_counter()-start;stages.append(dict(stage=name,seconds=elapsed));print(json.dumps(stages[-1]),flush=True)
start_all=time.perf_counter();stages=[]
part='decode'
with torch.inference_mode():
    latent=torch.from_numpy(np.load(out/'latent.npy'))
    start=time.perf_counter();cfg=json.loads((root/'vae/config.json').read_text())
    with torch.device('meta'):model=AutoencoderKLWan.from_config(cfg)
    load(model,root/'vae',torch.float32);load_time=time.perf_counter()-start
    mean=torch.tensor(cfg['latents_mean'],device='cpu').reshape(1,16,1,1,1)
    std=torch.tensor(cfg['latents_std'],device='cpu').reshape(1,16,1,1,1)
    video=model.decode(latent.float()*std+mean,return_dict=False)[0]
    if not torch.isfinite(video).all():raise RuntimeError('Non-finite video decoder')
    pixels=video[0].float().cpu().clamp(-1,1).permute(1,2,3,0).numpy()
    rgb=np.rint((pixels+1)*127.5).clip(0,255).astype('uint8')
    del model,video;clear();stage('Wan load and decode',start);stages[-1]['load_seconds']=load_time
elapsed=time.perf_counter()-start_all
(out/('python-'+part+'-result.json')).write_text(json.dumps(dict(stage=part,seconds=elapsed,stages=stages),indent=2))
print(part,elapsed,flush=True)
for i,frame in enumerate(rgb):Image.fromarray(frame).save(out/f'python-frame-{i}.png')
