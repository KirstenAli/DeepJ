set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/cpu-media-2026-11-08"
repo="$root/work/deepj-qwen-thinking"
py="$out/reference-env/bin/python"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export VECLIB_MAXIMUM_THREADS=10 OMP_NUM_THREADS=10 PYTORCH_ENABLE_MPS_FALLBACK=0
for engine in deepj python; do
 trial="$out/pilot-image-FLOAT32-$engine"
 mkdir -p "$trial"
 if [[ "$engine" == deepj ]]; then
  cmd=("$java" -Xms256m -Xmx8g --enable-native-access=ALL-UNNAMED -Djava.awt.headless=true -cp "$repo/target/classes:$out/classes" CpuMediaProbe image "$root/outputs/sana-sprint-readme/model" "$trial" FLOAT32)
 else
  cmd=("$py" -B "$out/image_reference.py" "$root/outputs/sana-sprint-readme/model" "$out" "$trial" FLOAT32)
 fi
 "$py" -B "$out/run_guarded.py" --timeout 60 --rss-gib 9 --swap-mib 32 --stop-file "$out/STOP" --log "$trial.log" -- "${cmd[@]}"
done
printf 'CPU_PHOTO_PILOT_COMPLETE\n'
