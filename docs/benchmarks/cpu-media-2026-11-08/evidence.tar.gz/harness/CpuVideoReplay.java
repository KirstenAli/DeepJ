import io.github.kirstenali.deepj.autograd.GradMode;
import io.github.kirstenali.deepj.concurrent.DeepJExecutor;
import io.github.kirstenali.deepj.nn.diffusion.sanavideo.SanaVideo;
import io.github.kirstenali.deepj.persistence.qwen3.Qwen3Json;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.cpu.CpuBackend;
import java.nio.*;
import java.nio.file.*;
import java.lang.reflect.*;
import java.awt.image.BufferedImage;
import java.util.*;
import javax.imageio.ImageIO;
public final class CpuVideoReplay {
 public static void main(String[] args) throws Exception {
  Tensor.setBackend(new CpuBackend());DeepJExecutor.setNumThreads(10);
  Path out=Path.of(args[1]),features=Path.of(args[3]);Files.createDirectories(out);
  var model=new SanaVideo(Path.of(args[0]));DType type=DType.valueOf(args[2]);
  try(var ignored=GradMode.noGrad()) {
   Object texts=features(features,Path.of(args[4]));
   Tensor latent=(Tensor)invoke(model,"sample",new Class[]{texts.getClass(),SanaVideo.Options.class},texts,new SanaVideo.Options(32,32,5,1,6,42,type));
   write(out.resolve("latent.f32"),latent.toFloatArray());
   @SuppressWarnings("unchecked") var frames=(List<BufferedImage>)invoke(model,"decode",new Class[]{Tensor.class},latent);
   for(int i=0;i<frames.size();i++) {ImageIO.write(frames.get(i),"png",out.resolve("frame-"+i+".png").toFile());}
  }
  DeepJExecutor.shutdown();
 }
 private static Object features(Path folder,Path inputs) throws Exception {
  Class<?> type=Class.forName(SanaVideo.class.getName()+"$Features");
  var constructor=type.getDeclaredConstructor(float[].class,int[].class,int[].class);constructor.setAccessible(true);
  Object array=Array.newInstance(type,2);var metadata=Qwen3Json.read(inputs);
  String[] names={"positive","negative"};
  for(int i=0;i<2;i++) {
   var entry=Qwen3Json.object(metadata.get(names[i]));
   int[] mask=Qwen3Json.array(entry.get("mask")).stream().mapToInt(v->((Number)v).intValue()).toArray();
   ByteBuffer data=ByteBuffer.wrap(Files.readAllBytes(folder.resolve(names[i]+".f32"))).order(ByteOrder.LITTLE_ENDIAN);
   float[] values=new float[data.remaining()/4];data.asFloatBuffer().get(values);
   Array.set(array,i,constructor.newInstance(values,new int[]{1,300,2304},mask));
  }
  return array;
 }
 private static Object invoke(Object target,String name,Class<?>[] types,Object... args) throws Exception {
  Method method=target.getClass().getDeclaredMethod(name,types);method.setAccessible(true);
  return method.invoke(target,args);
 }
 private static void write(Path path,float[] values) throws Exception {
  ByteBuffer bytes=ByteBuffer.allocate(values.length*4).order(ByteOrder.LITTLE_ENDIAN);
  bytes.asFloatBuffer().put(values);Files.write(path,bytes.array());
 }
}
