set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/cpu-media-2026-11-08"
repo="$root/work/deepj-qwen-thinking"
py="$out/reference-env/bin/python"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export VECLIB_MAXIMUM_THREADS=10 OMP_NUM_THREADS=10 PYTORCH_ENABLE_MPS_FALLBACK=0
"$py" -B - <<'WAIT'
import psutil,time
for attempt in range(180):
 names={p.info['name'] for p in psutil.process_iter(['name'])}
 if not names.intersection({'idea','Google Chrome'}):break
 time.sleep(1)
else:raise RuntimeError('Benchmark waits for IntelliJ and Chrome to close')
WAIT

trial="$out/split-video-BFLOAT16-python"
mkdir -p "$trial"
cp "$out/video-input.json" "$trial/video-input.json"
cp "$out/noise.f32" "$trial/noise.f32"
for stage in text diffusion decode; do
 "$py" -B "$out/run_guarded.py" --timeout 60 --rss-gib 9 --swap-mib 32 --stop-file "$out/STOP" --log "$trial/$stage.log" -- "$py" -B "$out/video_${stage}_reference.py" "$root/outputs/sana-video-model" "$trial" BFLOAT16 --safe-fp16
done
for dtype in FLOAT32 FLOAT16 BFLOAT16; do
 trial="$out/replay-image-$dtype-deepj"
 mkdir -p "$trial"
 "$py" -B "$out/run_guarded.py" --timeout 60 --rss-gib 9 --swap-mib 32 --stop-file "$out/STOP" --log "$trial.log" -- "$java" -Xms256m -Xmx8g --enable-native-access=ALL-UNNAMED -Djava.awt.headless=true -cp "$out/candidate-classes:$repo/target/classes:$out/classes" io.github.kirstenali.deepj.nn.diffusion.sana.CpuImageReplay "$root/outputs/sana-sprint-readme/model" "$trial" "$dtype" "$out/text-python/python-text.f32" "$out/image-input.json"
 for control in same-text alternate-text; do
  trial="$out/replay-image-$dtype-$control-python"
  mkdir -p "$trial"
  text="$out/text-python/python-text.f32"
  if [[ "$control" == alternate-text ]]; then text="$root/outputs/python-photo-parity-2026-11-08/split-bias-BFLOAT16/text.f32"; fi
  "$py" -B "$out/run_guarded.py" --timeout 60 --rss-gib 9 --swap-mib 32 --stop-file "$out/STOP" --log "$trial.log" -- "$py" -B "$out/image_replay_reference.py" "$root/outputs/sana-sprint-readme/model" "$out" "$trial" "$dtype" "$text"
 done
done
printf 'CPU_IMAGE_COMPONENT_ACCURACY_COMPLETE\n'
