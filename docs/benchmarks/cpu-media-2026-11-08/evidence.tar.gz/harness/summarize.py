import hashlib,json,statistics,struct
from pathlib import Path
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parent
DTYPES=['FLOAT32','FLOAT16','BFLOAT16']
def read(path):return json.loads(path.read_text())
def image(folder):return np.asarray(Image.open(folder/'frame-0.png'),dtype=np.int16)
def frames(folder,prefix):
    return np.stack([np.asarray(Image.open(folder/f'{prefix}{i}.png'),dtype=np.int16) for i in range(5)])
def difference(a,b):
    delta=np.abs(a-b)
    return dict(mean=float(delta.mean()),maximum=int(delta.max()),p99=float(np.quantile(delta,.99)),identical=bool(np.array_equal(a,b)))
def timing(kind,dtype):
    deepj=[read(ROOT/f'candidate{n}-{kind}-{dtype}-deepj/result.json') for n in [1,2]]
    if kind=='image':python=[read(ROOT/f'{tag}-{kind}-{dtype}-python/result.json') for tag in ['baseline','candidate1']]
    elif dtype=='FLOAT32':python=[read(ROOT/f'{tag}-{kind}-{dtype}-python/python-video-result.json') for tag in ['baseline','candidate1']]
    else:python=[read(f) for f in sorted((ROOT/f'split-video-{dtype}-python').glob('python-*-result.json'))]
    seconds=[x['generation_seconds'] for x in python] if 'generation_seconds' in python[0] else [sum(x['seconds'] for x in python)]
    return dict(kind=kind,dtype=dtype,final_deepj_seconds=deepj[-1]['generation_seconds'],deepj_observations=deepj,
                python_observations=python,python_seconds=seconds,python_summary_seconds=statistics.median(seconds),
                python_method='isolated stage sum' if kind=='video' and dtype!='FLOAT32' else 'median of two complete generations')
def photo(dtype):
    actual=image(ROOT/f'candidate2-image-{dtype}-deepj');oracle=image(ROOT/f'candidate1-image-{dtype}-python')
    own=image(ROOT/f'replay-image-{dtype}-deepj');same=image(ROOT/f'replay-image-{dtype}-same-text-python')
    alternate=image(ROOT/f'replay-image-{dtype}-alternate-text-python');rounded=image(ROOT/f'replay-image-{dtype}-split-bias-python')
    return dict(dtype=dtype,baseline=difference(actual,image(ROOT/f'baseline-image-{dtype}-deepj')),
                python=difference(actual,oracle),same_features=difference(own,same),
                python_text_control=difference(same,alternate),python_rounding_control=difference(same,rounded),
                versus_rounding_control=difference(own,rounded))
def video(dtype):
    folder=ROOT/f'candidate1-video-{dtype}-python' if dtype=='FLOAT32' else ROOT/f'split-video-{dtype}-python'
    a=frames(ROOT/f'candidate2-video-{dtype}-deepj','frame-');b=frames(folder,'python-frame-')
    old=ROOT/f'replay-video-{dtype}-baseline';new=ROOT/f'replay-video-{dtype}-candidate'
    row=dict(dtype=dtype,python=difference(a,b),baseline=difference(frames(old,'frame-'),frames(new,'frame-')),
             latent_identical=(old/'latent.f32').read_bytes()==(new/'latent.f32').read_bytes(),
             same_features=difference(frames(new,'frame-'),b))
    if dtype=='BFLOAT16':
        c=frames(ROOT/'video-BFLOAT16-split-bias-python','python-frame-')
        row.update(python_rounding_control=difference(b,c),versus_rounding_control=difference(frames(new,'frame-'),c))
    return row
def training():
    rows=read(ROOT/'training-regression.json')
    for model in ['loop','prism','qwen']:
        a=read(ROOT/f'training-{model}-baseline.jsonl');b=read(ROOT/f'training-{model}-candidate.jsonl')
        rows.append(dict(model=model,dtype='FLOAT32',steps=len(a['losses']),losses_equal=a['losses']==b['losses'],
                         parameters_equal=a['parameters_sha256']==b['parameters_sha256'],gradients_equal=a['gradients_sha256']==b['gradients_sha256'],
                         baseline_ms=statistics.median(a['milliseconds']),candidate_ms=statistics.median(b['milliseconds'])))
    return rows
def guards():
    accepted=[];excluded=[]
    for path in sorted(ROOT.rglob('*.metrics.json')):
        data=read(path);entry=dict(file=str(path.relative_to(ROOT)),**data)
        (accepted if data['returncode']==0 and data.get('stopped_for') is None else excluded).append(entry)
    return dict(accepted=accepted,excluded=excluded)
result=dict(baseline_commit=(ROOT/'baseline-commit.txt').read_text().strip(),threads=10,
            environment=read(ROOT/'baseline-image-FLOAT32-python/result.json'),
            timings=[timing(kind,dtype) for kind in ['image','video'] for dtype in DTYPES],
            photos=[photo(dtype) for dtype in DTYPES],videos=[video(dtype) for dtype in DTYPES],training=training(),guards=guards())
assert all(x['baseline']['identical'] for x in result['photos']+result['videos'])
assert all(x['latent_identical'] for x in result['videos'])
assert all(x['losses_equal'] and all(x.get('tensors_equal',{}).values()) for x in result['training'])
(ROOT/'results.json').write_text(json.dumps(result,indent=2))
print('All before/after photo/video and training equivalence assertions passed')
for row in result['timings']:print(row['kind'],row['dtype'],row['final_deepj_seconds'],row['python_summary_seconds'],row['python_method'])
