import io.github.kirstenali.deepj.concurrent.DeepJExecutor;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.cpu.CpuBackend;
import java.util.Arrays;
public final class CpuUnaryProbe {
 public static void main(String[] args) {
  Tensor.setBackend(new CpuBackend()); DeepJExecutor.setNumThreads(10);
  for (DType type : DType.values()) {
   float[] data = new float[596*9216];
   for(int i=0;i<data.length;i++) data[i]=(i%1001-500)*0.01f;
   Tensor x=Tensor.from(data,type,1,596,9216);
   double[] times=new double[7]; float check=0;
   for(int i=0;i<10;i++) {
    long start=System.nanoTime(); Tensor y=Tensor.backend().gelu(x);
    double ms=(System.nanoTime()-start)/1e6; check=y.get(0,0,700);
    if(i>=3) times[i-3]=ms;
   }
   Arrays.sort(times); System.out.println(type+" median_ms="+times[3]+" check="+check);
  }
  DeepJExecutor.shutdown();
 }
}
