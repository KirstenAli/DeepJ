set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/cpu-media-2026-11-08"
repo="$root/work/deepj-qwen-thinking"
py="$out/reference-env/bin/python"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export VECLIB_MAXIMUM_THREADS=10 OMP_NUM_THREADS=10 PYTORCH_ENABLE_MPS_FALLBACK=0
"$py" -B - <<'WAIT'
import psutil,time
for attempt in range(180):
 names={p.info['name'] for p in psutil.process_iter(['name'])}
 if not names.intersection({'idea','Google Chrome'}):break
 time.sleep(1)
else:raise RuntimeError('Benchmark waits for IntelliJ and Chrome to close')
WAIT
for kind in image video; do
 for dtype in FLOAT32 FLOAT16 BFLOAT16; do
  for engine in deepj python; do
   if [[ -f "$out/STOP" ]]; then exit 1; fi
   trial="$out/baseline-$kind-$dtype-$engine"
   mkdir -p "$trial"
   if [[ "$kind" == image ]]; then model="$root/outputs/sana-sprint-readme/model"; else model="$root/outputs/sana-video-model"; fi
   if [[ "$engine" == deepj ]]; then
    cmd=("$java" -Xms256m -Xmx8g --enable-native-access=ALL-UNNAMED -Djava.awt.headless=true -cp "$repo/target/classes:$out/classes" CpuMediaProbe "$kind" "$model" "$trial" "$dtype")
   elif [[ "$kind" == image ]]; then
    cmd=("$py" -B "$out/image_reference.py" "$model" "$out" "$trial" "$dtype")
   else
    cp "$out/video-input.json" "$trial/video-input.json"
    cp "$out/noise.f32" "$trial/noise.f32"
    cmd=("$py" -B "$out/video_reference.py" "$model" "$trial" "$dtype" --safe-fp16)
   fi
   printf '%s %s %s\n' "$kind" "$dtype" "$engine"
   "$py" -B "$out/run_guarded.py" --timeout 60 --rss-gib 9 --swap-mib 32 --stop-file "$out/STOP" --log "$trial.log" -- "${cmd[@]}"
  done
 done
done
printf 'CPU_MEDIA_BASELINE_COMPLETE\n'
