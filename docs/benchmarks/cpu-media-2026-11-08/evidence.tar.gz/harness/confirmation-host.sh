set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/cpu-media-2026-11-08"
repo="$root/work/deepj-qwen-thinking"
py="$out/reference-env/bin/python"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export VECLIB_MAXIMUM_THREADS=10 OMP_NUM_THREADS=10 PYTORCH_ENABLE_MPS_FALLBACK=0
"$py" -B - <<'WAIT'
import psutil,time
for attempt in range(180):
 names={p.info['name'] for p in psutil.process_iter(['name'])}
 if not names.intersection({'idea','Google Chrome'}):break
 time.sleep(1)
else:raise RuntimeError('Benchmark waits for IntelliJ and Chrome to close')
WAIT

for dtype in FLOAT32 FLOAT16 BFLOAT16; do
 trial="$out/replay-image-$dtype-split-bias-python"
 mkdir -p "$trial"
 "$py" -B "$out/run_guarded.py" --timeout 60 --rss-gib 9 --swap-mib 32 --stop-file "$out/STOP" --log "$trial.log" -- "$py" -B "$out/image_replay_reference.py" "$root/outputs/sana-sprint-readme/model" "$out" "$trial" "$dtype" "$out/text-python/python-text.f32" --split-bias
done
trial="$out/split-video-FLOAT32-python"
mkdir -p "$trial"
cp "$out/video-input.json" "$trial/video-input.json"
cp "$out/noise.f32" "$trial/noise.f32"
"$py" -B "$out/run_guarded.py" --timeout 60 --rss-gib 9 --swap-mib 32 --stop-file "$out/STOP" --log "$trial/text.log" -- "$py" -B "$out/video_text_reference.py" "$root/outputs/sana-video-model" "$trial" FLOAT32
for dtype in FLOAT32 FLOAT16 BFLOAT16; do
 features="$out/split-video-$dtype-python"
 "$py" -B - "$features" <<'UNPACK'
from pathlib import Path
import numpy as np,sys
p=Path(sys.argv[1]);x=np.load(p/'features.npz')
for name in ['positive','negative']:x[name].astype('<f4').tofile(p/(name+'.f32'))
UNPACK
 for revision in baseline candidate; do
  trial="$out/replay-video-$dtype-$revision"
  mkdir -p "$trial"
  "$py" -B "$out/run_guarded.py" --timeout 60 --rss-gib 9 --swap-mib 32 --stop-file "$out/STOP" --log "$trial.log" -- "$java" -Xms256m -Xmx8g --enable-native-access=ALL-UNNAMED -Djava.awt.headless=true -cp "$out/$revision-classes:$repo/target/classes:$out/classes" CpuVideoReplay "$root/outputs/sana-video-model" "$trial" "$dtype" "$features" "$out/video-input.json"
 done
done
trial="$out/video-BFLOAT16-split-bias-python"
mkdir -p "$trial"
cp "$out/video-input.json" "$trial/video-input.json"
cp "$out/noise.f32" "$trial/noise.f32"
cp "$out/split-video-BFLOAT16-python/features.npz" "$trial/features.npz"
for stage in diffusion decode; do
 "$py" -B "$out/run_guarded.py" --timeout 60 --rss-gib 9 --swap-mib 32 --stop-file "$out/STOP" --log "$trial/$stage.log" -- "$py" -B "$out/video_${stage}_reference.py" "$root/outputs/sana-video-model" "$trial" BFLOAT16 --safe-fp16 --split-bias
done
for kind in image video; do
 for dtype in FLOAT32 FLOAT16 BFLOAT16; do
  trial="$out/candidate2-$kind-$dtype-deepj"
  mkdir -p "$trial"
  if [[ "$kind" == image ]]; then model="$root/outputs/sana-sprint-readme/model"; else model="$root/outputs/sana-video-model"; fi
  "$py" -B "$out/run_guarded.py" --timeout 60 --rss-gib 9 --swap-mib 32 --stop-file "$out/STOP" --log "$trial.log" -- "$java" -Xms256m -Xmx8g --enable-native-access=ALL-UNNAMED -Djava.awt.headless=true -cp "$out/candidate-classes:$repo/target/classes:$out/classes" CpuMediaProbe "$kind" "$model" "$trial" "$dtype"
 done
done
for model in qwen gemma; do
 if [[ "$model" == qwen ]]; then fixture="$root/outputs/qwen-training-comparison/fixture"; else fixture="$root/outputs/gemma-video-gap-2026-11-07/tiny-gemma"; fi
 for dtype in FLOAT32 FLOAT16 BFLOAT16; do
  for revision in baseline candidate; do
   trial="$out/training-$model-$dtype-$revision"
   "$java" -Xmx1g --enable-native-access=ALL-UNNAMED -cp "$out/$revision-classes:$repo/target/classes:$out/classes" io.github.kirstenali.deepj.nn.transformer.qwen3.CompactTrainingProbe "$model" "$fixture" "$dtype" cpu "$trial" audit > "$trial.log" 2>&1
  done
 done
done
for model in loop prism qwen; do
 for revision in baseline candidate; do
  "$java" -Xmx1g --enable-native-access=ALL-UNNAMED -Ddeepj.probe.warmups=50 -Ddeepj.probe.runs=51 -cp "$out/$revision-classes:$repo/target/classes:$out/classes" TinyTrainingProbe cpu "$model" > "$out/training-$model-$revision.jsonl" 2>&1
 done
done
printf 'CPU_MEDIA_CONFIRMATION_COMPLETE\n'
