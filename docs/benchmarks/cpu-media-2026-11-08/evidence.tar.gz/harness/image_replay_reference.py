"""Staged official Diffusers models and scheduler, using DeepJ's exact prompt IDs and noises."""
import sys,time,json,os
from pathlib import Path
import numpy as np
from PIL import Image
import torch,diffusers,transformers
from diffusers import SanaTransformer2DModel,AutoencoderDC,SCMScheduler
from diffusers.schedulers import scheduling_scm
from transformers import Gemma2Config,Gemma2Model
from transformers.models.gemma2.modeling_gemma2 import Gemma2RotaryEmbedding
from reference_common import load,clear,sync,stage,stages
device='cpu'
root=Path(sys.argv[1]);inputs_root=Path(sys.argv[2]);out=Path(sys.argv[3]);out.mkdir(parents=True,exist_ok=True)
dtype={'FLOAT32':torch.float32,'FLOAT16':torch.float16,'BFLOAT16':torch.bfloat16}[sys.argv[4]]
inputs=json.loads((inputs_root/'image-input.json').read_text())
torch.set_num_threads(10);torch.set_num_interop_threads(1)

def noise(index):return torch.from_numpy(np.fromfile(inputs_root/f'image-noise-{index}.f32',dtype='<f4').reshape(1,32,2,2)).to(device)
import torch.nn.functional as functional
def separate_linear(module,value):
 result=functional.linear(value,module.weight,None)
 return result if module.bias is None else result+module.bias
def separate_convolution(module,value):
 result=module._conv_forward(value,module.weight,None)
 return result if module.bias is None else result+module.bias.reshape(1,-1,1,1)
if '--split-bias' in sys.argv:
 torch.nn.Linear.forward=separate_linear
 torch.nn.Conv2d.forward=separate_convolution
start_all=time.perf_counter()
with torch.inference_mode():
 text=torch.from_numpy(np.fromfile((Path(sys.argv[5]) if len(sys.argv)>5 else inputs_root/'text-python/python-text.f32'),dtype='<f4').reshape(1,300,2304)).to(dtype)
 mask=torch.tensor([inputs['mask']],device=device)
 start=time.perf_counter();cfg=json.loads((root/'transformer/config.json').read_text())
 with torch.device('meta'):model=SanaTransformer2DModel.from_config(cfg)
 load(model,root/'transformer',dtype)
 scheduler=SCMScheduler.from_pretrained(root/'scheduler',local_files_only=True);scheduler.set_timesteps(2,device=device)
 latent=noise(0)*scheduler.config.sigma_data;fixed=noise(1)
 scheduling_scm.randn_tensor=lambda *args,**kwargs:fixed
 guidance=torch.tensor([4.5],device=device,dtype=torch.float32)*cfg['guidance_embeds_scale']
 for angle in scheduler.timesteps[:-1]:
  t=angle.expand(1);time_value=torch.sin(t)/(torch.cos(t)+torch.sin(t));u=time_value.reshape(-1,1,1,1)
  model_input=latent/scheduler.config.sigma_data*torch.sqrt(u**2+(1-u)**2)
  prediction=model(model_input.to(dtype),encoder_hidden_states=text,encoder_attention_mask=mask,guidance=guidance,timestep=time_value,return_dict=False)[0]
  predicted=((1-2*u)*model_input+(1-2*u+2*u**2)*prediction)/torch.sqrt(u**2+(1-u)**2)
  latent,denoised=scheduler.step(predicted.float()*scheduler.config.sigma_data,t,latent,return_dict=False)
 latent=denoised/scheduler.config.sigma_data
 latent.float().cpu().numpy().tofile(out/'latent.f32')
 if not torch.isfinite(latent).all():raise RuntimeError('Non-finite image latent')
 del model,prediction,predicted,model_input,text,mask,fixed;clear();stage('Transformer load and two steps',start)
 start=time.perf_counter();cfg=json.loads((root/'vae/config.json').read_text())
 with torch.device('meta'):model=AutoencoderDC.from_config(cfg)
 load(model,root/'vae',dtype)
 pixels=model.decode(latent.to(dtype)/cfg['scaling_factor'],return_dict=False)[0]
 pixels=pixels[0].float().cpu().clamp(-1,1).permute(1,2,0).numpy();rgb=np.rint((pixels+1)*127.5).clip(0,255).astype('uint8')
 del model;clear();stage('DC-AE load and decode',start)
elapsed=time.perf_counter()-start_all
Image.fromarray(rgb).save(out/'frame-0.png')
result=dict(engine='PyTorch/Diffusers',torch=torch.__version__,transformers=transformers.__version__,diffusers=diffusers.__version__,backend=device,dtype=sys.argv[4],width=64,height=64,steps=2,guidance=4.5,stages=stages,generation_seconds=elapsed)
(out/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
