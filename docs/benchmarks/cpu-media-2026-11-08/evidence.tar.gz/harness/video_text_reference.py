"""Bounded staged Diffusers SANA-Video benchmark with DeepJ's exact prompt IDs and starting noise."""
import gc,json,sys,time
from pathlib import Path
import numpy as np
from PIL import Image
import torch,diffusers,transformers
from safetensors import safe_open
from reference_common import stream_gemma,stream_video,stable_half_video
from diffusers import SanaVideoTransformer3DModel,AutoencoderKLWan,DPMSolverMultistepScheduler
from diffusers.models.transformers.transformer_sana_video import WanRotaryPosEmbed
from transformers import Gemma2Config,Gemma2Model
from transformers.models.gemma2.modeling_gemma2 import Gemma2RotaryEmbedding
root=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
inputs=json.loads((out/'video-input.json').read_text());dtype={'FLOAT32':torch.float32,'FLOAT16':torch.float16,'BFLOAT16':torch.bfloat16}[sys.argv[3]]
torch.set_num_threads(10);torch.set_num_interop_threads(1)

def sync():None
def clear():gc.collect();None;sync()
def load(model,directory,kind):
    from reference_common import load as resident
    return resident(model,directory,kind)
def stage(name,start):
    sync();elapsed=time.perf_counter()-start;stages.append(dict(stage=name,seconds=elapsed));print(json.dumps(stages[-1]),flush=True)
start_all=time.perf_counter();stages=[]
part='text'
with torch.inference_mode():
    start=time.perf_counter();cfg=Gemma2Config.from_pretrained(root/'text_encoder',local_files_only=True);cfg._attn_implementation='eager'
    with torch.device('meta'):model=Gemma2Model(cfg)
    stream_gemma(model,root/'text_encoder',dtype);model.rotary_emb=Gemma2RotaryEmbedding(cfg).to('cpu')
    if hasattr(model.embed_tokens,'embed_scale'):
        model.embed_tokens.embed_scale=torch.tensor(cfg.hidden_size**.5,device='cpu',dtype=dtype)
    load_time=time.perf_counter()-start;features={};masks={}
    names=['positive','negative'];length=max(len(inputs[name]['tokens']) for name in names)
    tokens=[inputs[name]['tokens']+[0]*(length-len(inputs[name]['tokens'])) for name in names]
    valid=[inputs[name]['valid']+[0]*(length-len(inputs[name]['valid'])) for name in names]
    hidden=model(torch.tensor(tokens,device='cpu'),attention_mask=torch.tensor(valid,device='cpu'),use_cache=False).last_hidden_state
    if not torch.isfinite(hidden).all():raise RuntimeError('Non-finite Gemma output')
    for row,name in enumerate(names):
        item=inputs[name];features[name]=hidden[row:row+1,item['selected']].to(dtype)
        masks[name]=torch.tensor([item['mask']],device='cpu')
    del hidden,model;clear();stage('Gemma load and encode',start)
    stages[-1]['load_seconds']=load_time
    saved={name:features[name].float().cpu().numpy() for name in names}
elapsed=time.perf_counter()-start_all
(out/('python-'+part+'-result.json')).write_text(json.dumps(dict(stage=part,seconds=elapsed,stages=stages),indent=2))
print(part,elapsed,flush=True)
np.savez(out/'features.npz',**saved)
