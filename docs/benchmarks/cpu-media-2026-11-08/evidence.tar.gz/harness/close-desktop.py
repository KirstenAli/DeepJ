import os,shlex,signal,subprocess,time
from pathlib import Path
closed=[]
for line in subprocess.check_output(['/bin/ps','-axo','pid=,command='],text=True).splitlines():
 fields=line.strip().split(None,1)
 if len(fields)!=2:continue
 try:args=shlex.split(fields[1])
 except ValueError:continue
 if not args or Path(args[0]).name not in {'java','javaw'} or '-jar' not in args:continue
 index=args.index('-jar')
 if index+1>=len(args) or Path(args[index+1]).name!='deepj-desktop.jar':continue
 pid=int(fields[0]);os.kill(pid,signal.SIGTERM);closed.append(pid)
for pid in closed:
 for attempt in range(25):
  try:os.kill(pid,0)
  except ProcessLookupError:break
  time.sleep(.2)
 else:os.kill(pid,signal.SIGKILL)
print('Closed DeepJ desktop processes:',closed,flush=True)
print(subprocess.check_output(['/usr/bin/vm_stat'],text=True),flush=True)
print(subprocess.check_output(['/usr/sbin/sysctl','vm.swapusage'],text=True),flush=True)
