set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/cpu-media-2026-11-08"
repo="$root/work/deepj-qwen-thinking"
py="$out/reference-env/bin/python"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export VECLIB_MAXIMUM_THREADS=10 OMP_NUM_THREADS=10 PYTORCH_ENABLE_MPS_FALLBACK=0
"$py" -B - <<'WAIT'
import psutil,time
for attempt in range(180):
 names={p.info['name'] for p in psutil.process_iter(['name'])}
 if not names.intersection({'idea','Google Chrome'}):break
 time.sleep(1)
else:raise RuntimeError('Benchmark waits for IntelliJ and Chrome to close')
WAIT

trial="$out/text-python"
mkdir -p "$trial"
"$py" -B "$out/run_guarded.py" --timeout 60 --rss-gib 9 --swap-mib 32 --stop-file "$out/STOP" --log "$trial.log" -- "$py" -B "$out/image_text_reference.py" "$root/outputs/sana-sprint-readme/model" "$out" "$trial" FLOAT32
"$py" -B "$out/run_guarded.py" --timeout 60 --rss-gib 9 --swap-mib 32 --stop-file "$out/STOP" --log "$out/text-deepj.log" -- "$java" -Xms256m -Xmx8g --enable-native-access=ALL-UNNAMED -Djava.awt.headless=true -cp "$out/candidate-classes:$repo/target/classes:$out/classes" CpuImageTextProbe "$root/outputs/sana-sprint-readme/model" "$out/deepj-text.f32"
for dtype in FLOAT16 BFLOAT16; do
 for engine in deepj python; do
  trial="$out/candidate1-video-$dtype-$engine"
  mkdir -p "$trial"
  model="$root/outputs/sana-video-model"
  if [[ "$engine" == deepj ]]; then
   "$py" -B "$out/run_guarded.py" --timeout 60 --rss-gib 9 --swap-mib 32 --stop-file "$out/STOP" --log "$trial.log" -- "$java" -Xms256m -Xmx8g --enable-native-access=ALL-UNNAMED -Djava.awt.headless=true -cp "$out/candidate-classes:$repo/target/classes:$out/classes" CpuMediaProbe video "$model" "$trial" "$dtype"
  elif [[ "$dtype" == FLOAT16 ]]; then
   trial="$out/split-video-FLOAT16-python"
   mkdir -p "$trial"
   cp "$out/video-input.json" "$trial/video-input.json"
   cp "$out/noise.f32" "$trial/noise.f32"
   for stage in text diffusion decode; do
    "$py" -B "$out/run_guarded.py" --timeout 60 --rss-gib 9 --swap-mib 32 --stop-file "$out/STOP" --log "$trial/$stage.log" -- "$py" -B "$out/video_${stage}_reference.py" "$model" "$trial" "$dtype" --safe-fp16
   done
  else
   cp "$out/video-input.json" "$trial/video-input.json"
   cp "$out/noise.f32" "$trial/noise.f32"
   "$py" -B "$out/run_guarded.py" --timeout 60 --rss-gib 9 --swap-mib 32 --stop-file "$out/STOP" --log "$trial.log" -- "$py" -B "$out/video_reference.py" "$model" "$trial" "$dtype" --safe-fp16
  fi
 done
done
printf 'CPU_MEDIA_FOLLOWUP_COMPLETE\n'
