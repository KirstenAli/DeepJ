set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/cpu-media-2026-11-08"
repo="$root/work/deepj-qwen-thinking"
py="$out/reference-env/bin/python"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export VECLIB_MAXIMUM_THREADS=10 OMP_NUM_THREADS=10 PYTORCH_ENABLE_MPS_FALLBACK=0
for model in qwen gemma; do
 if [[ "$model" == qwen ]]; then fixture="$root/outputs/qwen-training-comparison/fixture"; else fixture="$root/outputs/gemma-video-gap-2026-11-07/tiny-gemma"; fi
 for dtype in FLOAT32 FLOAT16 BFLOAT16; do
  for revision in baseline candidate; do
   trial="$out/training-$model-$dtype-$revision"
   "$java" -Xmx1g --enable-native-access=ALL-UNNAMED -cp "$out/$revision-classes:$repo/target/classes:$out/classes" io.github.kirstenali.deepj.nn.transformer.qwen3.CompactTrainingProbe "$model" "$fixture" "$dtype" cpu "$trial" audit > "$trial.log" 2>&1
  done
 done
done
for model in loop prism qwen; do
 for revision in baseline candidate; do
  "$java" -Xmx1g --enable-native-access=ALL-UNNAMED -Ddeepj.probe.warmups=50 -Ddeepj.probe.runs=51 -cp "$out/$revision-classes:$repo/target/classes:$out/classes" TinyTrainingProbe cpu "$model" > "$out/training-$model-$revision.jsonl" 2>&1
 done
done
printf 'CPU_MEDIA_CONFIRMATION_COMPLETE\n'
cd "$repo"
JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home /opt/homebrew/bin/mvn -o clean verify -Pfull-coverage -Dsanavideo.test.metal=true > "$out/full-verify.log" 2>&1
printf 'CPU_MEDIA_FULL_VERIFY_COMPLETE\n'
