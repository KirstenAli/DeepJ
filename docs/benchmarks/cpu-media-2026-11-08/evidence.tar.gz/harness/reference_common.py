import gc,time,json
import torch
from safetensors import safe_open
stages=[]
def sync():None
def clear():gc.collect();None;sync()
def load(model,directory,kind):
    wanted=set(model.state_dict())
    state={}
    for filename in sorted(directory.glob('*.safetensors')):
        with safe_open(filename,framework='pt',device='cpu') as source:
            for key in source.keys():
                if key in wanted:state[key]=source.get_tensor(key).to(dtype=kind)
    model.load_state_dict(state,strict=False,assign=True)
    if any(p.is_meta or p.dtype!=kind or p.device.type!='cpu' for p in model.parameters()):
        raise RuntimeError('Incomplete CPU model assignment')
    return model.requires_grad_(False).eval()

def stage(name,start):
    sync();elapsed=time.perf_counter()-start;stages.append(dict(stage=name,seconds=elapsed));print(json.dumps(stages[-1]),flush=True)

def index_weights(directory):
    result={}
    for filename in sorted(directory.glob('*.safetensors')):
        with safe_open(filename,framework='pt',device='cpu') as source:
            result.update({key:filename for key in source.keys()})
    return result

def assign_group(module,index,prefix,kind):
    state={}
    for key,filename in index.items():
        if not key.startswith(prefix):continue
        with safe_open(filename,framework='pt',device='cpu') as source:
            state[key[len(prefix):]]=source.get_tensor(key).to(dtype=kind)
    module.load_state_dict(state,strict=False,assign=True)

def stream_gemma(model,directory,kind):
    index=index_weights(directory)
    groups=[('embed_tokens',model.embed_tokens)]+[(f'layers.{i}',layer) for i,layer in enumerate(model.layers)]+[('norm',model.norm)]
    def before(prefix):
        def hook(module,args):
            assign_group(module,index,prefix+'.',kind)
            if prefix=='embed_tokens' and hasattr(module,'embed_scale'):
                module.embed_scale=torch.tensor(model.config.hidden_size**.5,dtype=kind)
        return hook
    def after(module,args,output):
        module.to('meta')
        return output
    for prefix,module in groups:
        module.register_forward_pre_hook(before(prefix))
        module.register_forward_hook(after)
    return model.requires_grad_(False).eval()

def stream_video(model,directory,kind):
    index=index_weights(directory)
    base={key:file for key,file in index.items() if not key.startswith('transformer_blocks.')}
    assign_group(model,base,'',kind)
    def before(prefix):
        return lambda module,args:assign_group(module,index,prefix,kind)
    def after(module,args,output):
        module.to('meta')
        return output
    for i,block in enumerate(model.transformer_blocks):
        block.register_forward_pre_hook(before(f'transformer_blocks.{i}.'))
        block.register_forward_hook(after)
    return model.requires_grad_(False).eval()

def stable_half_video(model):
    import inspect
    from diffusers.models.transformers import transformer_sana_video as upstream
    source=inspect.getsource(upstream.SanaLinearAttnProcessor3_0)
    original='z = 1 / (key.sum(dim=-1, keepdim=True).transpose(-2, -1) @ query + 1e-15)'
    replacement='z = 1 / (key.float().sum(dim=-1, keepdim=True).transpose(-2, -1) @ query.float() + 1e-15)'
    if original not in source:raise RuntimeError('Upstream attention denominator changed')
    namespace=dict(vars(upstream));exec(source.replace(original,replacement),namespace)
    processor=namespace['SanaLinearAttnProcessor3_0']()
    for block in model.transformer_blocks:block.attn1.set_processor(processor)

    import torch.nn.functional as functional
    def project(module):
        def forward(value):
            bias=None if module.bias is None else module.bias.float()
            return functional.linear(value.float(),module.weight.float(),bias)
        return forward
    def normalized(module):
        original=module.forward
        return lambda value:original(value).to(torch.float16)
    for block in model.transformer_blocks:
        for attention in [block.attn1,block.attn2]:
            for kind in ['q','k']:
                module=getattr(attention,'to_'+kind);module.forward=project(module)
                norm=getattr(attention,'norm_'+kind);norm.forward=normalized(norm)
    source=inspect.getsource(upstream.SanaVideoTransformerBlock)
    source=source.replace('hidden_states = hidden_states + gate_msa * attn_output',
        'hidden_states = hidden_states.float() + gate_msa.float() * attn_output.float()')
    source=source.replace('hidden_states = hidden_states + gate_mlp * ff_output',
        'hidden_states = hidden_states.float() + gate_mlp.float() * ff_output.float()')
    source=source.replace('norm_hidden_states.to(hidden_states.dtype)',
        'norm_hidden_states.to(self.scale_shift_table.dtype)')
    source=source.replace('norm_hidden_states.unflatten(1,',
        'norm_hidden_states.to(self.scale_shift_table.dtype).unflatten(1,')
    namespace=dict(vars(upstream));exec(source,namespace)
    import types
    forward=namespace['SanaVideoTransformerBlock'].forward
    for block in model.transformer_blocks:block.forward=types.MethodType(forward,block)
    model.proj_out.register_forward_pre_hook(lambda module,args:(args[0].to(module.weight.dtype),))
