package io.github.kirstenali.deepj.nn.diffusion.sana;

import io.github.kirstenali.deepj.autograd.GradMode;
import io.github.kirstenali.deepj.concurrent.DeepJExecutor;
import io.github.kirstenali.deepj.tensor.DType;
import io.github.kirstenali.deepj.tensor.Tensor;
import io.github.kirstenali.deepj.tensor.cpu.CpuBackend;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.nio.file.Path;
import javax.imageio.ImageIO;

public final class CpuImageReplay {
    public static void main(String[] args) throws Exception {
        Tensor.setBackend(new CpuBackend());
        DeepJExecutor.setNumThreads(10);
        Path out = Path.of(args[1]);
        Files.createDirectories(out);
        var model = new SanaSprint(Path.of(args[0]), System.out::println);
        DType dtype = DType.valueOf(args[2]);
        try (var ignored = GradMode.noGrad()) {
            Object features = features(Path.of(args[3]), Path.of(args[4]));
            Tensor latent = (Tensor) invoke(model, "sample", new Class[]{features.getClass(), SanaSprint.Options.class},
                    features, new SanaSprint.Options(64, 64, 2, 4.5f, 42, dtype));
            write(out.resolve("latent.f32"), latent.toFloatArray());
            var image = (java.awt.image.BufferedImage) invoke(model, "decode", new Class[]{Tensor.class, DType.class}, latent, dtype);
            ImageIO.write(image, "png", out.resolve("frame-0.png").toFile());
        }
        Tensor.backend().releaseResources();
        DeepJExecutor.shutdown();
    }

    private static Object features(Path data, Path mask) throws Exception {
        var type = Class.forName(SanaSprint.class.getName() + "$PromptFeatures");
        var constructor = type.getDeclaredConstructor(float[].class, int[].class, int[].class);
        constructor.setAccessible(true);
        ByteBuffer bytes = ByteBuffer.wrap(Files.readAllBytes(data)).order(ByteOrder.LITTLE_ENDIAN);
        float[] values = new float[bytes.remaining() / 4];
        bytes.asFloatBuffer().get(values);
        var metadata = io.github.kirstenali.deepj.persistence.qwen3.Qwen3Json.read(mask);
        int[] valid = ((java.util.List<?>) metadata.get("mask")).stream().mapToInt(v -> ((Number) v).intValue()).toArray();
        return constructor.newInstance(values, new int[]{1, valid.length, 2304}, valid);
    }

    private static Object invoke(Object value, String name, Class<?>[] types, Object... args) throws Exception {
        Method method = value.getClass().getDeclaredMethod(name, types);
        method.setAccessible(true);
        return method.invoke(value, args);
    }

    private static void write(Path path, float[] values) throws Exception {
        ByteBuffer bytes = ByteBuffer.allocate(values.length * 4).order(ByteOrder.LITTLE_ENDIAN);
        bytes.asFloatBuffer().put(values);
        Files.write(path, bytes.array());
    }
}
