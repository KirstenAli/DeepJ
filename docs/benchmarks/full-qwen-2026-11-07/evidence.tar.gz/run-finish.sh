#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/full-qwen-performance"
repo="$root/work/deepj-qwen-thinking"
py="$root/outputs/cpu-throughput/reference-env/bin/python"
export JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
export VECLIB_MAXIMUM_THREADS=10
export PYTHONPATH="$repo/src/test/python"
export TOKENIZERS_PARALLELISM=false
has_idea() { /bin/ps -axo comm | /usr/bin/awk '/IntelliJ IDEA.app/{found=1} END{exit !found}'; }
for attempt in {1..120}; do
  if ! has_idea; then break; fi
  sleep 1
done
if has_idea; then exit 3; fi
sleep 5
"$py" "$root/outputs/cpu-throughput/run_guarded.py" --log "$out/improved-deepj-cpu.jsonl" --timeout 180 --rss-gib 11 --swap-mib 128 -- \
  "$JAVA_HOME/bin/java" -Xmx10g --enable-native-access=ALL-UNNAMED \
  -cp "$out/improved.jar:$repo/target/test-classes" io.github.kirstenali.deepj.nn.transformer.qwen3.Qwen3Benchmark \
  /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B cpu FLOAT32 \
  "$root/outputs/qwen3-1p7b/benchmark-input.json" 10 8 5
sleep 3
"$py" "$root/outputs/cpu-throughput/run_guarded.py" --log "$out/loaded-pytorch-mps.jsonl" --timeout 180 --rss-gib 11 --swap-mib 128 -- \
  "$py" "$out/matched_reference.py" /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B mps \
  "$root/outputs/qwen3-1p7b/benchmark-input.json" || printf 'MPS_REFERENCE_STOPPED\n'
printf 'COMPARISON_DONE\n'
cd "$repo"
/opt/homebrew/bin/mvn -o --batch-mode -Pfull-coverage verify > "$out/full-verify.log" 2>&1
printf 'VERIFY_DONE\n'
