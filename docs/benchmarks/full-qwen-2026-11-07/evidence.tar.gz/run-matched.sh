#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/full-qwen-performance"
repo="$root/work/deepj-qwen-thinking"
py="$root/outputs/cpu-throughput/reference-env/bin/python"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
export VECLIB_MAXIMUM_THREADS=10
export PYTHONPATH="$repo/src/test/python"
export TOKENIZERS_PARALLELISM=false
has_idea() { /bin/ps -axo comm | /usr/bin/awk '/IntelliJ IDEA.app/{found=1} END{exit !found}'; }
for attempt in {1..120}; do
  if ! has_idea; then break; fi
  sleep 1
done
if has_idea; then exit 3; fi
sleep 5
bash "$out/inspect-host.sh"
for backend in cpu metal; do
  "$py" "$root/outputs/cpu-throughput/run_guarded.py" --log "$out/final-deepj-$backend.jsonl" --timeout 180 --rss-gib 11 --swap-mib 128 -- \
    "$java" -Xmx10g -Xlog:gc:file="$out/final-deepj-$backend-gc.log" --enable-native-access=ALL-UNNAMED \
    -cp "$root/outputs/qwen-inference-optimizations/final.jar:$out/classes" \
    io.github.kirstenali.deepj.nn.transformer.qwen3.Qwen3Benchmark \
    /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B "$backend" FLOAT32 \
    "$root/outputs/qwen3-1p7b/benchmark-input.json" 10 8 5
  sleep 3
done
for backend in cpu mps; do
  "$py" "$root/outputs/cpu-throughput/run_guarded.py" --log "$out/final-pytorch-$backend.jsonl" --timeout 180 --rss-gib 11 --swap-mib 128 -- \
    "$py" "$out/matched_reference.py" /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B "$backend" \
    "$root/outputs/qwen3-1p7b/benchmark-input.json"
  sleep 3
done
printf 'FULL_MODEL_COMPARISON_DONE\n'
