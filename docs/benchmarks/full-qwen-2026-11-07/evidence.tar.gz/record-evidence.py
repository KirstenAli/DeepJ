import hashlib
import json
import statistics
import tarfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
out = root / 'outputs/full-qwen-performance'
repo = root / 'work/deepj-qwen-thinking'
doc = repo / 'docs/benchmarks/full-qwen-2026-11-07'
doc.mkdir(parents=True, exist_ok=True)
files = {'DeepJ CPU': 'improved-deepj-cpu', 'DeepJ Metal': 'final-deepj-metal',
         'PyTorch CPU': 'final-pytorch-cpu', 'PyTorch MPS': 'gpu-converted-pytorch-mps'}
results = {}
for name, stem in files.items():
    records = [json.loads(line) for line in (out / (stem + '.jsonl')).read_text().splitlines() if line.startswith('{')]
    measured = [r for r in records if r.get('trial', -1) >= 0]
    results[name] = {'records': records, 'process': json.loads((out / (stem + '.metrics.json')).read_text()),
        'median_prefill_ms': statistics.median(r['prefill_seconds'] * 1000 for r in measured),
        'median_decode_tokens_per_second': statistics.median(r['tokens_per_second'] for r in measured)}
controls = {p.stem: json.loads(p.read_text()) for p in sorted(out.glob('control-*.json'))}
result = dict(deepj_cpu_commit='4ed97933', deepj_metal_commit='d5baf672', checkpoint_revision='70d244cc86ccca08cf5af4e1e306ecf908b1ad5e',
    platform='Apple M4, 16 GiB unified memory, macOS 15.5', java='Temurin 20.0.2', torch='2.8.0', transformers='4.51.3',
    dtype='FLOAT32', batch=1, warmups=8, measured_runs=5, cpu_threads=10,
    input=json.loads((root/'outputs/qwen3-1p7b/benchmark-input.json').read_text()),
    runtime_sha256=hashlib.sha256((out/'improved.jar').read_bytes()).hexdigest(), comparisons=results, training_controls=controls)
(doc/'results.json').write_text(json.dumps(result, indent=2)+'\n')
with tarfile.open(doc/'evidence.tar.gz', 'w:gz') as archive:
    for pattern in ['*.sh','*.py','*.java','*.log','*.jsonl','*.metrics.json']:
        for p in sorted(out.glob(pattern)): archive.add(p, arcname=p.name)
    for p in sorted((out/'aborted-memory-check').glob('*')): archive.add(p, arcname='aborted-memory-check/'+p.name)
    for p in sorted((out/'startup-overlap-controls').glob('*')): archive.add(p, arcname='startup-overlap-controls/'+p.name)
    for name in ['qwen3_benchmark.py','qwen3_cpu_benchmark.py']:
        archive.add(repo/'src/test/python'/name, arcname='reference/'+name)
    archive.add(repo/'src/test/java/io/github/kirstenali/deepj/nn/transformer/qwen3/Qwen3Benchmark.java', arcname='Qwen3Benchmark.java')
    archive.add(root/'outputs/qwen-inference-optimizations/QuickProbe.java', arcname='QuickProbe.java')
    archive.add(root/'outputs/qwen3-1p7b/benchmark-input.json', arcname='benchmark-input.json')
print(json.dumps({k:{key:value for key,value in v.items() if key.startswith('median')} for k,v in results.items()}, indent=2))
