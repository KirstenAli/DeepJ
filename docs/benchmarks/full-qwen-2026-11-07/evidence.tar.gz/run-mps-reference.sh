#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/full-qwen-performance"
repo="$root/work/deepj-qwen-thinking"
py="$root/outputs/cpu-throughput/reference-env/bin/python"
export JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
export VECLIB_MAXIMUM_THREADS=10
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH="$repo/src/test/python"
has_idea() { /bin/ps -axo comm | /usr/bin/awk '/IntelliJ IDEA.app/{found=1} END{exit !found}'; }
for attempt in {1..120}; do
  if ! has_idea && /usr/bin/grep -q 'BUILD SUCCESS' "$out/full-verify.log"; then break; fi
  sleep 1
done
if has_idea || ! /usr/bin/grep -q 'BUILD SUCCESS' "$out/full-verify.log"; then exit 3; fi
sleep 5
"$py" "$root/outputs/cpu-throughput/run_guarded.py" --log "$out/gpu-converted-pytorch-mps.jsonl" --timeout 120 --rss-gib 10 --swap-mib 128 -- \
  "$py" "$out/matched_reference.py" /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B mps \
  "$root/outputs/qwen3-1p7b/benchmark-input.json" || printf 'REFERENCE_STOPPED\n'
printf 'MPS_REFERENCE_DONE\n'
