package io.github.kirstenali.deepj.nn.transformer.qwen3;

import io.github.kirstenali.deepj.concurrent.DeepJExecutor;
import io.github.kirstenali.deepj.persistence.qwen3.Qwen3Json;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.cpu.CpuBackend;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;
import java.nio.file.Path;
import java.util.*;

public final class PrefillProbe {
    private PrefillProbe() {}
    public static void main(String[] args) throws Exception {
        boolean metal = args[1].equals("metal"), profile = !args[3].equals("plain");
        TensorBackend actual = metal ? new MetalBackend() : new CpuBackend();
        var observer = new StageProfiler(actual);
        Tensor.setBackend(args[3].equals("profile") ? observer.proxy() : actual);
        DeepJExecutor.setNumThreads(10);
        Qwen3 model = Qwen3Pretrained.load(Path.of(args[0]), DType.valueOf(args[2]));
        var input = Qwen3Json.read(Path.of(args[0], "input.json"));
        int[] prompt = ids(input.get("prompt")), decode = ids(input.get("decode"));
        try {
            for (int warm = 0; warm < 40; warm++) { trial(model, prompt, decode); }
            measure(model, prompt, decode, observer, metal, profile, args);
        } finally { Tensor.backend().releaseResources(); DeepJExecutor.shutdown(); }
    }

    private static void measure(Qwen3 model, int[] prompt, int[] decode, StageProfiler profiler,
                                 boolean metal, boolean profile, String[] args) {
        double[] prefill = new double[9], decoding = new double[9];
        for (int run = 0; run < prefill.length; run++) {
            double[] time = trial(model, prompt, decode);
            prefill[run] = time[0];
            decoding[run] = time[1];
        }
        emit(Map.of("kind", "timing", "backend", args[1], "weight_dtype", args[2], "mode", args[3],
                "prefill_ms", prefill, "decode_ms", decoding, "warmups", 40));
        if (profile) for (int i = 0; i < 5; i++) stages(model, prompt, decode, profiler, metal);
    }

    private static double[] trial(Qwen3 model, int[] prompt, int[] decode) {
        try (var session = model.openGeneration()) {
            long start = System.nanoTime();
            session.apply(prompt).toFloatArray();
            double prefill = (System.nanoTime() - start) / 1e6;
            int[] context = Arrays.copyOf(prompt, prompt.length + decode.length);
            start = System.nanoTime();
            for (int token = 0; token < decode.length; token++) {
                context[prompt.length + token] = decode[token];
                session.apply(Arrays.copyOf(context, prompt.length + token + 1)).toFloatArray();
                Tensor.backend().releaseTemporaryResources();
            }
            return new double[]{prefill, (System.nanoTime() - start) / 1e6};
        }
    }

    private static void stages(Qwen3 model, int[] prompt, int[] decode, StageProfiler profiler, boolean metal) {
        try (var session = model.openGeneration()) {
            reset(profiler, metal);
            long start = System.nanoTime();
            float[] result = session.apply(prompt).toFloatArray();
            finish(profiler, metal, "prefill", start, result);
            int[] context = Arrays.copyOf(prompt, prompt.length + 1);
            context[prompt.length] = decode[0];
            reset(profiler, metal);
            start = System.nanoTime();
            result = session.apply(context).toFloatArray();
            finish(profiler, metal, "decode_one_token", start, result);
        }
    }

    private static void reset(StageProfiler profiler, boolean metal) {
        profiler.reset();

        profiler.enabled = true;
    }

    private static void finish(StageProfiler profiler, boolean metal, String phase, long start, float[] output) {
        double wall = (System.nanoTime() - start) / 1e6;
        profiler.enabled = false;
        long[] nativeTimes = new long[0];
        emit(Map.of("kind", "stages", "phase", phase, "wall_ms", wall, "operations", profiler.report(),
                "native", nativeTimes, "logits", output));
    }

    private static int[] ids(Object value) {
        return Qwen3Json.array(value).stream().mapToInt(item -> Math.toIntExact(Qwen3Json.integer(item))).toArray();
    }

    private static Object normalize(Object value) {
        if (value instanceof Map<?, ?> map) {
            var result = new LinkedHashMap<String, Object>();
            map.forEach((key, item) -> result.put(key.toString(), normalize(item)));
            return result;
        }
        if (value != null && value.getClass().isArray()) {
            var result = new ArrayList<Object>();
            for (int i = 0; i < java.lang.reflect.Array.getLength(value); i++) result.add(java.lang.reflect.Array.get(value, i));
            return result;
        }
        return value;
    }

    private static void emit(Map<String, ?> value) {
        System.out.println(Qwen3Json.stringify(normalize(value)));
    }
}
