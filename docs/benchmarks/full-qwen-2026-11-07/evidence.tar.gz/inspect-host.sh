#!/bin/bash
set -euo pipefail
out=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/full-qwen-performance
/bin/ps -axo pid,rss,pcpu,etime,comm | /usr/bin/sort -nrk2 | /usr/bin/awk 'NR <= 18' > "$out/processes.txt"
/usr/sbin/sysctl vm.swapusage > "$out/swap.txt"
/usr/bin/memory_pressure > "$out/pressure.txt"
