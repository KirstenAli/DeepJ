import json
import statistics
from pathlib import Path
root = Path(__file__).parent
for path in sorted(root.glob('*.jsonl')):
    samples = [json.loads(line) for line in path.read_text().splitlines() if line.startswith('{')]
    trials = [s for s in samples if s.get('trial', -1) >= 0]
    if not trials:
        print(path.name, 'waiting for measured trials')
        continue
    print(path.name, 'n=',len(trials), 'prefill_ms=', round(1000*statistics.median(s['prefill_seconds'] for s in trials),3),
          'decode_tps=', round(statistics.median(s['tokens_per_second'] for s in trials),3),
          'checksums=',[s['checksum'] for s in trials])
