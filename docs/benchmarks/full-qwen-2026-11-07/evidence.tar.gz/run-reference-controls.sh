#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/full-qwen-performance"
repo="$root/work/deepj-qwen-thinking"
py="$root/outputs/cpu-throughput/reference-env/bin/python"
export JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
export VECLIB_MAXIMUM_THREADS=10
export PYTHONPATH="$repo/src/test/python"
has_idea() { /bin/ps -axo comm | /usr/bin/awk '/IntelliJ IDEA.app/{found=1} END{exit !found}'; }
for attempt in {1..120}; do
  if ! has_idea && /usr/bin/grep -q 'BUILD SUCCESS' "$out/full-verify.log"; then break; fi
  sleep 1
done
if has_idea || ! /usr/bin/grep -q 'BUILD SUCCESS' "$out/full-verify.log"; then exit 3; fi
sleep 5
"$py" "$root/outputs/cpu-throughput/run_guarded.py" --log "$out/device-loaded-pytorch-mps.jsonl" --timeout 120 --rss-gib 10 --swap-mib 128 -- \
  "$py" "$out/matched_reference.py" /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B mps \
  "$root/outputs/qwen3-1p7b/benchmark-input.json" || printf 'REFERENCE_STOPPED\n'
for backend in cpu metal; do
 for model in qwen loop prism; do
  for variant in before after; do
   jar="$root/outputs/qwen-inference-optimizations/final.jar"
   if [ "$variant" = after ]; then jar="$out/improved.jar"; fi
   "$JAVA_HOME/bin/java" -Xmx1g -Xbatch -XX:CompileThresholdScaling=0.1 \
    -Dprobe.warmups=100 -Dprobe.samples=30 --enable-native-access=ALL-UNNAMED \
    -cp "$jar:$root/outputs/qwen-inference-optimizations" QuickProbe "$backend" "$model" training \
    > "$out/control-$backend-$model-$variant.json"
  done
 done
done
printf 'REFERENCE_AND_CONTROLS_DONE\n'
