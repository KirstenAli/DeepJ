"""Bounded, matched Gemma 2 inference reference using the local SANA text encoder."""
import gc,json,sys,time
from pathlib import Path
import numpy as np
import torch,transformers
from safetensors import safe_open
from transformers import Gemma2Config,Gemma2ForCausalLM,HybridCache
from transformers.models.gemma2.modeling_gemma2 import Gemma2RotaryEmbedding
root=Path(sys.argv[1]);name=sys.argv[2];inputs=Path(sys.argv[3]);output=Path(sys.argv[4])
if name not in ('FLOAT16','BFLOAT16'): name,inputs=sys.argv[3],Path(sys.argv[2])
dtype={'FLOAT16':torch.float16,'BFLOAT16':torch.bfloat16}[name]
torch.set_num_threads(10);torch.set_num_interop_threads(1)
config=Gemma2Config.from_pretrained(root,local_files_only=True)
config._attn_implementation='eager'
start=time.perf_counter()
with torch.device('meta'): model=Gemma2ForCausalLM(config)
files=sorted(set(json.loads((root/'model.safetensors.index.json').read_text())['weight_map'].values()))
for filename in files:
    with safe_open(root/filename,framework='pt',device='cpu') as shard: keys=list(shard.keys())
    for key in keys:
        with safe_open(root/filename,framework='pt',device='cpu') as shard:
            value=shard.get_tensor(key).to(device='mps',dtype=dtype)
        target=key if key.startswith('model.') or key=='lm_head.weight' else 'model.'+key
        model.load_state_dict({target:value},strict=False,assign=True)
        del value
        torch.mps.synchronize();torch.mps.empty_cache()
model.tie_weights();model.requires_grad_(False).eval()
model.model.rotary_emb=Gemma2RotaryEmbedding(config,device='mps')
assert not any(p.is_meta or p.dtype!=dtype or p.device.type!='mps' for p in model.parameters())
print(json.dumps(dict(engine='PyTorch',torch=torch.__version__,transformers=transformers.__version__,dtype=name,
    load_seconds=time.perf_counter()-start,parameters=sum(p.numel() for p in model.parameters()),attention='eager')),flush=True)
data=json.loads(inputs.read_text())
@torch.inference_mode()
def run(number,stream=None):
    cache=HybridCache(config=config,max_batch_size=1,max_cache_len=128,device='mps',dtype=dtype)
    position=0;check=0;prefill=0;decode_start=0
    for index,tokens in enumerate([data['prompt']]+[[token] for token in data['decode']]):
        start=time.perf_counter()
        result=model(torch.tensor([tokens],device='mps'),past_key_values=cache,use_cache=True,logits_to_keep=1,
            cache_position=torch.arange(position,position+len(tokens),device='mps'))
        values=result.logits[0,-1].float().cpu().numpy().copy()
        position+=len(tokens);check+=float(values[0])
        if stream is not None: values.tofile(stream)
        if index==0: prefill=time.perf_counter()-start;decode_start=time.perf_counter()
    elapsed=time.perf_counter()-decode_start
    if stream is None:print(json.dumps(dict(trial=number,dtype=name,prefill_seconds=prefill,
        decode_seconds=elapsed,tokens_per_second=len(data['decode'])/elapsed,checksum=check)),flush=True)
for number in range(-3,3):run(number)
with output.open('wb') as stream:run(99,stream)
