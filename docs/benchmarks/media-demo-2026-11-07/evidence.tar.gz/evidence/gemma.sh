#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/media-demo-2026-11-07"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
python="$root/outputs/cpu-throughput/reference-env/bin/python"
model="$root/outputs/sana-sprint-readme/model"
current="$root/outputs/demo-compact/verified-candidate.jar"
baseline="$root/outputs/compact-followup/combined-candidate.jar"
codec=/Users/kirstenali/.m2/repository/org/jcodec
extras="$codec/jcodec/0.2.5/jcodec-0.2.5.jar:$codec/jcodec-javase/0.2.5/jcodec-javase-0.2.5.jar"
export PYTORCH_ENABLE_MPS_FALLBACK=0
export VECLIB_MAXIMUM_THREADS=10

for dtype in BFLOAT16 FLOAT16; do
 for engine in current pytorch baseline; do
  if [[ -f "$out/stop.flag" ]]; then exit 130; fi
  if [[ "$engine" == pytorch ]]; then
   command=("$python" -B "$out/gemma_reference.py" "$model/text_encoder" "$dtype"
    "$out/gemma-input-$dtype.json" "$out/gemma-$dtype-$engine.bin")
  else
   jar="$current"; if [[ "$engine" == baseline ]]; then jar="$baseline"; fi
   command=("$java" -Xmx7g -Ddeepj.metal.maxBufferBytes=7516192768 --enable-native-access=ALL-UNNAMED
    -cp "$out/classes:$jar" GemmaDemoProbe "$model/text_encoder" "$dtype"
    "$out/gemma-input-$dtype.json" "$out/gemma-$dtype-$engine.bin")
  fi
  "$python" "$out/run_guarded.py" --stop-file "$out/stop.flag" --log "$out/gemma-$dtype-$engine.jsonl" \
   --timeout 90 --rss-gib 9 --swap-mib 128 -- "${command[@]}"
  echo "GEMMA_COMPLETE $dtype $engine"
 done
done
