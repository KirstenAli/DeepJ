import io.github.kirstenali.deepj.concurrent.DeepJExecutor;
import io.github.kirstenali.deepj.nn.transformer.ContextWindowMode;
import io.github.kirstenali.deepj.nn.transformer.gemma2.Gemma2ChatModel;
import io.github.kirstenali.deepj.persistence.qwen3.Qwen3Json;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;
import io.github.kirstenali.deepj.tokenizers.gemma.Gemma2Chat;
import java.nio.*;
import java.nio.file.*;
import java.util.*;

public final class GemmaDemoProbe {
    private static final String PROMPT = "Explain in two sentences how a neural network learns from examples.";
    public static void main(String[] args) throws Exception {
        if (!MetalBackend.isAvailable()) throw new IllegalStateException("Physical Metal required");
        Tensor.setBackend(new MetalBackend()); DeepJExecutor.setNumThreads(10);
        long start = System.nanoTime();
        var chat = Gemma2ChatModel.load(Path.of(args[0]), DType.valueOf(args[1]));
        int[] prompt = chat.tokenizer().encode(Gemma2Chat.format(PROMPT,List.of()));
        int[] continuation = chat.tokenizer().encode(" A neural network learns by adjusting its weights to reduce errors on examples.".repeat(3));
        int[] decode = Arrays.copyOfRange(continuation,1,17);
        Files.writeString(Path.of(args[2]),Qwen3Json.stringify(Map.of("prompt",ids(prompt),"decode",ids(decode),"text",PROMPT)));
        System.out.println(Qwen3Json.stringify(Map.of("load_seconds",seconds(start),"dtype",args[1],"backend","metal")));
        try {
            for(int trial=-Integer.getInteger("probe.warmup",3);trial<Integer.getInteger("probe.runs",3);trial++) trial(chat,prompt,decode,trial);
            if (!Boolean.getBoolean("probe.short")) { audit(chat,prompt,decode,Path.of(args[3])); stream(chat); }
        } finally { chat.model().close(); Tensor.backend().releaseTemporaryResources(); DeepJExecutor.shutdown(); }
    }
    private static void trial(Gemma2ChatModel chat,int[] prompt,int[] decode,int number) {
        try(var session=chat.model().openGeneration()) {
            long start=System.nanoTime(); float checksum=session.apply(prompt).toFloatArray()[0]; double prefill=seconds(start);
            int[] context=Arrays.copyOf(prompt,prompt.length+decode.length); start=System.nanoTime();
            for(int i=0;i<decode.length;i++) {
                context[prompt.length+i]=decode[i];
                checksum+=session.apply(Arrays.copyOf(context,prompt.length+i+1)).toFloatArray()[0];
                Tensor.backend().releaseTemporaryResources();
            }
            double elapsed=seconds(start);
            System.out.println(Qwen3Json.stringify(Map.of("trial",number,"dtype",chat.model().parameters().get(0).value.dtype().name(),
                "prefill_seconds",prefill,"decode_seconds",elapsed,"tokens_per_second",decode.length/elapsed,"checksum",checksum)));
        }
    }
    private static void audit(Gemma2ChatModel chat,int[] prompt,int[] decode,Path output) throws Exception {
        try(var session=chat.model().openGeneration();var file=Files.newOutputStream(output)) {
            int[] context=Arrays.copyOf(prompt,prompt.length+decode.length);
            for(int i=0;i<=decode.length;i++) {
                if(i>0) context[prompt.length+i-1]=decode[i-1];
                float[] values=session.apply(Arrays.copyOf(context,prompt.length+i)).toFloatArray();
                var buffer=ByteBuffer.allocate(values.length*4).order(ByteOrder.LITTLE_ENDIAN);
                buffer.asFloatBuffer().put(values); file.write(buffer.array());
                Tensor.backend().releaseTemporaryResources();
            }
        }
    }
    private static void stream(Gemma2ChatModel chat) {
        var stamps=new ArrayList<Long>();long start=System.nanoTime();
        String reply=chat.stream(PROMPT,List.of(),64,.7f,1,42,1,ContextWindowMode.REBUILD,text->stamps.add(System.nanoTime()));
        int count=stamps.size();
        System.out.println(Qwen3Json.stringify(Map.of("kind","chat","reply",reply,"tokens",count,
            "first_token_ms",count==0?0:(stamps.get(0)-start)/1e6,
            "tokens_per_second",count<2?0:(count-1)/((stamps.get(count-1)-stamps.get(0))/1e9))));
    }
    private static List<Integer> ids(int[] tokens) { return Arrays.stream(tokens).boxed().toList(); }
    private static double seconds(long start) { return (System.nanoTime()-start)/1e9; }
}
