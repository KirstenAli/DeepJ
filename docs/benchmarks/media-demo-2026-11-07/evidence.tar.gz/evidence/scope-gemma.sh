#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/media-demo-2026-11-07"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
python="$root/outputs/cpu-throughput/reference-env/bin/python"
model="$root/outputs/sana-sprint-readme/model"
current="$root/outputs/demo-compact/verified-candidate.jar"
baseline="$root/outputs/compact-followup/combined-candidate.jar"
codec=/Users/kirstenali/.m2/repository/org/jcodec
extras="$codec/jcodec/0.2.5/jcodec-0.2.5.jar:$codec/jcodec-javase/0.2.5/jcodec-javase-0.2.5.jar"
export PYTORCH_ENABLE_MPS_FALLBACK=0
export VECLIB_MAXIMUM_THREADS=10


"$python" "$out/run_guarded.py" --stop-file "$out/stop.flag" --log "$out/scope-smoke.log" \
 --timeout 30 --rss-gib 2 --swap-mib 128 -- "$java" -Xmx512m --enable-native-access=ALL-UNNAMED \
 -cp "$out/classes:$out/scope-candidate.jar" GemmaBatchSmoke "$root/work/deepj-qwen-thinking/src/test/resources/gemma2"
"$python" "$out/run_guarded.py" --stop-file "$out/stop.flag" --log "$out/gemma-BFLOAT16-scope.jsonl" \
 --timeout 90 --rss-gib 9 --swap-mib 128 -- "$java" -Xmx3g -Ddeepj.metal.maxBufferBytes=7516192768 \
 --enable-native-access=ALL-UNNAMED -cp "$out/classes:$out/scope-candidate.jar" \
 GemmaDemoProbe "$model/text_encoder" BFLOAT16 "$out/gemma-input-BFLOAT16.json" "$out/gemma-BFLOAT16-scope.bin"
