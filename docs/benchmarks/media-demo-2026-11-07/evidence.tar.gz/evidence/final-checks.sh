#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/media-demo-2026-11-07"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
python="$root/outputs/cpu-throughput/reference-env/bin/python"
model="$root/outputs/sana-sprint-readme/model"
export JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
export PYTORCH_ENABLE_MPS_FALLBACK=0
export VECLIB_MAXIMUM_THREADS=10
cd "$root/work/deepj-qwen-thinking"
"$python" "$out/run_guarded.py" --stop-file "$out/stop.flag" --log "$out/gemma-metal-tests.log" --timeout 90 --rss-gib 3 --swap-mib 128 -- /opt/homebrew/bin/mvn -o test '-Dtest=Gemma2*Test,ModelInferenceTest' -Dgemma.test.metal=true
"$python" "$out/run_guarded.py" --stop-file "$out/stop.flag" --log "$out/gemma-BFLOAT16-profile.jsonl" --timeout 60 --rss-gib 9 --swap-mib 128 -- "$java" -Xmx3g -Ddeepj.metal.maxBufferBytes=7516192768 -Dprobe.short=true -Dprobe.warmup=2 -Dprobe.runs=1 --enable-native-access=ALL-UNNAMED -cp "$out/classes:$out/profile-candidate.jar" GemmaDemoProbe "$model/text_encoder" BFLOAT16 "$out/gemma-input-BFLOAT16.json" "$out/unused.bin"
"$python" "$out/run_guarded.py" --stop-file "$out/stop.flag" --log "$out/gemma-FLOAT16-scope.jsonl" --timeout 90 --rss-gib 9 --swap-mib 128 -- "$java" -Xmx3g -Ddeepj.metal.maxBufferBytes=7516192768 --enable-native-access=ALL-UNNAMED -cp "$out/classes:$out/scope-candidate.jar" GemmaDemoProbe "$model/text_encoder" FLOAT16 "$out/gemma-input-FLOAT16.json" "$out/gemma-FLOAT16-scope.bin"
"$python" "$out/run_guarded.py" --stop-file "$out/stop.flag" --log "$out/gemma-FLOAT16-pytorch.jsonl" --timeout 60 --rss-gib 9 --swap-mib 128 -- "$python" -B "$out/gemma_reference.py" "$model/text_encoder" "$out/gemma-input-FLOAT16.json" FLOAT16 "$out/gemma-FLOAT16-pytorch.bin"
codec=/Users/kirstenali/.m2/repository/org/jcodec
extras="$codec/jcodec/0.2.5/jcodec-0.2.5.jar:$codec/jcodec-javase/0.2.5/jcodec-javase-0.2.5.jar"
"$python" "$out/run_guarded.py" --stop-file "$out/stop.flag" --log "$out/image-fp32-check.log" --timeout 180 --rss-gib 10 --swap-mib 128 -- "$java" -Xmx3g -Ddeepj.metal.maxBufferBytes=8589934592 --enable-native-access=ALL-UNNAMED -cp "$out/classes:$out/scope-candidate.jar:$extras" MediaDemoProbe image "$model" "$out/image-fp32-check" FLOAT32
echo FINAL_CHECKS_PASSED
