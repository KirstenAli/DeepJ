#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/media-demo-2026-11-07"
"$root/outputs/cpu-throughput/reference-env/bin/python" "$out/run_guarded.py" --stop-file "$out/stop.flag" --log "$out/offset-check.log" --timeout 30 --rss-gib 2 --swap-mib 128 -- /Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java -Xmx512m --enable-native-access=ALL-UNNAMED -cp "$out/classes:$out/fixed-candidate.jar" CompactOffsetProbe
