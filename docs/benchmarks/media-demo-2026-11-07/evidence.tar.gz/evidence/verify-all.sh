#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/media-demo-2026-11-07"
export JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
cd "$root/work/deepj-qwen-thinking"
/opt/homebrew/bin/mvn -o test '-Dtest=MetalCompactGraphTest,ModelRmsTest,Gemma2*Test,ModelInferenceTest' -Dgemma.test.metal=true > "$out/fixed-metal-tests.log" 2>&1
bash "$out/media-verified.sh"
/opt/homebrew/bin/mvn -o test > "$out/full-tests.log" 2>&1
echo ALL_VERIFICATION_PASSED
