#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/media-demo-2026-11-07"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
python="$root/outputs/cpu-throughput/reference-env/bin/python"
model="$root/outputs/sana-sprint-readme/model"
current="$root/outputs/demo-compact/verified-candidate.jar"
baseline="$root/outputs/compact-followup/combined-candidate.jar"
codec=/Users/kirstenali/.m2/repository/org/jcodec
extras="$codec/jcodec/0.2.5/jcodec-0.2.5.jar:$codec/jcodec-javase/0.2.5/jcodec-javase-0.2.5.jar"
export PYTORCH_ENABLE_MPS_FALLBACK=0
export VECLIB_MAXIMUM_THREADS=10


for phase in image-bf16-check scope-gemma; do
 if ! bash "$out/quiet.sh" "$out/$phase.sh" > "$out/$phase-run.log" 2>&1; then echo "PHASE_FAILED $phase"; fi
 if [[ -f "$out/resumed-state.txt" ]]; then cp "$out/resumed-state.txt" "$out/$phase-resumed-state.txt"; fi
 echo "PHASE_DONE $phase"
done
