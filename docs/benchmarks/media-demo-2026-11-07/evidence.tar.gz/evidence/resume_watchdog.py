import os
import signal
import sys
import time

time.sleep(600)
for value in sys.argv[1:]:
    try:
        os.kill(int(value), signal.SIGCONT)
    except ProcessLookupError:
        pass
