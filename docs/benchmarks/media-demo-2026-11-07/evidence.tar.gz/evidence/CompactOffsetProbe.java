import io.github.kirstenali.deepj.autograd.GradMode;
import io.github.kirstenali.deepj.nn.ModelOps;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;
import java.util.*;
public final class CompactOffsetProbe {
 public static void main(String[] args) {
  Tensor.setBackend(new MetalBackend());
  try(var ignored=GradMode.noGrad()) {
   for(DType dtype:DType.values()) offsets(dtype);
   for(DType dtype:new DType[]{DType.FLOAT16,DType.BFLOAT16}) normalization(dtype);
  }
 }
 private static void offsets(DType dtype) {
  Random random=new Random(12);float[] av=new float[5*256],bv=new float[256*256];
  for(int i=0;i<av.length;i++) av[i]=random.nextFloat()-.5f;
  for(int i=0;i<bv.length;i++) bv[i]=random.nextFloat()-.5f;
  Tensor a=Tensor.from(av,dtype,1,5,256).retainDeviceBuffer();
  Tensor b=Tensor.from(bv,dtype,256,256).transpose(-1,-2).retainDeviceBuffer();
  Tensor row=a.slice(1,4,5);float[] expected=row.copy().matmul(b).toFloatArray();
  float[] actual=row.matmul(b).toFloatArray();double max=0;
  for(int i=0;i<actual.length;i++)max=Math.max(max,Math.abs(actual[i]-expected[i]));
  System.out.println("OFFSET "+dtype+" max "+max+" actual0 "+actual[0]+" expected0 "+expected[0]);
  a.releaseDeviceBufferRetention();b.releaseDeviceBufferRetention();Tensor.backend().releaseTemporaryResources();
 }
 private static void normalization(DType dtype) {
  Tensor a=Tensor.from(new float[2304],dtype,1,1,2304).retainDeviceBuffer();
  Tensor gain=Tensor.from(new float[2304],dtype,2304).retainDeviceBuffer();
  for(int run=0;run<4;run++) {
   long start=System.nanoTime();
   try(var buffers=BackwardBuffers.begin()) {
    Tensor value=buffers.capture(()->{Tensor v=a;for(int i=0;i<105;i++)v=ModelOps.rms(v,gain,null,1e-6f,true);return v;});
    value.toFloatArray();
   }
   System.out.println("RMS105 "+dtype+" ms "+(System.nanoTime()-start)/1e6);Tensor.backend().releaseTemporaryResources();
  }
  a.releaseDeviceBufferRetention();gain.releaseDeviceBufferRetention();Tensor.backend().releaseTemporaryResources();
 }
}
