#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/media-demo-2026-11-07"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
python="$root/outputs/cpu-throughput/reference-env/bin/python"
model="$root/outputs/sana-sprint-readme/model"
export JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
export PYTORCH_ENABLE_MPS_FALLBACK=0
export VECLIB_MAXIMUM_THREADS=10
cd "$root/work/deepj-qwen-thinking"
/opt/homebrew/bin/mvn -o test '-Dtest=MetalCompactGraphTest,ModelRmsTest,Gemma2*Test,ModelInferenceTest' -Dgemma.test.metal=true pmd:check pmd:cpd-check > "$out/final-metal-tests.log" 2>&1
for dtype in BFLOAT16 FLOAT16; do
 "$python" "$out/run_guarded.py" --stop-file "$out/stop.flag" --log "$out/gemma-$dtype-final.jsonl" --timeout 90 --rss-gib 9 --swap-mib 128 -- "$java" -Xmx3g -Ddeepj.metal.maxBufferBytes=7516192768 --enable-native-access=ALL-UNNAMED -cp "$out/classes:$out/fixed-candidate.jar" GemmaDemoProbe "$model/text_encoder" "$dtype" "$out/gemma-input-$dtype.json" "$out/gemma-$dtype-final.bin"
 "$python" "$out/run_guarded.py" --stop-file "$out/stop.flag" --log "$out/gemma-$dtype-reference-final.jsonl" --timeout 60 --rss-gib 9 --swap-mib 128 -- "$python" -B "$out/gemma_reference.py" "$model/text_encoder" "$dtype" "$out/gemma-input-$dtype.json" "$out/gemma-$dtype-reference-final.bin"
done
codec=/Users/kirstenali/.m2/repository/org/jcodec
extras="$codec/jcodec/0.2.5/jcodec-0.2.5.jar:$codec/jcodec-javase/0.2.5/jcodec-javase-0.2.5.jar"
"$python" "$out/run_guarded.py" --stop-file "$out/stop.flag" --log "$out/image-verified-bf16.log" --timeout 150 --rss-gib 9 --swap-mib 128 -- "$java" -Xmx3g -Ddeepj.metal.maxBufferBytes=6442450944 --enable-native-access=ALL-UNNAMED -cp "$out/classes:$out/fixed-candidate.jar:$extras" MediaDemoProbe image "$model" "$out/image-verified-bf16" BFLOAT16
echo FINAL_DEMO_CHECKS_PASSED
