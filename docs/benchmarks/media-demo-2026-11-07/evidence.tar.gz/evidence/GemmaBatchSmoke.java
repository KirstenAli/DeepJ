import io.github.kirstenali.deepj.autograd.GradMode;
import io.github.kirstenali.deepj.nn.ModelInference;
import io.github.kirstenali.deepj.nn.transformer.gemma2.Gemma2Pretrained;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;
import java.nio.file.Path;
import java.util.Arrays;
public class GemmaBatchSmoke {
 public static void main(String[] args)throws Exception {
  Tensor.setBackend(new MetalBackend());
  for(DType type:DType.values()) {
   try(var model=Gemma2Pretrained.load(Path.of(args[0]),type);var ignored=GradMode.noGrad()) {
    int[] tokens={2,3,4,5}; float[] expected=model.forward(tokens).toFloatArray();
    for(int n=0;n<4;n++) {
     float[] actual=ModelInference.batch(()->model.forward(tokens)).toFloatArray();
     if(!Arrays.equals(expected,actual))throw new AssertionError("Batched output differs: "+type);
     Tensor.backend().releaseTemporaryResources();
    }
    try(var session=model.openGeneration()) { session.apply(tokens).toFloatArray();session.apply(new int[]{2,3,4,5,6}).toFloatArray(); }
   }
   System.out.println("BATCH_SMOKE_PASSED "+type);
  }
  io.github.kirstenali.deepj.concurrent.DeepJExecutor.shutdown();
 }
}
