#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/media-demo-2026-11-07"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
python="$root/outputs/cpu-throughput/reference-env/bin/python"
model="$root/outputs/sana-sprint-readme/model"
current="$root/outputs/demo-compact/verified-candidate.jar"
baseline="$root/outputs/compact-followup/combined-candidate.jar"
codec=/Users/kirstenali/.m2/repository/org/jcodec
extras="$codec/jcodec/0.2.5/jcodec-0.2.5.jar:$codec/jcodec-javase/0.2.5/jcodec-javase-0.2.5.jar"
export PYTORCH_ENABLE_MPS_FALLBACK=0
export VECLIB_MAXIMUM_THREADS=10

for variant in current-fp32 current-bf16 baseline-fp32; do
 if [[ -f "$out/stop.flag" ]]; then exit 130; fi
 jar="$current"; dtype=FLOAT32
 if [[ "$variant" == current-bf16 ]]; then dtype=BFLOAT16; fi
 if [[ "$variant" == baseline-fp32 ]]; then jar="$baseline"; fi
 "$python" "$out/run_guarded.py" --stop-file "$out/stop.flag" --log "$out/image-$variant.log" \
  --timeout 150 --rss-gib 9 --swap-mib 128 -- "$java" -Xmx7g \
  -Ddeepj.metal.maxBufferBytes=6442450944 --enable-native-access=ALL-UNNAMED \
  -cp "$out/classes:$jar:$extras" MediaDemoProbe image "$model" "$out/image-$variant" "$dtype"
 echo "FOX_IMAGE_COMPLETE $variant"
done
