# Flash attention qualification, declared before execution

Candidate: FP32 one-pass online-softmax attention, query-block parallel forward,
deterministic query-owned and key-owned backward reductions. No mixed precision,
atomics, optimizer changes, new model weights, or real-training checkpoint writes.
Baseline: d879b55c, existing parallel blocked MPS attention. Unsupported shapes
and devices continue through the unfused backend path.

## Numerical contract

* Independent double-precision forward and dQ/dK/dV reference, including 9/12
  heads at length 1024, causal boundaries, zero/negative scales and saturation.
  Keep the pre-existing output bound 2e-5 + 2e-4*abs(reference), derivative bound
  3e-5 + 5e-4*abs(reference). Reference derivatives also need finite differences.
* Preserve exact repeated execution and causal isolation checks. Cross-algorithm
  bit equality is not a correctness gate: prior FP64 investigation reproduced
  its failure, with cancellation-sensitive near-zero gradients amplified by Adam.
* All five architectures: three small-model updates; existing loss comparison
  bound 2e-4 + 2e-4*abs(reference), global gradient relative L2 <= 1e-3 and global
  weight relative L2 <= 1e-4. Record maxima as diagnostics, reject nonfinite values.
  These are explicit new cross-algorithm gates, not assertions of identical weights.

## Real-data qualification

* TinyStories train/validation are separate files, tokenized with the existing
  Frisky 16384-vocabulary BPE tokenizer. No ByteTokenizer substitution.
* 200 updates per variant/model/seed, seeds 100, 101, 102; batch 1, context 1024,
  AdamW learning rate 1e-4. Identical initialization and precomputed batches per
  paired run. Fixed eight-batch validation before training and every 50 updates.
* Full-size Prism 90M, Nova 100M and Loop 100M; bounded two-layer Origin/Orbit
  configurations. Clearly distinguish these sizes in the report.
* Every loss/gradient norm finite. Compare each held-out checkpoint with absolute
  loss difference <= 0.01 nats (about 1% perplexity); paired mean training loss
  difference <= 0.01 nats. Record all per-step differences; investigate sustained
  drift, explosions and any violation, not just a favorable final checkpoint.
* Check heap/GC and process peak memory for retention or pressure. A 200-update
  check is not a claim about month-long convergence or endurance.

## Performance, quality and release gate

* Fresh JVMs, matched settings, alternating old/new order, warmed-up timings,
  at least three samples per variant for full-size Prism/Nova/Loop. No competing
  GPU jobs. Report median step times, peak footprint/RSS, heap/GC and swap activity.
* Investigate median regressions >3% or peak-footprint regressions >5%; require
  a repeatable speed benefit in the primary full-size training cases.
* Complete Maven/Java/frontend/native checks and coverage without lowering their
  thresholds. Review source/binary alignment, fallbacks and test discovery.
* Raise a PR only after qualification passes. Attach the evidence and disclose
  rounding differences and scope limitations. Do not merge or release.
