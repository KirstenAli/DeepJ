#!/bin/zsh
set -euo pipefail
qualRoot=${0:A:h}
qualJdk=$(/usr/libexec/java_home -v 20)
qualPhase=PREPARING
trap 'result=$?; if (( result != 0 )); then print -r -- "FAILED phase=$qualPhase exit=$result" > "$qualRoot/status.txt"; fi' EXIT

progress() {
    qualPhase=$1
    print -r -- "$qualPhase" > "$qualRoot/status.txt"
}

build() {
    progress "FULL BUILD $1"
    (cd "$qualRoot/candidate" && JAVA_HOME="$qualJdk" /opt/homebrew/bin/mvn -o clean verify -Pfull-coverage) \
        > "$qualRoot/logs/$1-coverage.txt" 2>&1
}

prepare() {
    build initial
    "$qualJdk/bin/javac" -cp "$qualRoot/candidate/target/classes" -d "$qualRoot/harness" \
        "$qualRoot"/Qualification*.java
    "$qualJdk/bin/java" -Xmx1g -cp "$qualRoot/candidate/target/classes:$qualRoot/harness" \
        QualificationData <LOCAL_HOME>/IdeaProjects/DeepJ "$qualRoot/data" \
        > "$qualRoot/logs/data.txt" 2>&1
    shasum -a 256 "$qualRoot"/{baseline,candidate}/src/main/resources/native/macos/libdeepj_metal_jni.dylib \
        > "$qualRoot/logs/libraries.txt"
}

run_case() {
    local stem=$1 variant=$2 model=$3 main=$4
    shift 4
    local heap=8g log="$qualRoot/logs/$stem.txt"
    [[ "$model" == prism ]] && heap=6g
    [[ ! -e "$log" ]] || { print -u2 "Refusing to replace existing evidence: $log"; return 1; }
    progress "RUNNING $stem"
    vm_stat > "$qualRoot/logs/$stem-vm-before.txt"
    /usr/bin/time -l "$qualJdk/bin/java" -Xmx$heap -XX:+ExitOnOutOfMemoryError \
        --enable-native-access=ALL-UNNAMED -cp "$qualRoot/$variant/target/classes:$qualRoot/harness" \
        "$main" "$model" "$@" > "$log" 2>&1
    vm_stat > "$qualRoot/logs/$stem-vm-after.txt"
    /usr/bin/grep -q '^RESULT ' "$log"
}

training() {
    for seed in 100 101 102; do
        local order=(baseline candidate)
        [[ "$seed" == 101 ]] && order=(candidate baseline)
        for model in origin orbit prism nova loop; do
            for variant in $order; do
                run_case "$model-$seed-$variant" "$variant" "$model" QualificationTraining "$seed" "$qualRoot/data"
            done
        done
    done
    "$qualRoot/candidate/target/node/node" "$qualRoot/analyse.mjs" training \
        > "$qualRoot/logs/training-analysis.txt" 2>&1
}

timing() {
    for model in prism nova loop; do
        for round in 1 2 3; do
            local order=(baseline candidate)
            [[ "$round" == 2 ]] && order=(candidate baseline)
            for variant in $order; do
                run_case "timing-$model-$round-$variant" "$variant" "$model" QualificationTiming
            done
        done
    done
    "$qualRoot/candidate/target/node/node" "$qualRoot/analyse.mjs" timing \
        > "$qualRoot/logs/timing-analysis.txt" 2>&1
}

prepare
training
timing
build final
progress 'ALL QUALIFICATION, TIMING AND FINAL BUILD CHECKS PASSED'
