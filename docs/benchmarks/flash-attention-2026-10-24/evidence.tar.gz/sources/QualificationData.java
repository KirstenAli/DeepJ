import io.github.kirstenali.deepj.data.Batch;
import io.github.kirstenali.deepj.data.RandomAccessTextDataset;
import io.github.kirstenali.deepj.tokenizers.bpe.BPEModelIO;
import io.github.kirstenali.deepj.tokenizers.bpe.BPETokenizer;
import java.io.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;

/** Private precomputed token batches; never include these binaries in public evidence. */
final class QualificationData {
    static final int LENGTH = 1024;
    private QualificationData() {}

    public static void main(String[] args) throws Exception {
        Path project = Path.of(args[0]), output = Path.of(args[1]);
        var tokenizer = new BPETokenizer(BPEModelIO.load(
                project.resolve("checkpoints/deepj-90m/pretrain/tokenizer.bpe")));
        if (tokenizer.vocabSize() != 16_384) throw new AssertionError("Unexpected tokenizer vocabulary");
        Files.createDirectories(output);
        for (int seed : new int[]{100, 101, 102}) {
            sample(project.resolve("sample_data/TinyStories-train.txt"), tokenizer,
                    output.resolve("train-" + seed + ".bin"), 200, 2026 + seed);
        }
        sample(project.resolve("sample_data/TinyStories-valid.txt"), tokenizer,
                output.resolve("validation.bin"), 8, 2027);
    }

    private static void sample(Path corpus, BPETokenizer tokenizer, Path file,
                                int count, long seed) throws Exception {
        try (var dataset = new RandomAccessTextDataset(corpus, tokenizer, LENGTH, seed);
             var output = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(file,
                     StandardOpenOption.CREATE_NEW)))) {
            output.writeInt(count);
            for (int index = 0; index < count; index++) write(output, dataset.nextBatch(1));
        }
        String hash = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(file)));
        System.out.printf("DATA file=%s batches=%d seed=%d sha256=%s%n", file.getFileName(), count, seed, hash);
    }

    private static void write(DataOutputStream output, Batch batch) throws IOException {
        for (int value : batch.x()[0]) output.writeInt(value);
        for (int value : batch.y()[0]) output.writeInt(value);
    }

    static List<Batch> read(Path file, int count) throws IOException {
        try (var input = new DataInputStream(new BufferedInputStream(Files.newInputStream(file)))) {
            if (input.readInt() != count) throw new IOException("Wrong batch count: " + file);
            List<Batch> result = new ArrayList<>();
            for (int index = 0; index < count; index++) {
                result.add(new Batch(new int[][]{sequence(input)}, new int[][]{sequence(input)}));
            }
            if (input.read() != -1) throw new IOException("Unexpected trailing batch data");
            return result;
        }
    }

    private static int[] sequence(DataInputStream input) throws IOException {
        int[] values = new int[LENGTH];
        for (int index = 0; index < values.length; index++) {
            values[index] = input.readInt();
            if (values[index] < 0 || values[index] >= 16_384) throw new IOException("Invalid token");
        }
        return values;
    }

    static Batch synthetic(Random random) {
        int[] input = new int[LENGTH], target = new int[LENGTH];
        int previous = random.nextInt(16_384);
        for (int index = 0; index < LENGTH; index++) {
            input[index] = previous;
            previous = random.nextInt(16_384);
            target[index] = previous;
        }
        return new Batch(new int[][]{input}, new int[][]{target});
    }
}
