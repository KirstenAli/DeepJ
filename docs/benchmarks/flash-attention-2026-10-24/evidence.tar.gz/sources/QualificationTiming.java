import io.github.kirstenali.deepj.tensor.Tensor;
import io.github.kirstenali.deepj.training.CausalLMTraining;
import io.github.kirstenali.deepj.training.Trainer;
import java.util.Arrays;
import java.util.Random;

public final class QualificationTiming {
    private QualificationTiming() {}

    public static void main(String[] args) {
        QualificationModels.requireMetal();
        try {
            benchmark(args[0]);
        } finally {
            Tensor.backend().releaseResources();
        }
    }

    private static void benchmark(String name) {
        var model = QualificationModels.create(name, 100);
        var random = new Random(2026);
        var trainer = CausalLMTraining.trainer(model, ignored -> QualificationData.synthetic(random), 1e-4f);
        rounds(trainer, "warmup", 10);
        double[] seconds = rounds(trainer, "measured", 30);
        Arrays.sort(seconds);
        System.out.printf("RESULT model=%s parameters=%d medianSeconds=%.9f%n",
                name, QualificationModels.parameters(model), (seconds[14] + seconds[15]) / 2);
    }

    private static double[] rounds(Trainer trainer, String phase, int count) {
        double[] seconds = new double[count];
        for (int round = 0; round < count; round++) {
            long start = System.nanoTime();
            float loss = trainer.trainStep(1);
            Tensor.backend().releaseTemporaryResources();
            seconds[round] = (System.nanoTime() - start) / 1e9;
            QualificationTelemetry.finite(loss);
            System.out.printf("STEP phase=%s round=%d loss=%.9g seconds=%.9f %s%n",
                    phase, round, loss, seconds[round], QualificationTelemetry.snapshot());
        }
        return seconds;
    }
}
