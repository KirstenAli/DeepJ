import io.github.kirstenali.deepj.autograd.GradMode;
import io.github.kirstenali.deepj.data.Batch;
import io.github.kirstenali.deepj.loss.CrossEntropyLoss;
import io.github.kirstenali.deepj.models.DecoderOnlyModel;
import io.github.kirstenali.deepj.tensor.Tensor;
import io.github.kirstenali.deepj.training.CausalLMTraining;
import io.github.kirstenali.deepj.training.Trainer;
import java.nio.file.Path;
import java.util.List;

public final class QualificationTraining {
    private QualificationTraining() {}

    public static void main(String[] args) throws Exception {
        QualificationModels.requireMetal();
        try {
            train(args[0], Integer.parseInt(args[1]), Path.of(args[2]));
        } finally {
            Tensor.backend().releaseResources();
        }
    }

    private static void train(String name, int seed, Path data) throws Exception {
        var training = QualificationData.read(data.resolve("train-" + seed + ".bin"), 200);
        var validation = QualificationData.read(data.resolve("validation.bin"), 8);
        var model = QualificationModels.create(name, seed);
        int[] cursor = {0};
        var trainer = CausalLMTraining.trainer(model, ignored -> training.get(cursor[0]++), 1e-4f);
        System.out.printf("START model=%s seed=%d parameters=%d batch=1 sequence=1024%n",
                name, seed, QualificationModels.parameters(model));
        validate(model, validation, 0);
        for (int step = 1; step <= 200; step++) {
            update(model, trainer, step);
            if (step % 50 == 0) validate(model, validation, step);
        }
        System.out.printf("RESULT model=%s seed=%d steps=200%n", name, seed);
    }

    private static void update(DecoderOnlyModel model, Trainer trainer, int step) {
        long started = System.nanoTime();
        float loss = trainer.trainStep(1);
        QualificationTelemetry.finite(loss);
        if (step % 50 == 0) gradient(model, step);
        Tensor.backend().releaseTemporaryResources();
        double seconds = (System.nanoTime() - started) / 1e9;
        System.out.printf("TRAIN step=%d loss=%.9g seconds=%.6f %s%n",
                step, loss, seconds, QualificationTelemetry.snapshot());
    }

    private static void gradient(DecoderOnlyModel model, int step) {
        var gradients = model.parameters().stream().map(parameter -> parameter.grad())
                .filter(value -> value != null).toList();
        float norm = Tensor.backend().l2Norm(gradients);
        QualificationTelemetry.finite(norm);
        if (norm <= 0) throw new AssertionError("Gradient measurement must precede GPU cleanup");
        System.out.printf("GRADIENT step=%d norm=%.9g%n", step, norm);
    }

    private static void validate(DecoderOnlyModel model, List<Batch> batches, int step) {
        double sum = 0;
        try (var ignored = GradMode.noGrad()) {
            for (Batch batch : batches) {
                sum += CrossEntropyLoss.loss(model.forward(batch.x()[0]), batch.y()[0]);
                Tensor.backend().releaseTemporaryResources();
            }
        }
        double loss = sum / batches.size();
        QualificationTelemetry.finite(loss);
        System.out.printf("VALIDATION step=%d loss=%.12g perplexity=%.12g tokens=%d%n",
                step, loss, Math.exp(loss), batches.size() * 1024);
    }
}
