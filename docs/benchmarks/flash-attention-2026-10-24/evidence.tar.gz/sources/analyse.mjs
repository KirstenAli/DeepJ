import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const mean = (values) => values.reduce((sum, value) => sum + value, 0) / values.length;
const median = (values) => values.toSorted((a, b) => a - b)[Math.floor(values.length / 2)];

function fields(line) {
  return Object.fromEntries([...line.matchAll(/(\w+)=([^ ]+)/g)].map(([, key, value]) =>
    [key, Number.isNaN(Number(value)) ? value : Number(value)]));
}

function log(stem) {
  const text = readFileSync(join(root, 'logs', stem + '.txt'), 'utf8');
  assert.ok(!/Exception|OutOfMemory|SIGSEGV|NaN|Infinity|Terminating|AssertionError/.test(text), stem);
  const rows = (prefix) => text.split('\n').filter((line) => line.startsWith(prefix)).map(fields);
  assert.equal(rows('RESULT ').length, 1, stem + ': missing success');
  return { rows, footprint: Number(text.match(/(\d+)\s+peak memory footprint/)[1]),
    rss: Number(text.match(/(\d+)\s+maximum resident set size/)[1]) };
}

function trainingRun(stem) {
  const result = log(stem), train = result.rows('TRAIN '), validation = result.rows('VALIDATION ');
  const gradients = result.rows('GRADIENT ');
  assert.deepEqual(train.map((row) => row.step), Array.from({ length: 200 }, (_, index) => index + 1));
  assert.deepEqual(validation.map((row) => row.step), [0, 50, 100, 150, 200]);
  assert.deepEqual(gradients.map((row) => row.step), [50, 100, 150, 200]);
  assert.ok(gradients.every((row) => Number.isFinite(row.norm) && row.norm > 0));
  assert.ok(train.every((row) => Number.isFinite(row.loss) && row.seconds > 0));
  return { ...result, train, validation, gradients, start: result.rows('START ')[0] };
}

function trainingPair(model, seed) {
  const old = trainingRun(`${model}-${seed}-baseline`), next = trainingRun(`${model}-${seed}-candidate`);
  assert.deepEqual(old.start, next.start);
  const validation = old.validation.map((row, index) => ({ step: row.step, baseline: row.loss,
    candidate: next.validation[index].loss, delta: next.validation[index].loss - row.loss }));
  const deltas = old.train.map((row, index) => next.train[index].loss - row.loss);
  const maxValidationDelta = Math.max(...validation.map((row) => Math.abs(row.delta)));
  assert.ok(maxValidationDelta <= .01, `${model}/${seed}: validation delta ${maxValidationDelta}`);
  assert.ok(Math.abs(mean(deltas)) <= .01, `${model}/${seed}: mean training delta ${mean(deltas)}`);
  return { model, seed, parameters: old.start.parameters, validation, maxValidationDelta,
    meanTrainingDelta: mean(deltas), maxTrainingDelta: Math.max(...deltas.map(Math.abs)), deltas,
    baselineFootprint: old.footprint, candidateFootprint: next.footprint,
    baselineRss: old.rss, candidateRss: next.rss,
    baselineFinal: old.train.at(-1), candidateFinal: next.train.at(-1),
    baselineGradients: old.gradients, candidateGradients: next.gradients };
}

function training() {
  const results = [];
  for (const model of ['origin', 'orbit', 'prism', 'nova', 'loop']) {
    for (const seed of [100, 101, 102]) results.push(trainingPair(model, seed));
  }
  save('training', results);
  console.log('PASS: 30 complete runs, 6000 updates, 150 held-out measurements.');
  console.log('Maximum held-out delta:', Math.max(...results.map((row) => row.maxValidationDelta)));
}

function timingRun(model, round, variant) {
  const stem = `timing-${model}-${round}-${variant}`, result = log(stem);
  const steps = result.rows('STEP ').filter((row) => row.phase === 'measured');
  assert.equal(steps.length, 30);
  const swaps = (phase) => Number(readFileSync(join(root, 'logs', `${stem}-vm-${phase}.txt`),
    'utf8').match(/Swapouts:\s*(\d+)/)[1]);
  return { round, variant, seconds: result.rows('RESULT ')[0].medianSeconds,
    footprint: result.footprint, rss: result.rss, systemSwapoutPages: swaps('after') - swaps('before') };
}

function timingPair(model) {
  const baseline = [1, 2, 3].map((round) => timingRun(model, round, 'baseline'));
  const candidate = [1, 2, 3].map((round) => timingRun(model, round, 'candidate'));
  const old = median(baseline.map((row) => row.seconds));
  const next = median(candidate.map((row) => row.seconds));
  const footprintRatio = median(candidate.map((row) => row.footprint)) /
    median(baseline.map((row) => row.footprint));
  return { model, baseline, candidate, baselineMedian: old, candidateMedian: next,
    stepTimeReductionPercent: 100 * (1 - next / old), throughputGainPercent: 100 * (old / next - 1),
    footprintChangePercent: 100 * (footprintRatio - 1) };
}

function timing() {
  const results = ['prism', 'nova', 'loop'].map(timingPair);
  save('timing', results);
  for (const result of results) {
    console.log(JSON.stringify(result));
    assert.ok(result.stepTimeReductionPercent >= -3, `${result.model}: speed regression`);
    assert.ok(result.footprintChangePercent <= 5, `${result.model}: memory regression`);
    assert.ok(result.stepTimeReductionPercent >= 5, `${result.model}: repeatable benefit not established`);
  }
  console.log('PASS: all 18 matched timing cases meet the speed and footprint gates.');
}

function save(name, result) {
  writeFileSync(join(root, name + '-summary.json'), JSON.stringify(result, null, 2) + '\n');
}

if (process.argv[2] === 'training') training();
else if (process.argv[2] === 'timing') timing();
else throw new Error('Expected training or timing');
