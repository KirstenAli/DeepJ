import io.github.kirstenali.deepj.models.DecoderOnlyModel;
import io.github.kirstenali.deepj.models.origin.*;
import io.github.kirstenali.deepj.models.orbit.*;
import io.github.kirstenali.deepj.models.prism.*;
import io.github.kirstenali.deepj.models.nova.*;
import io.github.kirstenali.deepj.models.loop.*;
import io.github.kirstenali.deepj.tensor.Tensor;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;

final class QualificationModels {
    private QualificationModels() {}

    static void requireMetal() {
        if (!MetalBackend.isAvailable()) throw new IllegalStateException("Metal is required");
        Tensor.setBackend(new MetalBackend());
    }

    static DecoderOnlyModel create(String name, long seed) {
        return switch (name) {
            case "origin" -> new DeepJOrigin(new DeepJOriginConfig(16_384, 1024, 128, 2, 2, 256), seed);
            case "orbit" -> new DeepJOrbit(new DeepJOrbitConfig(16_384, 1024, 128, 2, 2, 256), seed);
            case "prism" -> new DeepJPrism(new DeepJPrismConfig(
                    16_384, 1024, 768, 12, 10, 2112, 384, 192, 0.2f, 1), seed);
            case "nova" -> new DeepJNova(new DeepJNovaConfig(
                    16_384, 1024, 576, 9, 3, 24, 1664, true, 0.2f, 1), seed);
            case "loop" -> new DeepJLoop(new DeepJLoopConfig(
                    16_384, 1024, 576, 9, 3, 6, 12, 6, 2, 1664), seed);
            default -> throw new IllegalArgumentException(name);
        };
    }

    static long parameters(DecoderOnlyModel model) {
        return model.parameters().stream().mapToLong(parameter -> parameter.value.data.length).sum();
    }
}
