import java.lang.management.ManagementFactory;

final class QualificationTelemetry {
    private QualificationTelemetry() {}

    static String snapshot() {
        var heap = ManagementFactory.getMemoryMXBean().getHeapMemoryUsage();
        long count = 0, milliseconds = 0;
        for (var collector : ManagementFactory.getGarbageCollectorMXBeans()) {
            count += Math.max(0, collector.getCollectionCount());
            milliseconds += Math.max(0, collector.getCollectionTime());
        }
        return "heapUsed=" + heap.getUsed() + " heapCommitted=" + heap.getCommitted()
                + " gcCount=" + count + " gcMillis=" + milliseconds;
    }

    static void finite(double value) {
        if (!Double.isFinite(value)) throw new AssertionError("Non-finite value: " + value);
    }
}
