# Flash attention validation investigation

24 October 2026. This investigates the failed validation, rather than using an
optional implementation as a substitute for explaining it. Scratch experiment:
`/private/tmp/deepj-flash-validation.aopfiS`. Libraries and Java classes were held
fixed from `/private/tmp/deepj-flash-revisit.ts22Bk`.

## Finding

The current failures measure reproduction of the legacy MPS rounding trajectory.
They are not sufficient evidence that Flash attention calculates the wrong
mathematical operation. Two new controls establish this distinction:

1. At the first failure of the two-pass exact-arithmetic test, the Flash result
   is the nearest FP32 value to the independent FP64 answer. The legacy value is
   one float away and less accurate. The exact test rejects the more accurate
   result at that element.
2. Substituting independent FP64 attention into the full-size scratch models,
   while keeping the remaining operations and optimizer unchanged, also fails
   the legacy updated-weight bound: 86 selected Prism weights and 2 Nova weights.

This explains why those gates can fail without establishing a kernel defect.
It does not prove every input or a long training run safe. All original tests,
tolerances, epsilon, clipping and production code are unchanged by this follow-up.
No existing failure was converted into a pass.

## Exact attention test, all heads

The exact failing fixture was reproduced: 12 heads, length 1024, width 64,
scale 0.125, original seeds 229/233/239/241. An independent scalar FP64 calculation
checked all 786,432 elements in each of output, dQ, dK and dV, for 3,145,728
values per implementation. It uses double scores, probabilities, products and
accumulations, with `StrictMath.exp`.

First rejected output in the two-pass implementation, flat index 128:

| Calculation | Value | Absolute error from FP64 |
| --- | ---: | ---: |
| Independent FP64 | 0.1526084382245670 | Reference |
| Legacy MPS | 0.1526084542274475 | 1.60029e-8 |
| Two-pass Flash | 0.1526084393262863 | 1.10172e-9 |

The Flash value is also the nearest representable float to the FP64 answer.
The exact test requires the legacy value regardless of that accuracy comparison.
The one-pass first mismatch at index 71 is also closer to FP64 than the legacy
value, although neither is the nearest float there.

All-head relative L2 errors against the independent reference:

| Quantity | Current MPS | Two-pass Flash | One-pass Flash |
| --- | ---: | ---: | ---: |
| Output | 2.19884e-7 | 2.23858e-7 | 2.24991e-7 |
| dQ | 2.85965e-7 | 2.93798e-7 | 2.94462e-7 |
| dK | 7.53822e-7 | 7.57972e-7 | 7.59410e-7 |
| dV | 7.53591e-7 | 7.55273e-7 | 7.55273e-7 |

All three passed the existing independent per-element accuracy bounds: output
`2e-5 + 2e-4*abs(reference)`, gradients `3e-5 + 5e-4*abs(reference)`.
The Flash implementations are not uniformly more accurate; the aggregate errors
above are slightly larger. Counting bit differences is therefore not the same
as measuring mathematical error. The current MPS result remains bit-identical
to its unfused MPS reference throughout this fixture.

## Trace of the updated-weight failure

Eight fresh full-size scratch training runs were traced: Prism and Nova, each
with current MPS, two-pass Flash, one-pass Flash and the independent FP64 attention
control. Initialization seed 100, synthetic input seed 2026, sequence 1024,
batch 1, original model configurations and AdamW settings were retained.

The same seven selected parameter arrays were compared, not every model weight.
The legacy bound remains `2e-6 + 2e-4*abs(reference)`.

| Implementation | Prism outliers | Nova outliers |
| --- | ---: | ---: |
| Current MPS | 0 | 0 |
| Two-pass Flash | 84 | 0 |
| One-pass Flash | 82 | 4 |
| Independent FP64 attention control | 86 | 2 |

The first three rows reproduce the prior diagnostic counts and worst values.
The current MPS controls reproduce their archived reference exactly.
The FP64 control changes only attention, rounding back to float at the tensor
boundary. All other layers, global clipping and AdamW remain FP32. It is not a
full FP64 model and must not be described as one.

For each of the 56 selected arrays across these eight runs, the worst weight
was replayed through the unchanged Metal AdamW operation using its recorded
initial value and clipped gradient. Both the old and new weight matched their
replay bit for bit. Thus the optimizer's response to the changed gradients
accounts for those recorded weight differences; this was not an unexplained
weight write or optimizer configuration change.

### Largest two-pass Prism outlier

Parameter 9 is the first block's feed-forward gate projection, shape 768x2112.
Its flat index 252607 is the largest selected two-pass weight difference:

| Quantity | Legacy MPS | Two-pass Flash | FP64 attention control |
| --- | ---: | ---: | ---: |
| Gradient after clipping | +1.44002343383e-9 | -2.34952368672e-9 | -2.18119744488e-9 |
| Updated weight | 0.0149850808084 | 0.0150166936219 | 0.0150155751035 |

All begin with weight `0.0149976834655`. The Flash result is closer to the FP64
attention control in this particular worst case. Other elements do not all
favor Flash, so this example is not a claim of universally better gradients.

Captured matrix operands allow the raw gradient's 1024-term dot product to be
recomputed independently in FP64. In the legacy run, the sum of absolute terms
is `0.0352742052296642`, but their signed sum is only `1.08185703299763e-8`:
positive and negative contributions cancel by a factor of about 3.26 million.
The actual MPS raw gradient is `9.46228873033306e-9` after FP32 reduction.

Recomputing the candidate dot with its own captured operands gives
`-1.52125981436988e-8`; the candidate's MPS raw gradient is
`-1.54385482176167e-8`. Both use the same MPS parameter-gradient multiplication.
The independently decomposed change is:

- Changed upstream gradient: `-2.60632247358230e-8`.
- Changed forward activation: `+3.20548815087968e-11`.
- Product of both changes: `+1.38111549022275e-15`.
- Different local FP32 rounding accounts for the remaining difference between
  the two FP64 dot sums and the two actual raw gradients.

The upstream change dominates this outlier. The final matrix multiplication
does not have to be wrong for the near-zero result to change sign. The original
clipping scale then reduces the gradients; AdamW with epsilon `1e-8` amplifies
their difference into a weight difference of `3.16128135e-5`.

On the first optimizer step, the idealized bias-corrected Adam contribution is
`learningRate * g / (abs(g) + epsilon)`. This is very sensitive when `g` is near
epsilon or zero. The bit-exact replay uses the real implementation, not just
that simplified equation. No epsilon change or gradient clamping was made.

The analogous largest one-pass Prism outlier is parameter 13, index 914600,
in the first feed-forward down projection. Its legacy dot has a cancellation
factor of about 3.69 million. Its difference is also dominated by the changed
upstream gradient. Per-outlier decompositions for the captured matrix gradients
are preserved in `dot-analysis.json`.

## Validation of the diagnostic reference

The independent reference's q/k/v derivatives also passed 108 central finite
difference checks, covering length 7/33, zero/positive/negative scales,
saturated logits, causal boundaries and three perturbation sizes. The scalar
objective was evaluated in FP64, and the denominator used the actual float
input perturbation. Bounds were `1e-7 + 2e-5*abs(analytic derivative)`.

This supplements the earlier candidate finite-difference, independent-oracle,
determinism and short TinyStories checks. It does not replace the longer,
multi-seed training qualification still needed for a production decision.

## Consequence for acceptance

The demonstrated issue is the use of legacy arithmetic reproduction as a
universal correctness requirement. Preserve exact-repeat tests for the same
implementation, and preserve the exact MPS comparison for the MPS path. A
different attention algorithm should be qualified against independently
computed outputs/derivatives, finite differences, mathematical invariants,
repeatability, full-model gradient statistics and held-out training behavior.

Do not simply widen every tolerance until Flash passes. Before changing the
formal acceptance contract, choose and document the accuracy/training bounds,
then test all five architectures and multiple seeds against them. Existing
short-run loss agreement alone is insufficient for a complete rollout claim.

This follow-up found no new kernel or optimizer defect explaining the traced
failures. It established a concrete rounding/cancellation/Adam mechanism and
demonstrated that higher-precision attention also fails the legacy weight gate.
It does not assert that every Flash case is now qualified. No production
selection, PR, merge, release, real checkpoint or training process was changed.

## Evidence

`sources/` contains the Java diagnostic tools and zsh runners. `logs/` contains
all completed results. `outliers/` contains the small synthetic-value CSVs.
`summary.json` verifies completion and aggregates the unchanged outlier counts.
Raw scratch matrix captures remain only in the temporary experiment directory;
they are excluded from the portable evidence to avoid unnecessary duplication.
