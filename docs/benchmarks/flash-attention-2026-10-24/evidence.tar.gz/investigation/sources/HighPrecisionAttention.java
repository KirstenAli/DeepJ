import io.github.kirstenali.deepj.tensor.*;

/** Independent FP64 attention calculation, rounded only at the public tensor boundary. */
final class HighPrecisionAttention {
    private static final int WIDTH = 64;

    record Input(Tensor q, Tensor k, Tensor v, Tensor g, int heads, float scale) {
        int length() { return q.rows / heads; }
    }

    record Result(double[] output, double[] dq, double[] dk, double[] dv) {}

    private HighPrecisionAttention() {}

    static Result calculate(Input x) {
        int size = x.q.data.length;
        var result = new Result(new double[size], new double[size], new double[size], new double[size]);
        for (int head = 0; head < x.heads; head++) accumulateHead(x, result, head * x.length());
        return result;
    }

    private static void accumulateHead(Input x, Result result, int base) {
        for (int row = 0; row < x.length(); row++) {
            double[] p = probabilities(x, base, row);
            double[] dp = upstream(x, base, row);
            double delta = dot(p, dp);
            for (int column = 0; column <= row; column++) {
                double ds = p[column] * (dp[column] - delta) * x.scale;
                accumulate(x, result, base + row, base + column, p[column], ds);
            }
        }
    }

    static Tensor forward(Input x) {
        Tensor output = new Tensor(x.q.rows, WIDTH);
        for (int head = 0; head < x.heads; head++) forwardHead(x, output, head * x.length());
        return output;
    }

    private static void forwardHead(Input x, Tensor output, int base) {
        for (int row = 0; row < x.length(); row++) {
            double[] p = probabilities(x, base, row);
            for (int channel = 0; channel < WIDTH; channel++) {
                double value = 0;
                for (int column = 0; column <= row; column++) {
                    value += p[column] * x.v.data[(base + column) * WIDTH + channel];
                }
                output.data[(base + row) * WIDTH + channel] = (float) value;
            }
        }
    }

    private static double[] probabilities(Input x, int base, int row) {
        double[] p = new double[row + 1];
        double maximum = Double.NEGATIVE_INFINITY;
        for (int column = 0; column <= row; column++) {
            p[column] = dot(x.q, base + row, x.k, base + column) * x.scale;
            maximum = Math.max(maximum, p[column]);
        }
        double sum = exponentiate(p, maximum);
        for (int column = 0; column < p.length; column++) p[column] /= sum;
        return p;
    }

    private static double exponentiate(double[] p, double maximum) {
        double sum = 0;
        for (int column = 0; column < p.length; column++) {
            p[column] = StrictMath.exp(p[column] - maximum);
            sum += p[column];
        }
        return sum;
    }

    private static double[] upstream(Input x, int base, int row) {
        double[] dp = new double[row + 1];
        for (int column = 0; column <= row; column++) dp[column] = dot(x.g, base + row, x.v, base + column);
        return dp;
    }

    private static double dot(Tensor left, int row, Tensor right, int column) {
        double sum = 0;
        for (int c = 0; c < WIDTH; c++) sum += (double) left.data[row * WIDTH + c] * right.data[column * WIDTH + c];
        return sum;
    }

    private static double dot(double[] left, double[] right) {
        double sum = 0;
        for (int index = 0; index < left.length; index++) sum += left[index] * right[index];
        return sum;
    }

    private static void accumulate(Input x, Result result, int row, int col, double p, double ds) {
        for (int c = 0; c < WIDTH; c++) {
            int query = row * WIDTH + c, key = col * WIDTH + c;
            result.output[query] += p * x.v.data[key];
            result.dq[query] += ds * x.k.data[key];
            result.dk[key] += ds * x.q.data[query];
            result.dv[key] += p * x.g.data[query];
        }
    }

    static Tensor tensor(double[] source) {
        Tensor result = new Tensor(source.length / WIDTH, WIDTH);
        for (int index = 0; index < source.length; index++) result.data[index] = (float) source[index];
        return result;
    }
}
