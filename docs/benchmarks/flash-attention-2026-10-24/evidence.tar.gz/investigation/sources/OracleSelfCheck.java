import io.github.kirstenali.deepj.tensor.Tensor;
import io.github.kirstenali.deepj.tensor.cpu.CpuBackend;
import java.util.Random;

/** Finite differences independently check the diagnostic reference's backward formula. */
public final class OracleSelfCheck {
    private static int checks;
    private OracleSelfCheck() {}

    public static void main(String[] args) {
        check(7, 0, 1);
        check(7, 0.125f, 1);
        check(33, -0.5f, 1);
        check(33, 2, 8);
        System.out.printf("ORACLE FINITE DIFFERENCES PASSED checks=%d%n", checks);
    }

    private static void check(int length, float scale, float amplitude) {
        var cpu = new CpuBackend();
        Tensor q = cpu.multiplyScalar(cpu.random(length, 64, new Random(607)), amplitude);
        Tensor k = cpu.multiplyScalar(cpu.random(length, 64, new Random(613)), amplitude);
        Tensor v = cpu.random(length, 64, new Random(617)), g = cpu.random(length, 64, new Random(619));
        var input = new HighPrecisionAttention.Input(q, k, v, g, 1, scale);
        var result = HighPrecisionAttention.calculate(input);
        checkVariable(input, q, result.dq(), "q");
        checkVariable(input, k, result.dk(), "k");
        checkVariable(input, v, result.dv(), "v");
    }

    private static void checkVariable(HighPrecisionAttention.Input input, Tensor variable,
                                       double[] derivative, String name) {
        int[] indices = {3, variable.data.length / 2 + 7, variable.data.length - 1};
        for (int index : indices) {
            for (double step : new double[]{0.003, 0.001, 0.0003}) {
                double numerical = difference(input, variable, index, step);
                double error = Math.abs(derivative[index] - numerical);
                if (error > 1e-7 + 2e-5 * Math.abs(derivative[index])) {
                    throw new AssertionError(name + " index=" + index + " error=" + error);
                }
                checks++;
            }
        }
    }

    private static double difference(HighPrecisionAttention.Input input, Tensor variable, int index, double step) {
        float original = variable.data[index];
        float upper = (float) (original + step), lower = (float) (original - step);
        variable.data[index] = upper;
        double positive = objective(input);
        variable.data[index] = lower;
        double negative = objective(input);
        variable.data[index] = original;
        return (positive - negative) / ((double) upper - lower);
    }

    private static double objective(HighPrecisionAttention.Input input) {
        double[] output = HighPrecisionAttention.calculate(input).output();
        double value = 0;
        for (int index = 0; index < output.length; index++) value += output[index] * input.g().data[index];
        return value;
    }
}
