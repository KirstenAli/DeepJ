import io.github.kirstenali.deepj.tensor.Tensor;
import java.io.*;

final class TraceMath {
    private TraceMath() {}

    static float[] readArray(DataInputStream input) throws IOException {
        float[] result = new float[input.readInt()];
        for (int index = 0; index < result.length; index++) result[index] = input.readFloat();
        return result;
    }

    static void writeArray(DataOutputStream out, Tensor tensor) throws IOException {
        out.writeInt(tensor.rows); out.writeInt(tensor.cols);
        for (float value : tensor.data) out.writeFloat(value);
    }

    static int worst(float[] expected, float[] actual) {
        if (expected.length != actual.length) throw new AssertionError("Shape mismatch");
        int worst = 0;
        for (int index = 1; index < expected.length; index++) {
            if (Math.abs(actual[index] - expected[index]) > Math.abs(actual[worst] - expected[worst])) worst = index;
        }
        return worst;
    }

    static boolean outside(float expected, float actual) {
        return Math.abs((double) actual - expected) > 2e-6 + 2e-4 * Math.abs(expected);
    }

    static int outside(float[] expected, float[] actual) {
        int count = 0;
        for (int index = 0; index < expected.length; index++) if (outside(expected[index], actual[index])) count++;
        return count;
    }

    static boolean same(float a, float b) { return Float.floatToRawIntBits(a) == Float.floatToRawIntBits(b); }
}
