import io.github.kirstenali.deepj.autograd.GradMode;
import io.github.kirstenali.deepj.data.Batch;
import io.github.kirstenali.deepj.models.DecoderOnlyModel;
import io.github.kirstenali.deepj.models.nova.*;
import io.github.kirstenali.deepj.models.prism.*;
import io.github.kirstenali.deepj.optimisers.*;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;
import io.github.kirstenali.deepj.training.CausalLMTraining;
import java.io.*;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.nio.file.*;
import java.util.*;
import java.util.zip.GZIPInputStream;

/** Read-only tracing of scratch training. Never modifies kernels, gradients, or optimizer settings. */
public final class FlashWeightTrace implements InvocationHandler {
    private static final int[] SELECTED = {0, 4, 7, 8, 9, 11, 13};
    private final MetalBackend device = new MetalBackend();
    private final Map<Tensor, Integer> owners = new IdentityHashMap<>();
    private final Map<Tensor, Integer> upstreams = new IdentityHashMap<>();
    private final Map<Integer, Dot> dots = new HashMap<>();
    private final Map<Integer, float[]> initial = new HashMap<>();
    private final Path reference, directory;
    private final String profile;
    private final boolean oracle;
    private final AdamW optimizer = AdamW.defaultAdamW(1e-4f);

    private FlashWeightTrace(String[] args) throws IOException {
        profile = args[0];
        oracle = args.length > 3 && args[3].equals("oracle");
        reference = Path.of(args[1]);
        directory = Path.of(args[2]);
        Files.createDirectories(directory);
    }

    public static void main(String[] args) throws Exception {
        var trace = new FlashWeightTrace(args);
        trace.install();
        try { trace.run(); }
        finally { trace.device.releaseResources(); }
    }

    private void install() {
        Tensor.setBackend((TensorBackend) Proxy.newProxyInstance(TensorBackend.class.getClassLoader(),
                new Class<?>[]{TensorBackend.class, CausalAttentionBackend.class}, this));
    }

    private void run() {
        DecoderOnlyModel model = model();
        var params = model.parameters();
        for (int index : SELECTED) owners.put(params.get(index).value, index);
        float loss = CausalLMTraining.trainer(model, ignored -> batch(), this::update).trainStep(1);
        System.out.printf("TRACE COMPLETE profile=%s loss=%.12g capturedDots=%s%n", profile, loss, dots.keySet());
    }

    private DecoderOnlyModel model() {
        return profile.equals("prism") ? new DeepJPrism(new DeepJPrismConfig(
                16384, 1024, 768, 12, 10, 2112, 384, 192, 0.2f, 1), 100)
                : new DeepJNova(new DeepJNovaConfig(16384, 1024, 576, 9, 3, 24, 1664, true, 0.2f, 1), 100);
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        try {
            if (oracle && method.getName().equals("causalAttention")) return oracleForward(args);
            if (oracle && method.getName().equals("causalAttentionBackward")) return oracleBackward(args);
            Object result = method.invoke(device, args);
            if (method.getName().equals("batchedMatmul")) observeDot(args, (Tensor) result);
            return result;
        } catch (InvocationTargetException error) { throw error.getCause(); }
    }

    private CausalAttentionResult oracleForward(Object[] args) {
        Tensor q = (Tensor) args[0], k = (Tensor) args[1], v = (Tensor) args[2];
        q.materialize(); k.materialize(); v.materialize();
        var input = new HighPrecisionAttention.Input(q, k, v, null, (int) args[3], (float) args[4]);
        return new CausalAttentionResult(HighPrecisionAttention.forward(input), new Tensor(q.rows, 2));
    }

    private AttentionGradients oracleBackward(Object[] args) {
        Tensor q = (Tensor) args[0], k = (Tensor) args[1], v = (Tensor) args[2], g = (Tensor) args[4];
        q.materialize(); k.materialize(); v.materialize(); g.materialize();
        var input = new HighPrecisionAttention.Input(q, k, v, g, (int) args[5], (float) args[6]);
        var result = HighPrecisionAttention.calculate(input);
        return new AttentionGradients(HighPrecisionAttention.tensor(result.dq()),
                HighPrecisionAttention.tensor(result.dk()), HighPrecisionAttention.tensor(result.dv()));
    }

    private void observeDot(Object[] args, Tensor result) {
        if ((int) args[2] != 1 || GradMode.isEnabled()) return;
        Tensor left = (Tensor) args[0], right = (Tensor) args[1];
        if (!(boolean) args[3] && (boolean) args[4] && owners.containsKey(right)) {
            upstreams.put(left, owners.get(right));
        }
        if ((boolean) args[3] && !(boolean) args[4] && upstreams.containsKey(right)) {
            dots.put(upstreams.get(right), new Dot(left, right, result));
        }
    }

    private void update(List<Parameter> params) {
        for (int index : SELECTED) {
            params.get(index).value.materialize();
            initial.put(index, params.get(index).value.data.clone());
        }
        optimizer.step(params);
        try (var input = new DataInputStream(new GZIPInputStream(Files.newInputStream(reference)))) {
            for (int index : SELECTED) inspect(input, index, params.get(index));
            if (input.read() != -1) throw new AssertionError("Unconsumed reference data");
        } catch (IOException error) { throw new UncheckedIOException(error); }
    }

    private void inspect(DataInputStream input, int index, Parameter parameter) throws IOException {
        float[] referenceGradient = TraceMath.readArray(input);
        float[] referenceWeight = TraceMath.readArray(input);
        parameter.grad().materialize();
        parameter.value.materialize();
        float[] gradient = parameter.grad().data, weight = parameter.value.data;
        int worst = TraceMath.worst(referenceWeight, weight);
        System.out.printf("PARAMETER index=%d shape=%dx%d worst=%d outside=%d%n", index,
                parameter.value.rows, parameter.value.cols, worst, TraceMath.outside(referenceWeight, weight));
        replay(index, worst, referenceGradient[worst], gradient[worst], referenceWeight[worst], weight[worst]);
        if (dots.containsKey(index)) dots.get(index).write(directory.resolve("parameter-" + index + ".bin"), worst);
        writeOutliers(index, referenceGradient, referenceWeight, gradient, weight);
    }

    private void replay(int parameter, int index, float oldG, float newG, float oldW, float newW) {
        float start = initial.get(parameter)[index];
        float replayOld = replayUpdate(start, oldG), replayNew = replayUpdate(start, newG);
        boolean oldMatch = TraceMath.same(oldW, replayOld), newMatch = TraceMath.same(newW, replayNew);
        System.out.printf("REPLAY parameter=%d index=%d initial=%.12g oldG=%.12g newG=%.12g "
                + "oldW=%.12g newW=%.12g oldBits=%s newBits=%s%n",
                parameter, index, start, oldG, newG, oldW, newW, oldMatch, newMatch);
        if (!oldMatch || !newMatch) throw new AssertionError("Optimizer replay mismatch");
    }

    private float replayUpdate(float weight, float gradient) {
        Tensor w = Tensor.from2D(new float[][]{{weight}}), g = Tensor.from2D(new float[][]{{gradient}});
        device.adamWUpdate(w, g, Tensor.zeros(1, 1), Tensor.zeros(1, 1),
                1e-4f, 0.9f, 0.999f, 1e-8f, 0.01f, 1 - 0.9f, 1 - 0.999f);
        return w.get(0, 0);
    }

    private void writeOutliers(int parameter, float[] oldG, float[] oldW, float[] newG, float[] newW)
            throws IOException {
        try (var out = Files.newBufferedWriter(directory.resolve("outliers-" + parameter + ".csv"))) {
            out.write("index,initial,oldGradient,newGradient,oldWeight,newWeight\n");
            for (int index = 0; index < oldW.length; index++) {
                if (!TraceMath.outside(oldW[index], newW[index])) continue;
                out.write(String.format(Locale.ROOT, "%d,%.12g,%.12g,%.12g,%.12g,%.12g%n", index,
                        initial.get(parameter)[index], oldG[index], newG[index], oldW[index], newW[index]));
            }
        }
    }

    private static Batch batch() {
        Random random = new Random(2026);
        int[][] x = new int[1][1024], y = new int[1][1024];
        int previous = random.nextInt(128);
        for (int index = 0; index < 1024; index++) {
            x[0][index] = previous;
            previous = random.nextInt(128);
            y[0][index] = previous;
        }
        return new Batch(x, y);
    }

    private record Dot(Tensor left, Tensor right, Tensor output) {
        void write(Path path, int worst) throws IOException {
            left.materialize(); right.materialize(); output.materialize();
            try (var out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(path)))) {
                out.writeInt(worst);
                TraceMath.writeArray(out, left);
                TraceMath.writeArray(out, right);
                TraceMath.writeArray(out, output);
            }
        }
    }
}
