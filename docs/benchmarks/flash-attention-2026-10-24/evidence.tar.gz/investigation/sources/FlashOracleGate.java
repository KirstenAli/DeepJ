import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.cpu.CpuBackend;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;
import java.util.*;

/** Explains the unchanged exact-arithmetic test with an independent double reference. */
public final class FlashOracleGate {
    private FlashOracleGate() {}

    public static void main(String[] args) {
        var device = new MetalBackend();
        Tensor.setBackend(device);
        try { check(device); }
        finally { device.releaseResources(); }
    }

    private static void check(MetalBackend device) {
        var cpu = new CpuBackend();
        Tensor q = cpu.random(12 * 1024, 64, new Random(229));
        Tensor k = cpu.random(q.rows, 64, new Random(233));
        Tensor v = cpu.random(q.rows, 64, new Random(239));
        Tensor g = cpu.random(q.rows, 64, new Random(241));
        var inputs = new HighPrecisionAttention.Input(q, k, v, g, 12, 0.125f);
        var oracle = HighPrecisionAttention.calculate(inputs);
        var saved = device.causalAttention(q, k, v, 12, 0.125f);
        var gradients = device.causalAttentionBackward(q, k, v, saved, g, 12, 0.125f);
        var legacy = reference(device, inputs);
        compare("output", oracle.output(), legacy.get(0), saved.output(), 2e-5, 2e-4);
        compare("dQ", oracle.dq(), legacy.get(1), gradients.query(), 3e-5, 5e-4);
        compare("dK", oracle.dk(), legacy.get(2), gradients.key(), 3e-5, 5e-4);
        compare("dV", oracle.dv(), legacy.get(3), gradients.value(), 3e-5, 5e-4);
        System.out.println("ALL HEADS FP64 ORACLE COMPLETED");
    }

    private static List<Tensor> reference(MetalBackend device, HighPrecisionAttention.Input x) {
        Tensor scores = device.batchedMatmul(x.q(), x.k(), x.heads(), false, true);
        Tensor p = device.causalSoftmax(scores, x.length(), x.scale());
        Tensor dp = device.batchedMatmul(x.g(), x.v(), x.heads(), false, true);
        Tensor ds = device.softmaxBackward(dp, p, x.scale());
        return List.of(device.batchedMatmul(p, x.v(), x.heads(), false, false),
                device.batchedMatmul(ds, x.k(), x.heads(), false, false),
                device.batchedMatmul(ds, x.q(), x.heads(), true, false),
                device.batchedMatmul(p, x.g(), x.heads(), true, false));
    }

    private static void compare(String name, double[] oracle, Tensor legacy, Tensor actual, double abs, double rel) {
        legacy.materialize(); actual.materialize();
        Metrics old = metrics(oracle, legacy.data, abs, rel), next = metrics(oracle, actual.data, abs, rel);
        int different = 0, first = -1;
        for (int index = 0; index < oracle.length; index++) {
            if (Float.floatToIntBits(legacy.data[index]) == Float.floatToIntBits(actual.data[index])) continue;
            different++;
            if (first < 0) first = index;
        }
        System.out.printf("ORACLE variable=%s count=%d bitDifferences=%d legacy=%s candidate=%s%n",
                name, oracle.length, different, old, next);
        if (first >= 0) System.out.printf("FIRST variable=%s index=%d legacy=%.16g candidate=%.16g "
                + "FP64=%.16g nearestFloat=%.16g%n", name, first, (double) legacy.data[first],
                (double) actual.data[first], oracle[first], (double) (float) oracle[first]);
        if (old.outside != 0 || next.outside != 0) throw new AssertionError("Independent accuracy failure");
    }

    private static Metrics metrics(double[] oracle, float[] actual, double abs, double rel) {
        double maximum = 0, error2 = 0, norm2 = 0;
        int outside = 0, nearest = 0;
        for (int index = 0; index < oracle.length; index++) {
            double error = Math.abs(actual[index] - oracle[index]);
            maximum = Math.max(maximum, error); error2 += error * error; norm2 += oracle[index] * oracle[index];
            if (!Float.isFinite(actual[index]) || error > abs + rel * Math.abs(oracle[index])) outside++;
            if (Float.floatToIntBits(actual[index]) == Float.floatToIntBits((float) oracle[index])) nearest++;
        }
        return new Metrics(maximum, Math.sqrt(error2 / norm2), outside, nearest);
    }

    private record Metrics(double maximumAbsolute, double relativeL2, int outside, int nearestFloat) {}
}
