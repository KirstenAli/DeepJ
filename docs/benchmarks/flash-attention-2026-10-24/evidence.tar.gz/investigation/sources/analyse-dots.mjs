import fs from 'node:fs';
import path from 'node:path';

const root = process.argv[2];

function readDot(file) {
  const data = fs.readFileSync(file);
  let offset = 4;
  const tensors = [];
  for (let tensor = 0; tensor < 3; tensor++) {
    const rows = data.readInt32BE(offset), cols = data.readInt32BE(offset + 4);
    offset += 8;
    const values = new Float32Array(rows * cols);
    for (let index = 0; index < values.length; index++, offset += 4) values[index] = data.readFloatBE(offset);
    tensors.push({ rows, cols, values });
  }
  if (offset !== data.length) throw new Error('Invalid tensor file');
  return { worst: data.readInt32BE(0), tensors };
}

function contributions(base, next, index) {
  const [x0, g0, out0] = base.tensors, [x1, g1, out1] = next.tensors;
  const row = Math.floor(index / out0.cols), col = index % out0.cols;
  let old64 = 0, new64 = 0, absOld = 0, absNew = 0, input = 0, upstream = 0, cross = 0;
  for (let time = 0; time < x0.rows; time++) {
    const a = x0.values[time * x0.cols + row], b = g0.values[time * g0.cols + col];
    const c = x1.values[time * x1.cols + row], d = g1.values[time * g1.cols + col];
    old64 += a * b; new64 += c * d; absOld += Math.abs(a * b); absNew += Math.abs(c * d);
    input += (c - a) * b; upstream += a * (d - b); cross += (c - a) * (d - b);
  }
  const old32 = out0.values[index], new32 = out1.values[index];
  return { old64, new64, old32, new32, input, upstream, cross, absOld, absNew,
    oldRounding: old32 - old64, newRounding: new32 - new64,
    oldCancellation: absOld / Math.abs(old64), newCancellation: absNew / Math.abs(new64) };
}

function outliers(file) {
  return fs.readFileSync(file, 'utf8').trim().split('\n').slice(1).map(line => {
    const [index, initial, oldGradient, newGradient, oldWeight, newWeight] = line.split(',').map(Number);
    return { index, initial, oldGradient, newGradient, oldWeight, newWeight };
  });
}

function analyse(model, variant) {
  const result = [];
  for (const parameter of [4, 7, 8, 9, 11, 13]) {
    const name = `parameter-${parameter}.bin`;
    const baseFile = path.join(root, `${model}-baseline`, name);
    const newFile = path.join(root, `${model}-${variant}`, name);
    if (!fs.existsSync(baseFile) || !fs.existsSync(newFile)) continue;
    const base = readDot(baseFile), next = readDot(newFile);
    for (const row of outliers(path.join(root, `${model}-${variant}`, `outliers-${parameter}.csv`))) {
      const values = contributions(base, next, row.index);
      result.push({ model, variant, parameter, ...row, ...values });
    }
  }
  return result;
}

const results = ['prism', 'nova'].flatMap(model => ['two-pass', 'one-pass', 'oracle'].flatMap(variant => analyse(model, variant)));
process.stdout.write(JSON.stringify(results, null, 2) + '\n');
