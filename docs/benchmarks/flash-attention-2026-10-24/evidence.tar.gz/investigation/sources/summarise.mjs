import fs from 'node:fs';
import path from 'node:path';

const root = process.argv[2];
const runs = [];
for (const model of ['prism', 'nova']) {
  for (const variant of ['baseline', 'two-pass', 'one-pass', 'oracle']) {
    const log = fs.readFileSync(path.join(root, `${model}-${variant}.txt`), 'utf8');
    if (!log.includes('TRACE COMPLETE') || /Bits=false|Exception/.test(log)) throw new Error('Incomplete trace');
    const arrays = [...log.matchAll(/PARAMETER index=(\d+) shape=(\d+)x(\d+) worst=(\d+) outside=(\d+)/g)]
      .map(([, parameter, rows, cols, worst, outside]) => ({ parameter: +parameter, rows: +rows,
        cols: +cols, worst: +worst, outside: +outside }));
    if (arrays.length !== 7) throw new Error('Missing selected array');
    runs.push({ model, variant, arrays, outside: arrays.reduce((sum, row) => sum + row.outside, 0) });
  }
}
process.stdout.write(JSON.stringify({ runs }, null, 2) + '\n');
