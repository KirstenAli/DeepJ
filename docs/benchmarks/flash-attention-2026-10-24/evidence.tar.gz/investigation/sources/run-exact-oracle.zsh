#!/bin/zsh
set -euo pipefail
TRACE_ROOT=${0:A:h}
FLASH_ROOT=/private/tmp/deepj-flash-revisit.ts22Bk
export JAVA_HOME=$(/usr/libexec/java_home -v 20)
TRACE_PHASE=starting
trap 'print "FAILED $TRACE_PHASE exit=$?" > "$TRACE_ROOT/exact-oracle-status.txt"' ZERR
for variant in baseline two-pass one-pass; do
    TRACE_PHASE="$variant-all-head-oracle"
    print "RUNNING $TRACE_PHASE" > "$TRACE_ROOT/exact-oracle-status.txt"
    "$JAVA_HOME/bin/java" -Xmx3g --enable-native-access=ALL-UNNAMED \
        -cp "$FLASH_ROOT/$variant/src/main/resources:$FLASH_ROOT/classes:$TRACE_ROOT/oracle-classes" \
        FlashOracleGate > "$TRACE_ROOT/$TRACE_PHASE.txt" 2>&1
done
print 'EXACT GATE ORACLE COMPLETED' > "$TRACE_ROOT/exact-oracle-status.txt"
