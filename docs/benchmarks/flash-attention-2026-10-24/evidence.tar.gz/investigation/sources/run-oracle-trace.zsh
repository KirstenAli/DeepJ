#!/bin/zsh
set -euo pipefail
TRACE_ROOT=${0:A:h}
FLASH_ROOT=/private/tmp/deepj-flash-revisit.ts22Bk
PRIOR_ROOT=/private/tmp/deepj-attention-followup.rO9vxi
export JAVA_HOME=$(/usr/libexec/java_home -v 20)
TRACE_PHASE=starting
trap 'print "FAILED $TRACE_PHASE exit=$?" > "$TRACE_ROOT/oracle-status.txt"' ZERR
for model in prism nova; do
    TRACE_PHASE="$model-oracle"
    print "RUNNING $TRACE_PHASE" > "$TRACE_ROOT/oracle-status.txt"
    "$JAVA_HOME/bin/java" -Xmx8g --enable-native-access=ALL-UNNAMED \
        -cp "$FLASH_ROOT/baseline/src/main/resources:$FLASH_ROOT/classes:$TRACE_ROOT/oracle-classes" \
        FlashWeightTrace "$model" "$PRIOR_ROOT/$model-first-step.gz" "$TRACE_ROOT/$TRACE_PHASE" oracle \
        > "$TRACE_ROOT/$TRACE_PHASE.txt" 2>&1
done
print 'ORACLE TRACE COMPLETED' > "$TRACE_ROOT/oracle-status.txt"
