#!/bin/zsh
set -euo pipefail
TRACE_ROOT=${0:A:h}
FLASH_ROOT=/private/tmp/deepj-flash-revisit.ts22Bk
PRIOR_ROOT=/private/tmp/deepj-attention-followup.rO9vxi
export JAVA_HOME=$(/usr/libexec/java_home -v 20)
TRACE_PHASE=starting
trap 'print "FAILED $TRACE_PHASE exit=$?" > "$TRACE_ROOT/status.txt"' ZERR
for model in prism nova; do
    heap=8g
    [[ "$model" != prism ]] || heap=6g
    for variant in baseline two-pass one-pass; do
        TRACE_PHASE="$model-$variant"
        print "RUNNING $TRACE_PHASE" > "$TRACE_ROOT/status.txt"
        "$JAVA_HOME/bin/java" "-Xmx$heap" --enable-native-access=ALL-UNNAMED \
            -cp "$FLASH_ROOT/$variant/src/main/resources:$FLASH_ROOT/classes:$TRACE_ROOT/classes" \
            FlashWeightTrace "$model" "$PRIOR_ROOT/$model-first-step.gz" "$TRACE_ROOT/$TRACE_PHASE" \
            > "$TRACE_ROOT/$TRACE_PHASE.txt" 2>&1
    done
done
print 'TRACE COMPLETED' > "$TRACE_ROOT/status.txt"
