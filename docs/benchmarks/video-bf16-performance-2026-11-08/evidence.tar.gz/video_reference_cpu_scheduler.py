"""Bounded staged Diffusers SANA-Video benchmark with DeepJ's exact prompt IDs and starting noise."""
import gc,json,sys,time
from pathlib import Path
import numpy as np
from PIL import Image
import torch,diffusers,transformers
from safetensors import safe_open
from reference_common import stream_gemma,stream_video,stable_half_video
from diffusers import SanaVideoTransformer3DModel,AutoencoderKLWan,DPMSolverMultistepScheduler
from diffusers.models.transformers.transformer_sana_video import WanRotaryPosEmbed
from transformers import Gemma2Config,Gemma2Model
from transformers.models.gemma2.modeling_gemma2 import Gemma2RotaryEmbedding
root=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
inputs=json.loads((out/'video-input.json').read_text());dtype={'FLOAT32':torch.float32,'FLOAT16':torch.float16,'BFLOAT16':torch.bfloat16}[sys.argv[3]]
torch.set_num_threads(10);torch.set_num_interop_threads(1)
if not torch.backends.mps.is_available():raise RuntimeError('MPS required')
def sync():torch.mps.synchronize()
def clear():gc.collect();torch.mps.empty_cache();sync()
def load(model,directory,kind):
    files=sorted(directory.glob('*.safetensors'))
    for filename in files:
        with safe_open(filename,framework='pt',device='cpu') as source:keys=list(source.keys())
        for key in keys:
            with safe_open(filename,framework='pt',device='cpu') as source:value=source.get_tensor(key).to(device='mps',dtype=kind)
            model.load_state_dict({key:value},strict=False,assign=True);del value
            sync()
    if any(p.is_meta or p.dtype!=kind or p.device.type!='mps' for p in model.parameters()):raise RuntimeError('Incomplete model assignment')
    return model.requires_grad_(False).eval()
def stage(name,start):
    sync();elapsed=time.perf_counter()-start;stages.append(dict(stage=name,seconds=elapsed));print(json.dumps(stages[-1]),flush=True)
start_all=time.perf_counter();stages=[]
with torch.inference_mode():
    start=time.perf_counter();cfg=Gemma2Config.from_pretrained(root/'text_encoder',local_files_only=True);cfg._attn_implementation='eager'
    with torch.device('meta'):model=Gemma2Model(cfg)
    stream_gemma(model,root/'text_encoder',dtype);model.rotary_emb=Gemma2RotaryEmbedding(cfg).to('mps')
    if hasattr(model.embed_tokens,'embed_scale'):
        model.embed_tokens.embed_scale=torch.tensor(cfg.hidden_size**.5,device='mps',dtype=dtype)
    load_time=time.perf_counter()-start;features={};masks={}
    names=['positive','negative'];length=max(len(inputs[name]['tokens']) for name in names)
    tokens=[inputs[name]['tokens']+[0]*(length-len(inputs[name]['tokens'])) for name in names]
    valid=[inputs[name]['valid']+[0]*(length-len(inputs[name]['valid'])) for name in names]
    hidden=model(torch.tensor(tokens,device='mps'),attention_mask=torch.tensor(valid,device='mps'),use_cache=False).last_hidden_state
    if not torch.isfinite(hidden).all():raise RuntimeError('Non-finite Gemma output')
    for row,name in enumerate(names):
        item=inputs[name];features[name]=hidden[row:row+1,item['selected']].to(dtype)
        masks[name]=torch.tensor([item['mask']],device='mps')
    del hidden,model;clear();stage('Gemma load and encode',start)
    stages[-1]['load_seconds']=load_time
    start=time.perf_counter();cfg=json.loads((root/'transformer/config.json').read_text())
    with torch.device('meta'):model=SanaVideoTransformer3DModel.from_config(cfg)
    (stream_video if dtype==torch.float32 else load)(model,root/'transformer',dtype)
    model.rope=WanRotaryPosEmbed(cfg['attention_head_dim'],cfg['patch_size'],cfg['rope_max_seq_len']).to('mps')
    if dtype==torch.float16 and '--safe-fp16' in sys.argv:stable_half_video(model)
    load_time=time.perf_counter()-start
    scheduler=DPMSolverMultistepScheduler.from_pretrained(root/'scheduler',local_files_only=True);scheduler.set_timesteps(3)
    latent=torch.from_numpy(np.fromfile(out/'noise.f32',dtype='<f4').reshape(inputs['shape'])).to('mps')
    embeds=torch.cat([features['negative'],features['positive']]);mask=torch.cat([masks['negative'],masks['positive']])
    for raw_time in scheduler.timesteps:
        timestep=raw_time.clone().to('mps')
        prediction=model(torch.cat([latent]*2).to(dtype),timestep=timestep.expand(2),encoder_hidden_states=embeds,
            encoder_attention_mask=mask,return_dict=False)[0].float()
        negative,positive=prediction.chunk(2);flow=negative+6*(positive-negative)
        latent=scheduler.step(flow.cpu(),raw_time,latent.cpu(),return_dict=False)[0].to('mps')
        if not torch.isfinite(latent).all():raise RuntimeError('Non-finite video latent')
    del model,prediction,positive,negative,features,embeds,masks,mask,flow;clear();stage('Transformer load and three guided steps',start)
    stages[-1]['load_seconds']=load_time
    start=time.perf_counter();cfg=json.loads((root/'vae/config.json').read_text())
    with torch.device('meta'):model=AutoencoderKLWan.from_config(cfg)
    load(model,root/'vae',torch.float32);load_time=time.perf_counter()-start
    mean=torch.tensor(cfg['latents_mean'],device='mps').reshape(1,16,1,1,1)
    std=torch.tensor(cfg['latents_std'],device='mps').reshape(1,16,1,1,1)
    video=model.decode(latent.float()*std+mean,return_dict=False)[0]
    if not torch.isfinite(video).all():raise RuntimeError('Non-finite video decoder')
    pixels=video[0].float().cpu().clamp(-1,1).permute(1,2,3,0).numpy()
    rgb=np.rint((pixels+1)*127.5).clip(0,255).astype('uint8')
    del model,video;clear();stage('Wan load and decode',start);stages[-1]['load_seconds']=load_time
elapsed=time.perf_counter()-start_all
for i,frame in enumerate(rgb):Image.fromarray(frame).save(out/f'python-frame-{i}.png')
result=dict(engine='PyTorch/Diffusers',torch=torch.__version__,transformers=transformers.__version__,diffusers=diffusers.__version__,
    backend='mps',dtype=sys.argv[3],frames=5,width=192,height=128,steps=3,guidance=6,stages=stages,generation_seconds=elapsed,
    guidance_batch=2,caption_batch=2,vae_dtype='FLOAT32',sampler_dtype='FLOAT32',scheduler_device='cpu',gemma_weights='streamed',fp16_stability='FP32 QK projection, normalization, denominator and gated residual' if dtype==torch.float16 and '--safe-fp16' in sys.argv else 'upstream')
(out/'python-video-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
