import io.github.kirstenali.deepj.concurrent.DeepJExecutor;
import io.github.kirstenali.deepj.nn.diffusion.sana.SanaSprint;
import io.github.kirstenali.deepj.nn.diffusion.sanavideo.*;
import io.github.kirstenali.deepj.persistence.qwen3.Qwen3Json;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;
import java.awt.image.BufferedImage;
import java.nio.file.*;
import java.util.*;
import javax.imageio.ImageIO;

public final class VideoAuditProbe {
    private static final String IMAGE="A red fox in a snowy forest, soft morning light, detailed wildlife photograph";
    private static final String VIDEO="A small red fox walks slowly through a sunny green meadow. Clear natural daylight, detailed fur, steady camera. motion score: 30.";
    private static final List<Map<String,Object>> stages=new ArrayList<>();
    private static long start, previous;
    private static String last="setup";
    public static void main(String[] args) throws Exception {
        if(!MetalBackend.isAvailable())throw new IllegalStateException("Physical Metal required");
        Tensor.setBackend(new MetalBackend());DeepJExecutor.setNumThreads(10);
        Path model=Path.of(args[1]),out=Path.of(args[2]);Files.createDirectories(out);
        DType dtype=DType.valueOf(args[3]); start=previous=System.nanoTime();
        List<BufferedImage> images=args[0].equals("image")?image(model,dtype):video(model,dtype);
        stage("complete");double elapsed=(System.nanoTime()-start)/1e9;
        long save=System.nanoTime();
        for(int i=0;i<images.size();i++)ImageIO.write(images.get(i),"png",out.resolve("frame-"+i+".png").toFile());
        
        Files.writeString(out.resolve("result.json"),Qwen3Json.stringify(Map.of("kind",args[0],"dtype",dtype.name(),
            "generation_seconds",elapsed,"save_seconds",(System.nanoTime()-save)/1e9,
            "frames",images.size(),"width",images.get(0).getWidth(),"height",images.get(0).getHeight(),"stages",stages)));
        System.out.println(Files.readString(out.resolve("result.json")));
        Tensor.backend().releaseTemporaryResources();DeepJExecutor.shutdown();
    }
    private static List<BufferedImage> image(Path model,DType dtype) throws Exception {
        return List.of(new SanaSprint(model,VideoAuditProbe::stage).generate(IMAGE,new SanaSprint.Options(1024,1024,2,4.5f,42,dtype)));
    }
    private static List<BufferedImage> video(Path model,DType dtype) throws Exception {
        return new SanaVideo(model,VideoAuditProbe::stage).generate(VIDEO,new SanaVideo.Options(192,128,5,3,6,42,dtype));
    }
    private static void stage(String name) {
        long now=System.nanoTime();
        var record=Map.<String,Object>of("stage",last,"seconds",(now-previous)/1e9,"next",name,"elapsed_seconds",(now-start)/1e9);
        stages.add(record);System.out.println(Qwen3Json.stringify(record));
        last=name;previous=now;
    }
}
