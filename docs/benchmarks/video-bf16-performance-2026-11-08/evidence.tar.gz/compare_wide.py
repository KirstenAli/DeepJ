from pathlib import Path
import numpy as np,json
root=Path(__file__).resolve().parent;results={}
for dtype in ('FLOAT32','FLOAT16','BFLOAT16'):
 a=np.fromfile(root/f'wide-{dtype}-staged/output.f32',dtype='<f4').astype(float)
 b=np.fromfile(root/f'wide-{dtype}-grouped/output.f32',dtype='<f4').astype(float)
 delta=np.abs(a-b);relative=np.sqrt(np.mean(delta**2))/np.sqrt(np.mean(a**2))
 results[dtype]={'elements':a.size,'max_abs':float(delta.max()),'relative_rmse':float(relative),'matching_elements':int(np.count_nonzero(a==b))}
 print(dtype,results[dtype],flush=True)
 assert relative<({'FLOAT32':1e-5,'FLOAT16':0.002,'BFLOAT16':0.01}[dtype])
(root/'wide-block-results.json').write_text(json.dumps(results,indent=2)+'\n')
