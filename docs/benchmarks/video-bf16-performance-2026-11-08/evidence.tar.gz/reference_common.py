import gc,time,json
import torch
from safetensors import safe_open
stages=[]
def sync():torch.mps.synchronize()
def clear():gc.collect();torch.mps.empty_cache();sync()
def load(model,directory,kind):
    files=sorted(directory.glob('*.safetensors'))
    for filename in files:
        with safe_open(filename,framework='pt',device='cpu') as source:keys=list(source.keys())
        for key in keys:
            with safe_open(filename,framework='pt',device='cpu') as source:value=source.get_tensor(key).to(device='mps',dtype=kind)
            model.load_state_dict({key:value},strict=False,assign=True);del value
            sync()
    if any(p.is_meta or p.dtype!=kind or p.device.type!='mps' for p in model.parameters()):raise RuntimeError('Incomplete model assignment')
    return model.requires_grad_(False).eval()
def stage(name,start):
    sync();elapsed=time.perf_counter()-start;stages.append(dict(stage=name,seconds=elapsed));print(json.dumps(stages[-1]),flush=True)

def stream_gemma(model,directory,kind):
    index={}
    for filename in sorted(directory.glob('*.safetensors')):
        with safe_open(filename,framework='pt',device='cpu') as source:
            index.update({key:filename for key in source.keys()})
    groups=[('embed_tokens',model.embed_tokens)]+[(f'layers.{i}',layer) for i,layer in enumerate(model.layers)]+[('norm',model.norm)]
    def before(prefix,module):
        def hook(_module,_args):
            for key,filename in index.items():
                if not key.startswith(prefix+'.'):continue
                with safe_open(filename,framework='pt',device='cpu') as source:
                    value=source.get_tensor(key).to(device='mps',dtype=kind)
                module.load_state_dict({key[len(prefix)+1:]:value},strict=False,assign=True)
                del value
            if prefix=='embed_tokens' and hasattr(module,'embed_scale'):
                module.embed_scale=torch.tensor(model.config.hidden_size**.5,device='mps',dtype=kind)
        return hook
    def after(module,_args,output):
        sync();module.to('meta');torch.mps.empty_cache();return output
    for prefix,module in groups:
        module.register_forward_pre_hook(before(prefix,module));module.register_forward_hook(after)
    return model.requires_grad_(False).eval()

def stream_video(model,directory,kind):
    index={}
    for filename in sorted(directory.glob('*.safetensors')):
        with safe_open(filename,framework='pt',device='cpu') as source:index.update({key:filename for key in source.keys()})
    def assign(module,prefix):
        for key,filename in index.items():
            if prefix and not key.startswith(prefix):continue
            if not prefix and key.startswith('transformer_blocks.'):continue
            with safe_open(filename,framework='pt',device='cpu') as source:value=source.get_tensor(key).to(device='mps',dtype=kind)
            module.load_state_dict({key[len(prefix):]:value},strict=False,assign=True);del value
    def before(prefix):
        return lambda module,_args:assign(module,prefix)
    def after(module,_args,output):
        sync();module.to('meta');torch.mps.empty_cache();return output
    assign(model,'')
    for i,block in enumerate(model.transformer_blocks):
        block.register_forward_pre_hook(before(f'transformer_blocks.{i}.'));block.register_forward_hook(after)
    return model.requires_grad_(False).eval()

def stable_half_video(model):
    import inspect
    from diffusers.models.transformers import transformer_sana_video as upstream
    source=inspect.getsource(upstream.SanaLinearAttnProcessor3_0)
    original='z = 1 / (key.sum(dim=-1, keepdim=True).transpose(-2, -1) @ query + 1e-15)'
    replacement='z = 1 / (key.float().sum(dim=-1, keepdim=True).transpose(-2, -1) @ query.float() + 1e-15)'
    if original not in source:raise RuntimeError('Upstream attention denominator changed')
    namespace=dict(vars(upstream));exec(source.replace(original,replacement),namespace)
    processor=namespace['SanaLinearAttnProcessor3_0']()
    for block in model.transformer_blocks:block.attn1.set_processor(processor)

    import torch.nn.functional as functional
    def project(module):
        def forward(value):
            bias=None if module.bias is None else module.bias.float()
            return functional.linear(value.float(),module.weight.float(),bias)
        return forward
    def normalized(module):
        original=module.forward
        return lambda value:original(value).to(torch.float16)
    for block in model.transformer_blocks:
        for attention in [block.attn1,block.attn2]:
            for kind in ['q','k']:
                module=getattr(attention,'to_'+kind);module.forward=project(module)
                norm=getattr(attention,'norm_'+kind);norm.forward=normalized(norm)
    source=inspect.getsource(upstream.SanaVideoTransformerBlock)
    source=source.replace('hidden_states = hidden_states + gate_msa * attn_output',
        'hidden_states = hidden_states.float() + gate_msa.float() * attn_output.float()')
    source=source.replace('hidden_states = hidden_states + gate_mlp * ff_output',
        'hidden_states = hidden_states.float() + gate_mlp.float() * ff_output.float()')
    source=source.replace('norm_hidden_states.to(hidden_states.dtype)',
        'norm_hidden_states.to(self.scale_shift_table.dtype)')
    source=source.replace('norm_hidden_states.unflatten(1,',
        'norm_hidden_states.to(self.scale_shift_table.dtype).unflatten(1,')
    namespace=dict(vars(upstream));exec(source,namespace)
    import types
    forward=namespace['SanaVideoTransformerBlock'].forward
    for block in model.transformer_blocks:block.forward=types.MethodType(forward,block)
    model.proj_out.register_forward_pre_hook(lambda module,args:(args[0].to(module.weight.dtype),))
