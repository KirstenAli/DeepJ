package io.github.kirstenali.deepj.nn.diffusion.sanavideo;
import io.github.kirstenali.deepj.autograd.GradMode;
import io.github.kirstenali.deepj.nn.*;
import io.github.kirstenali.deepj.persistence.HuggingFaceConfig;
import io.github.kirstenali.deepj.persistence.safetensors.TensorWeights;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;
import java.nio.*;
import java.nio.file.*;
import java.util.*;
public class WideBlockProbe {
 public static void main(String[] args)throws Exception {
  Tensor.setBackend(new MetalBackend());if(!MetalBackend.isAvailable())throw new IllegalStateException("Physical Metal required");
  Path model=Path.of(args[0]),out=Path.of(args[2]);Files.createDirectories(out);DType dtype=DType.valueOf(args[1]);
  var config=new HuggingFaceConfig(model.resolve("config.json"));int dim=config.integer("num_attention_heads")*config.integer("attention_head_dim");
  try(var ignored=GradMode.noGrad();var empty=TensorWeights.from(Map.of());var source=new VideoWeightCache(model,0,dtype)) {
   Tensor input=Tensor.random(384,dim,new Random(101)).to(dtype).reshape(2,192,dim);
   Tensor caption=Tensor.random(600,dim,new Random(102)).to(dtype).reshape(2,300,dim);
   Tensor time=Tensor.random(1,6*dim,new Random(103)).to(dtype);
   var rotary=new VideoRotary(2,8,12,config.integer("attention_head_dim"));
   var blocks=new SanaVideoBlocks(config,empty,source);
   try(var fixed=ModelMemory.retain(input,caption,time);var positions=ModelMemory.retain(rotary.buffers())) {
    Tensor result=blocks.forward(input,caption,null,time,rotary,0,new int[]{2,8,12});
    float[] values=ModelMemory.finite(result,"wide block control");
    ByteBuffer bytes=ByteBuffer.allocate(values.length*4).order(ByteOrder.LITTLE_ENDIAN);bytes.asFloatBuffer().put(values);
    Files.write(out.resolve("output.f32"),bytes.array());
   }
  }
  Tensor.backend().releaseResources();
 }
}
