import io.github.kirstenali.deepj.autograd.GradMode;
import io.github.kirstenali.deepj.nn.*;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;
import java.util.*;
import java.nio.*;
import java.nio.file.*;
public class ProjectionProbe {
 public static void main(String[] args)throws Exception {
  Tensor.setBackend(new MetalBackend());
  if(!MetalBackend.isAvailable())throw new IllegalStateException("Physical Metal required");
  try(var ignored=GradMode.noGrad()) {
   Tensor x=Tensor.random(384,2240,new Random(43)).to(DType.BFLOAT16).reshape(2,192,2240);
   Tensor w=Tensor.random(2240,2240,new Random(44)).to(DType.BFLOAT16).transpose();
   try(var pinned=ModelMemory.retain(x,w)) {
    double[] ms=new double[8];float checksum=0;
    for(int i=-3;i<8;i++) {
     long begin=System.nanoTime();
     try(var scope=TensorScope.open()) {
      Tensor y=args[0].equals("direct")?x.matmul(w):ModelOps.project(x,w);
      checksum+=y.toFloatArray()[0];
     }
     Tensor.backend().releaseTemporaryResources();
     if(i>=0)ms[i]=(System.nanoTime()-begin)/1e6;
    }
    Arrays.sort(ms);
    var names=GraphOpHistogram.opcodeNames();var ops=new TreeMap<String,Long>();
    GraphOpHistogram.snapshot().forEach((k,v)->ops.put(names.getOrDefault(k,k.toString()),v));
    if(args.length>1) {
     Path directory=Path.of(args[1]);Files.createDirectories(directory);
     raw(directory.resolve("x.f32"),x.toFloatArray());raw(directory.resolve("weight.f32"),w.transpose().toFloatArray());
     raw(directory.resolve("output.f32"),ModelOps.project(x,w).toFloatArray());
    }
    System.out.println("PROJECTION "+args[0]+" median_ms="+(ms[3]+ms[4])/2+" checksum="+checksum+" ops="+ops);
   }
  }
  Tensor.backend().releaseResources();
 }
 static void raw(Path path,float[] values)throws Exception {
  ByteBuffer buffer=ByteBuffer.allocate(values.length*4).order(ByteOrder.LITTLE_ENDIAN);buffer.asFloatBuffer().put(values);Files.write(path,buffer.array());
 }
}
