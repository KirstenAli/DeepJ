from pathlib import Path
import torch,numpy as np,json
root=Path(__file__).resolve().parent/'projection-values'
assert torch.backends.mps.is_available()
x=torch.from_numpy(np.fromfile(root/'x.f32',dtype='<f4').reshape(2,192,2240)).to(device='mps',dtype=torch.bfloat16)
w=torch.from_numpy(np.fromfile(root/'weight.f32',dtype='<f4').reshape(2240,2240)).to(device='mps',dtype=torch.bfloat16)
with torch.inference_mode():expected=torch.nn.functional.linear(x,w).float().cpu().numpy()
actual=np.fromfile(root/'output.f32',dtype='<f4').reshape(expected.shape)
difference=np.abs(actual-expected)
result={'elements':actual.size,'max_abs':float(difference.max()),'relative_rmse':float(np.sqrt(np.mean(difference**2))/np.sqrt(np.mean(expected**2))),'matching_elements':int(np.count_nonzero(actual==expected))}
(root/'comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
assert result['relative_rmse']<0.002
