from pathlib import Path
import subprocess,zipfile,json,statistics
out=Path.cwd();repo=out.parents[1]/'work/deepj-qwen-thinking';jdk=Path('/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home');folder=out/'last-axis';folder.mkdir(exist_ok=True)
s=(repo/'src/main/java/io/github/kirstenali/deepj/tensor/CpuContiguousSelection.java').read_text().replace('        if (target.dtype() != DType.FLOAT32 || updates.dtype() != DType.FLOAT32','        if (selection.axis() == target.rank() - 1 || target.dtype() != DType.FLOAT32 || updates.dtype() != DType.FLOAT32')
(folder/'CpuContiguousSelection.java').write_text(s)
subprocess.run([str(jdk/'bin/javac'),'-cp',str(repo/'target/deepj-cli.jar'),'-d',str(folder/'classes'),str(folder/'CpuContiguousSelection.java')],check=True)
updates={str(p.relative_to(folder/'classes')):p.read_bytes()for p in (folder/'classes').rglob('*.class')}
with zipfile.ZipFile(repo/'target/deepj-cli.jar')as old,zipfile.ZipFile(folder/'candidate.jar','w',zipfile.ZIP_DEFLATED)as new:
 for info in old.infolist():new.writestr(info,updates.pop(info.filename,old.read(info.filename)))
 for name,data in updates.items():new.writestr(name,data)
for label,jar in [('last','last-axis/candidate.jar'),('current',str(repo/'target/deepj-cli.jar'))]:
 with (out/(label+'-pilot.jsonl')).open('w')as log:subprocess.run([str(jdk/'bin/java'),'-Xmx1g','--enable-native-access=ALL-UNNAMED','-cp','classes:'+jar,'GemmaTrainingProbe','cpu',str(out.parent/'gemma-video-gap-2026-11-07/tiny-gemma')],stdout=log,stderr=subprocess.STDOUT,check=True)
 d=json.loads((out/(label+'-pilot.jsonl')).read_text().splitlines()[-1]);print(label,statistics.median(d['ms']),flush=True)
