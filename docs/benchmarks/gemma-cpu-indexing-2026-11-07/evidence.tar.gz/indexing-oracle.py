from pathlib import Path
import subprocess,zipfile
out=Path.cwd();repo=out.parents[1]/'work/deepj-qwen-thinking';folder=out/'oracle';folder.mkdir(exist_ok=True);jdk=Path('/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin')
s=(repo/'src/main/java/io/github/kirstenali/deepj/tensor/CpuRowSelection.java').read_text()
s=s.replace('    private CpuRowSelection() {}','''    private static int selections, additions;
    static { Runtime.getRuntime().addShutdownHook(new Thread(() -> System.err.println("INDEX_ORACLE selections="+selections+" additions="+additions))); }
    private CpuRowSelection() {}''')
s=s.replace('        return true;\n    }\n\n    static boolean add', '        checkSelection(input,selection,output);\n        return true;\n    }\n\n    static boolean add',1)
s=s.replace('        addRows(FloatRows.of(target)', '        float[] expected=referenceAdd(target,selection,updates);\n        addRows(FloatRows.of(target)',1).replace('        return true;\n    }\n\n    private static void addRows','        checkAddition(target,expected);\n        return true;\n    }\n\n    private static void addRows',1)
pos=s.rfind('}')
s=s[:pos]+'''
    private static void checkSelection(Tensor input,IndexSelection selection,Tensor output) {
        for(int index=0;index<output.numel();index++) {
            int source=input.layout().addressAt(selection.sourceIndex(index));
            if(input.dtype()==DType.FLOAT32) {
                if(Float.floatToRawIntBits(input.memory().floats()[source])!=Float.floatToRawIntBits(output.memory().floats()[index]))throw new AssertionError("Gather index "+index);
            } else if(input.memory().shorts()[source]!=output.memory().shorts()[index])throw new AssertionError("Compact gather index "+index);
        }
        selections++;
    }
    private static float[] referenceAdd(Tensor target,IndexSelection selection,Tensor updates) {
        float[] expected=target.memory().floats().clone();
        for(int index=0;index<updates.numel();index++) {
            int destination=target.layout().addressAt(selection.sourceIndex(index));
            expected[destination]+=updates.memory().get(updates.layout().addressAt(index));
        }
        return expected;
    }
    private static void checkAddition(Tensor target,float[] expected) {
        float[] actual=target.memory().floats();
        for(int index=0;index<expected.length;index++) {
            if(Float.floatToIntBits(expected[index])!=Float.floatToIntBits(actual[index]))throw new AssertionError("Scatter index "+index);
        }
        additions++;
    }
'''+s[pos:]
(folder/'CpuRowSelection.java').write_text(s)
subprocess.run([str(jdk/'javac'),'-cp','candidate.jar','-d',str(folder/'classes'),str(folder/'CpuRowSelection.java')],check=True)
updates={str(p.relative_to(folder/'classes')):p.read_bytes()for p in (folder/'classes').rglob('*.class')}
with zipfile.ZipFile(out/'candidate.jar')as old,zipfile.ZipFile(folder/'candidate.jar','w',zipfile.ZIP_DEFLATED)as new:
 for info in old.infolist():new.writestr(info,updates.pop(info.filename,old.read(info.filename)))
 for name,data in updates.items():new.writestr(name,data)
with (out/'indexing-oracle.jsonl').open('w')as f:subprocess.run([str(jdk/'java'),'-Xmx1g','-Dprobe.threads=1','-Dprobe.warmups=5','-Dprobe.samples=5','--enable-native-access=ALL-UNNAMED','-cp','classes:oracle/candidate.jar','GemmaTrainingProbe','cpu',str(out.parent/'gemma-video-gap-2026-11-07/tiny-gemma')],stdout=f,stderr=subprocess.STDOUT,check=True)
print((out/'indexing-oracle.jsonl').read_text().splitlines()[-1])
