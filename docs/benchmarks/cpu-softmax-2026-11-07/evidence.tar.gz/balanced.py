import subprocess,os
from pathlib import Path
p=Path(__file__).resolve().parent
java='/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java'
env=dict(os.environ,VECLIB_MAXIMUM_THREADS='10')
for pair in range(1,5):
 for version in (['baseline','candidate'] if pair%2 else ['candidate','baseline']):
  args=[java,'-Xmx1g','--enable-native-access=ALL-UNNAMED','-cp',f'{p}/{version}.jar:{p}/classes','io.github.kirstenali.deepj.nn.transformer.qwen3.PrefillProbe',str(p/'../prefill-investigation/one-block'),'cpu','FLOAT32','plain']
  with (p/f'block-{version}-{pair}.jsonl').open('w') as output:subprocess.run(args,stdout=output,stderr=subprocess.STDOUT,env=env,check=True,timeout=25)
  print('BLOCK_DONE',pair,version,flush=True)
for model in ['qwen','loop','prism']:
 for version in ['baseline','candidate']:
  args=[java,'-Xmx1g','-Dprobe.threads=1','--enable-native-access=ALL-UNNAMED','-cp',f'{p}/{version}.jar:{p}/classes','TinyTrainingProbe','cpu',model]
  with (p/f'train-{model}-{version}.jsonl').open('w') as output:subprocess.run(args,stdout=output,stderr=subprocess.STDOUT,env=env,check=True,timeout=25)
  print('TRAINING_DONE',model,version,flush=True)
