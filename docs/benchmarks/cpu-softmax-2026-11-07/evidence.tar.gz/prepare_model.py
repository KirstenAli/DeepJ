"""Extract one released decoder block and only the embedding rows used by the probe."""
import json
from pathlib import Path
import torch
from safetensors import safe_open
from safetensors.torch import save_file
root = Path(__file__).resolve().parents[2]
source = Path('/Users/kirstenali/Documents/Codex/models/Qwen3-1.7B')
out = Path(__file__).resolve().parent / 'one-block'
out.mkdir(exist_ok=True)
index = json.loads((source/'model.safetensors.index.json').read_text())['weight_map']
inputs = json.loads((root/'outputs/qwen3-1p7b/benchmark-input.json').read_text())
ids = sorted(set(inputs['prompt'] + inputs['decode']))
remap = {token:i for i,token in enumerate(ids)}
weights = {}
for shard in sorted(set(index.values())):
    with safe_open(source/shard,framework='pt',device='cpu') as reader:
        for name in reader.keys():
            if name.startswith('model.layers.0.') or name == 'model.norm.weight':
                weights[name] = reader.get_tensor(name).clone()
        if 'model.embed_tokens.weight' in reader.keys():
            sliced = reader.get_slice('model.embed_tokens.weight')
            weights['model.embed_tokens.weight'] = torch.cat([sliced[i:i+1] for i in ids])
config = json.loads((source/'config.json').read_text())
config.update(num_hidden_layers=1, vocab_size=len(ids), max_position_embeddings=128,
              bos_token_id=0, eos_token_id=1, pad_token_id=0)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n')
save_file(weights,out/'model.safetensors')
(out/'input.json').write_text(json.dumps({k:[remap[i] for i in v] for k,v in inputs.items()})+'\n')
(out/'provenance.json').write_text(json.dumps({'source_revision':'70d244cc86ccca08cf5af4e1e306ecf908b1ad5e','layers':1,'width':2048,'ff_width':6144,'heads':16,'kv_heads':8,'original_embedding_ids':ids,'purpose':'component performance diagnosis; not full-model throughput'},indent=2)+'\n')
print(json.dumps({'tensors':len(weights),'parameters':sum(t.numel() for t in weights.values()),'bytes':(out/'model.safetensors').stat().st_size,'vocab_size':len(ids)}))
