package io.github.kirstenali.deepj.nn.transformer.qwen3;
import io.github.kirstenali.deepj.concurrent.DeepJExecutor;
import io.github.kirstenali.deepj.persistence.qwen3.Qwen3Json;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.cpu.CpuBackend;
import java.nio.file.*;
import java.util.*;
public final class FullPrefillProbe {
 public static void main(String[] args) throws Exception {
  Tensor.setBackend(new CpuBackend());DeepJExecutor.setNumThreads(10);
  Qwen3 model=Qwen3Pretrained.load(Path.of(args[0]),DType.FLOAT32);
  System.gc();
  System.out.println(Qwen3Json.stringify(Map.of("kind","loaded","heap_used",Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory())));
  var input=Qwen3Json.read(Path.of(args[1]));
  int[] prompt=Qwen3Json.array(input.get("prompt")).stream().mapToInt(v->Math.toIntExact(Qwen3Json.integer(v))).toArray();
  try {
   for(int run=-8;run<5;run++) {
    try(var session=model.openGeneration()) {
     long start=System.nanoTime();float[] logits=session.apply(prompt).toFloatArray();double seconds=(System.nanoTime()-start)/1e9;
     System.out.println(Qwen3Json.stringify(Map.of("engine","DeepJ","backend","cpu","dtype","FLOAT32","trial",run,"prefill_seconds",seconds,"checksum",logits[0])));
    }
   }
  } finally {Tensor.backend().releaseTemporaryResources();DeepJExecutor.shutdown();}
 }
}
