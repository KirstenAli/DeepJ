#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/cpu-fp32-prefill-2026-11-07"
repo="$root/work/deepj-qwen-thinking"
python="$root/outputs/cpu-throughput/reference-env/bin/python"
export JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
export VECLIB_MAXIMUM_THREADS=10 PYTORCH_ENABLE_MPS_FALLBACK=0 TOKENIZERS_PARALLELISM=false
export PYTHONPATH="$repo/src/test/python"
guard="$out/small-regions"
cd "$guard"
cp "$repo/target/deepj-cli.jar" final.jar
prefill_ok=true
for pair in 1 2;do
 if ((pair%2));then order=(baseline pytorch final);else order=(final pytorch baseline);fi
 for engine in "${order[@]}";do
  if [[ "$engine" == pytorch ]];then
   cmd=("$python" -B "$out/matched_reference.py" /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B cpu "$out/prefill-input.json")
  else cmd=("$JAVA_HOME/bin/java" -Xmx8g -XX:G1HeapRegionSize=1m --enable-native-access=ALL-UNNAMED -cp "$out/$engine.jar:$out/classes" io.github.kirstenali.deepj.nn.transformer.qwen3.FullPrefillProbe /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B "$out/prefill-input.json");fi
  if ! "$python" run_guarded.py --stop-file "$guard/STOP" --log "$guard/full-$engine-$pair.jsonl" --timeout 60 --rss-gib 11 --swap-mib 64 -- "${cmd[@]}";then prefill_ok=false;break;fi
  sleep 3
 done
 if ! "$prefill_ok";then break;fi
done
echo "FULL_PREFILL_ACCEPTED=$prefill_ok"
