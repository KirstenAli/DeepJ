package io.github.kirstenali.deepj.nn.transformer.qwen3;

import io.github.kirstenali.deepj.tensor.*;
import java.lang.reflect.*;
import java.util.*;

final class StageProfiler implements InvocationHandler {
    private final TensorBackend target;
    private final Map<String, long[]> totals = new TreeMap<>();
    private final ThreadLocal<Integer> depth = ThreadLocal.withInitial(() -> 0);
    boolean enabled;
    StageProfiler(TensorBackend target) { this.target = target; }

    TensorBackend proxy() {
        Class<?> type = target instanceof CausalAttentionBackend ? CausalAttentionBackend.class : TensorBackend.class;
        return (TensorBackend) Proxy.newProxyInstance(getClass().getClassLoader(), new Class<?>[]{type}, this);
    }

    @Override public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        if (!enabled || method.getDeclaringClass() == Object.class) return call(method, args);
        int previous = depth.get();
        depth.set(previous + 1);
        long start = System.nanoTime();
        try {
            Object result = call(method, args);
            if (previous == 0) add(key(method, args, result), System.nanoTime() - start);
            return result;
        } finally { depth.set(previous); }
    }

    private Object call(Method method, Object[] args) throws Throwable {
        try { return method.invoke(target, args); }
        catch (InvocationTargetException failure) { throw failure.getCause(); }
    }

    private static String key(Method method, Object[] args, Object result) {
        StringBuilder key = new StringBuilder(method.getName());
        if (args != null) {
            for (Object arg : args) {
                if (arg instanceof Tensor t) key.append(' ').append(t.dtype()).append(Arrays.toString(t.shape()));
            }
        }
        if (result instanceof Tensor t) key.append(" -> ").append(t.dtype()).append(Arrays.toString(t.shape()));
        return key.toString();
    }

    private synchronized void add(String key, long nanos) {
        long[] values = totals.computeIfAbsent(key, ignored -> new long[2]);
        values[0]++;
        values[1] += nanos;
    }

    void reset() { totals.clear(); }
    Map<String, Object> report() {
        var result = new TreeMap<String, Object>();
        totals.forEach((key, value) -> result.put(key, Map.of("calls", value[0], "milliseconds", value[1] / 1e6)));
        return result;
    }
}
