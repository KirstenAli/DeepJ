package io.github.kirstenali.deepj.tensor;
public final class CpuSoftmaxAudit {
 public static void inspect(Tensor input,int width,float scale) {
  float[] values=input.toFloatArray(),output=new float[values.length];
  boolean accepted=CpuBlas.causalSoftmax(values,output,input.matrixRows(),width,scale,4);
  System.err.println("NATIVE_SOFTMAX_ACCEPTED="+accepted);
 }
}
