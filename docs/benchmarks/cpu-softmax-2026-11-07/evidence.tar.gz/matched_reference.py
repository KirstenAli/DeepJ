"""Same reference forward/timing; restore one FP32 tensor at a time to bound peak memory."""
import json
import sys
from pathlib import Path
import torch
import transformers
from safetensors import safe_open
import qwen3_benchmark as reference

root, device, path = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
torch.set_num_threads(10)
torch.set_num_interop_threads(1)
config = reference.Qwen3Config.from_pretrained(root, local_files_only=True)
config._attn_implementation = 'sdpa'
with torch.device('meta'):
    model = reference.Qwen3ForCausalLM(config)
names = sorted(set(json.loads((root / 'model.safetensors.index.json').read_text())['weight_map'].values()))
for name in names:
    with safe_open(root / name, framework='pt', device='cpu') as source:
        keys = list(source.keys())
    for key in keys:
        with safe_open(root / name, framework='pt', device='cpu') as source:
            value = source.get_tensor(key).to(device).to(dtype=torch.float32)
        model.load_state_dict({key: value}, strict=False, assign=True)
        del value
        if device == 'mps':
            torch.mps.synchronize()
            torch.mps.empty_cache()
model.tie_weights()
model.requires_grad_(False).eval()
model.model.rotary_emb = type(model.model.rotary_emb)(config=config, device=device)
assert all(p.dtype == torch.float32 and p.device.type == device for p in model.parameters())
assert model.lm_head.weight is model.model.embed_tokens.weight
print(json.dumps(dict(torch=torch.__version__, transformers=transformers.__version__,
    device=device, dtype='FLOAT32', threads=torch.get_num_threads(),
    interop=torch.get_num_interop_threads(), attention=config._attn_implementation,
    parameters=sum(p.numel() for p in model.parameters()),
    mps_allocated=torch.mps.current_allocated_memory() if device == 'mps' else 0,
    mps_driver=torch.mps.driver_allocated_memory() if device == 'mps' else 0)), flush=True)
data = json.loads(path.read_text())
for number in range(-8, 5):
    print(json.dumps(reference.trial(model, data, device, number)), flush=True)
