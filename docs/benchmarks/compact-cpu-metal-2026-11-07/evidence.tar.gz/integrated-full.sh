#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/compact-performance"
repo="$root/work/deepj-qwen-thinking"
python="$root/outputs/cpu-throughput/reference-env/bin/python"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
export VECLIB_MAXIMUM_THREADS=10
export PYTHONPATH="$repo/src/test/python"
export TOKENIZERS_PARALLELISM=false
has_idea() { /bin/ps -axo comm | /usr/bin/awk '/IntelliJ IDEA.app/{found=1} END{exit !found}'; }
for attempt in {1..120}; do
  if ! has_idea; then break; fi
  sleep 1
done
if has_idea; then exit 3; fi
sleep 5
/bin/ps -axo rss,comm | /usr/bin/sort -rn | /usr/bin/head -12 > "$out/benchmark-host-memory.txt" || true
for dtype in "$@"; do
  heap=6g; compact=true
  if [[ "$dtype" == FLOAT32 ]]; then heap=10g; compact=false; fi
  for backend in cpu metal; do
    "$python" "$root/outputs/cpu-throughput/run_guarded.py" --log "$out/integrated-full-deepj-$backend-$dtype.jsonl" \
      --timeout 180 --rss-gib 11 --swap-mib 128 -- \
      "$java" "-Xmx$heap" --enable-native-access=ALL-UNNAMED "-Dprobe.compact=$compact" \
      "-Dprobe.logits=$out/integrated-full-deepj-$backend-$dtype.bin" -cp "$out/column-classes:$out/classes:$out/integrated.jar" \
      io.github.kirstenali.deepj.nn.transformer.qwen3.FullPrecisionProbe \
      /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B "$backend" "$dtype" \
      "$root/outputs/qwen3-1p7b/benchmark-input.json" 10 5 5
    device="$backend"; if [[ "$backend" == metal ]]; then device=mps; fi
    "$python" "$root/outputs/cpu-throughput/run_guarded.py" --log "$out/integrated-full-pytorch-$backend-$dtype.jsonl" \
      --timeout 180 --rss-gib 11 --swap-mib 128 -- \
      "$python" "$out/full_reference.py" /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B "$device" \
      "$root/outputs/qwen3-1p7b/benchmark-input.json" "$dtype" "$out/integrated-full-pytorch-$backend-$dtype.bin"
    echo "FULL_COMPLETE $backend $dtype"
  done
done
echo FULL_MODELS_FINISHED
