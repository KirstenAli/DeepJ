#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/compact-performance"
repo="$root/work/deepj-qwen-thinking"
export JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
export VECLIB_MAXIMUM_THREADS=10
for backend in cpu metal; do
  for engine in deepj pytorch pytorch deepj; do
    tag="final-train-$backend-$engine-$(date +%s)"
    if [[ "$engine" == deepj ]]; then
      "$JAVA_HOME/bin/java" --enable-native-access=ALL-UNNAMED -Xmx1g -Xbatch -XX:CompileThresholdScaling=0.1 \
        -cp "$root/outputs/qwen-training-comparison/host/classes:$out/release.jar" \
        io.github.kirstenali.deepj.nn.transformer.qwen3.Qwen3TrainingBenchmark \
        "$backend" measure "$out/$tag" > "$out/$tag.log"
    else
      device="$backend"; if [[ "$backend" == metal ]]; then device=mps; fi
      "$root/outputs/cpu-throughput/reference-env/bin/python" -B "$repo/src/test/python/qwen3_training_benchmark.py" \
        "$root/outputs/qwen-training-comparison/host/fixture" "$device" "$out/$tag" > "$out/$tag.log"
    fi
    echo "MATCHED_TRAINING_COMPLETE $tag"
  done
done
echo TRAINING_COMPLETE
