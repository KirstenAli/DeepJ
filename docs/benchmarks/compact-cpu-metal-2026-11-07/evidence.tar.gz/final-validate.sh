#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
repo="$root/work/deepj-qwen-thinking"
out="$root/outputs/compact-performance"
export JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
export VECLIB_MAXIMUM_THREADS=10
cd "$repo"
/opt/homebrew/bin/mvn -o -Pfull-coverage -Ddeepj.qwen3.requireMetal=true verify > "$out/final-verify.log" 2>&1
echo FULL_VERIFY_PASSED
/opt/homebrew/bin/mvn -o surefire:test -Djacoco.skip=true -Ddeepj.cpu.javaOnly=true \
  -Dtest=CpuCompactNormalizationTest,CpuCompactPointwiseTest,CpuCompactSoftmaxTest,CpuCompactRotaryTest,TensorValuesCopyTest,Qwen3CompactTest \
  > "$out/final-fallback-tests.log" 2>&1
echo FALLBACK_CHECKS_PASSED

for backend in cpu metal; do
  for model in qwen loop prism; do
    for variant in baseline optimized; do
      jar="$root/outputs/full-qwen-performance/improved.jar"
      if [[ "$variant" == optimized ]]; then jar="$out/release.jar"; fi
      "$JAVA_HOME/bin/java" --enable-native-access=ALL-UNNAMED -Xmx1g -Xbatch -XX:CompileThresholdScaling=0.1 \
        -Dprobe.warmups=100 -Dprobe.samples=30 -cp "$root/outputs/qwen-inference-optimizations:$jar" \
        QuickProbe "$backend" "$model" training > "$out/final-control-$backend-$model-$variant.json"
    done
    echo "TRAINING_CONTROL_COMPLETE $backend $model"
  done
done
echo FINAL_CONTROLS_FINISHED
bash "$out/final-training.sh"
