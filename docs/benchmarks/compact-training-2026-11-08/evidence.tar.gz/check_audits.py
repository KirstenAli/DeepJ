import json
import math
from pathlib import Path
import torch
from safetensors.torch import load_file

root = Path(__file__).resolve().parent
results = {}
for backend in ['cpu', 'metal']:
    for model in ['qwen', 'gemma']:
        for dtype in ['FLOAT16', 'BFLOAT16']:
            name = f'{backend}-{model}-{dtype}'
            first = root / f'audit-{name}-deepj-0'
            second = root / f'audit-{name}-python-0'
            loss_a = json.loads((first / 'result.json').read_text())['losses'][0]
            loss_b = json.loads((second / 'result.json').read_text())['losses'][0]
            row = {'deepj_loss': loss_a, 'pytorch_loss': loss_b, 'loss_difference': abs(loss_a - loss_b)}
            for kind in ['logits', 'gradients', 'masters']:
                a = load_file(first / f'{kind}.safetensors')
                b = load_file(second / f'{kind}.safetensors')
                assert set(a) == set(b), (name, kind, set(a) ^ set(b))
                diff = torch.cat([(a[n].float() - b[n].float()).flatten() for n in a])
                reference = torch.cat([b[n].float().flatten() for n in a])
                row[kind] = {'maximum_absolute': diff.abs().max().item(),
                             'relative_l2': (diff.norm() / reference.norm()).item()}
            assert row['loss_difference'] < .1 and math.isfinite(row['gradients']['relative_l2']), name
            assert row['gradients']['relative_l2'] < (.02 if dtype == 'FLOAT16' else .1), (name, row)
            results[name] = row
            print(name, json.dumps(row), flush=True)
(root / 'audit-results.json').write_text(json.dumps(results, indent=2) + '\n')
