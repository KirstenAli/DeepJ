package io.github.kirstenali.deepj.nn.transformer.qwen3;

import io.github.kirstenali.deepj.concurrent.DeepJExecutor;
import io.github.kirstenali.deepj.loss.CrossEntropyLoss;
import io.github.kirstenali.deepj.nn.transformer.CausalLM;
import io.github.kirstenali.deepj.nn.transformer.gemma2.Gemma2Pretrained;
import io.github.kirstenali.deepj.optimisers.AdamW;
import io.github.kirstenali.deepj.optimisers.Parameter;
import io.github.kirstenali.deepj.persistence.qwen3.Qwen3Json;
import io.github.kirstenali.deepj.persistence.qwen3.SafeTensorWriter;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.cpu.CpuBackend;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;
import java.nio.file.*;
import java.util.*;

public final class CompactTrainingProbe {
    private final CausalLM model;
    private final List<Parameter> parameters;
    private final AdamW optimizer = AdamW.defaultAdamW(1e-4f);
    private final int[] tokens, targets;
    private final Path output;
    private final float scale;
    private final boolean audit;

    private CompactTrainingProbe(String[] args) throws Exception {
        DType dtype = DType.valueOf(args[2]);
        model = args[0].equals("qwen") ? Qwen3Pretrained.load(Path.of(args[1]), dtype, true)
                : Gemma2Pretrained.load(Path.of(args[1]), dtype);
        parameters = model.parameters().stream().sorted(Comparator.comparing(Parameter::name)).toList();
        var input = Qwen3Json.read(Path.of(args[1], "input.json"));
        tokens = ids(input.get("tokens")); targets = ids(input.get("targets"));
        output = Path.of(args[4]); Files.createDirectories(output);
        scale = dtype == DType.FLOAT16 ? 128 : 1;
        audit = args[5].equals("audit");
    }

    public static void main(String[] args) throws Exception {
        if (args[3].equals("metal") && !MetalBackend.isAvailable()) {
            throw new IllegalStateException("Physical Metal required");
        }
        Tensor.setBackend(args[3].equals("metal") ? new MetalBackend() : new CpuBackend());
        DeepJExecutor.setNumThreads(10);
        try { new CompactTrainingProbe(args).run(args); }
        finally { Tensor.backend().releaseResources(); DeepJExecutor.shutdown(); }
    }

    private void run(String[] args) throws Exception {
        var times = new ArrayList<Double>(); var losses = new ArrayList<Float>();
        int warmups = audit ? 0 : 100, samples = audit ? 1 : 30;
        Tensor.backend().releaseTemporaryResources();
        for (int step = -warmups; step < samples; step++) {
            long start = System.nanoTime(); float value = step();
            Tensor.backend().releaseTemporaryResources();
            double millis = (System.nanoTime() - start) / 1e6;
            losses.add(value); if (step >= 0) times.add(millis);
        }
        save("weights.safetensors", false); saveMasters();
        var result = result(args, warmups, times, losses);
        Files.writeString(output.resolve("result.json"), Qwen3Json.stringify(result));
        System.out.println(Qwen3Json.stringify(result));
    }

    private Map<String, Object> result(String[] args, int warmups, List<Double> times, List<Float> losses) {
        var result = new LinkedHashMap<String, Object>();
        result.put("engine", "DeepJ"); result.put("backend", args[3]); result.put("model", args[0]);
        result.put("dtype", args[2]); result.put("warmups", warmups); result.put("samples", times.size());
        result.put("loss_scale", scale); result.put("ms", times); result.put("losses", losses);
        result.put("gradients_dtype", "FLOAT32"); result.put("optimizer_dtype", "FLOAT32");
        result.put("parameters", parameters.stream().mapToLong(p -> p.value.numel()).sum());
        return result;
    }

    private float step() throws Exception {
        model.zeroGrad();
        try (var scope = TensorScope.open()) {
            Tensor logits = model.forward(tokens);
            if (audit) SafeTensorWriter.write(output.resolve("logits.safetensors"), Map.of("logits", logits));
            Tensor loss = CrossEntropyLoss.forward(logits, targets, null);
            (scale == 1 ? loss : loss.multiplyScalar(scale)).backward();
            float value = loss.item();
            if (!Float.isFinite(value)) throw new IllegalStateException("Non-finite loss");
            if (scale != 1) scaleGradients(1 / scale);
            if (audit) save("gradients.safetensors", true);
            clip(); optimizer.step(parameters);
            return value;
        }
    }

    private void clip() {
        var gradients = parameters.stream().map(Parameter::grad).filter(Objects::nonNull).toList();
        float norm = Tensor.backend().l2Norm(gradients);
        if (!Float.isFinite(norm)) throw new IllegalStateException("Non-finite gradient");
        if (norm > 1) scaleGradients(1 / (norm + 1e-12f));
    }

    private void scaleGradients(float factor) {
        for (Parameter parameter : parameters) {
            if (parameter.grad() != null) parameter.grad().multiplyScalarInPlace(factor);
        }
    }

    private void save(String filename, boolean gradients) throws Exception {
        var values = new LinkedHashMap<String, Tensor>();
        for (Parameter parameter : parameters) {
            Tensor value = gradients ? parameter.grad() : parameter.value;
            if (gradients && value.dtype() != DType.FLOAT32) throw new AssertionError("Gradient dtype");
            values.put(parameter.name(), value);
        }
        SafeTensorWriter.write(output.resolve(filename), canonical(values));
    }

    private void saveMasters() throws Exception {
        var state = optimizer.state(parameters); var values = new LinkedHashMap<String, Tensor>();
        for (int index = 0; index < parameters.size(); index++) {
            values.put(parameters.get(index).name(), state.masterWeights().get(index));
        }
        SafeTensorWriter.write(output.resolve("masters.safetensors"), canonical(values));
    }

    private Map<String, Tensor> canonical(Map<String, Tensor> values) {
        if (!(model instanceof Qwen3 qwen)) return values;
        var result = new LinkedHashMap<String, Tensor>();
        for (var weight : Qwen3Weights.inventory(qwen.config())) {
            Tensor value = values.get(weight.name());
            result.put(weight.source(), weight.transpose() ? value.transpose() : value.reshape(weight.sourceShape()));
        }
        return result;
    }

    private static int[] ids(Object value) {
        return Qwen3Json.array(value).stream().mapToInt(x -> Math.toIntExact(Qwen3Json.integer(x))).toArray();
    }
}
