#!/bin/bash
set -euo pipefail
root=$WORKSPACE
out="$root/outputs/compact-training-2026-11-08"
jar="$root/outputs/media-throughput-2026-11-07/candidate.jar"
py="$root/outputs/cpu-throughput/reference-env/bin/python"
jdk=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin
export VECLIB_MAXIMUM_THREADS=10 PYTORCH_ENABLE_MPS_FALLBACK=0
fixture() {
 if [[ "$1" == qwen ]]; then echo "$root/outputs/qwen-training-comparison/fixture"
 else echo "$root/outputs/gemma-video-gap-2026-11-07/tiny-gemma"; fi
}
run() {
 engine="$1";backend="$2";model="$3";dtype="$4";phase="$5";trial="$6"
 result="$out/$phase-$backend-$model-$dtype-$engine-$trial"
 reference="$backend";if [[ "$backend" == metal ]];then reference=mps;fi
 if [[ "$engine" == deepj ]];then
  "$py" -B "$root/outputs/media-throughput-2026-11-07/run_guarded.py" --timeout 60 --rss-gib 2 --swap-mib 64 --log "$result.log" -- \
   "$jdk/java" -Xmx1g -Xbatch -XX:CompileThresholdScaling=0.1 --enable-native-access=ALL-UNNAMED \
   -cp "$jar:$out" io.github.kirstenali.deepj.nn.transformer.qwen3.CompactTrainingProbe \
   "$model" "$(fixture "$model")" "$dtype" "$backend" "$result" "$phase"
 else
  "$py" -B "$root/outputs/media-throughput-2026-11-07/run_guarded.py" --timeout 60 --rss-gib 2 --swap-mib 64 --log "$result.log" -- \
   "$py" -B "$out/compact_training.py" "$model" "$(fixture "$model")" "$dtype" "$reference" "$result" "$phase"
 fi
}
for backend in cpu metal;do
 for model in qwen gemma;do
  for dtype in FLOAT16 BFLOAT16;do
   run deepj "$backend" "$model" "$dtype" audit 0
   run python "$backend" "$model" "$dtype" audit 0
  done
 done
done
echo AUDITS_COMPLETE
"$py" -B "$out/check_audits.py" > "$out/audit-summary.log" 2>&1
for trial in 1 2;do
 for backend in cpu metal;do
  for model in qwen gemma;do
   for dtype in FLOAT16 BFLOAT16;do
    if [[ "$trial" == 1 ]];then
     run deepj "$backend" "$model" "$dtype" measure "$trial"
     run python "$backend" "$model" "$dtype" measure "$trial"
    else
     run python "$backend" "$model" "$dtype" measure "$trial"
     run deepj "$backend" "$model" "$dtype" measure "$trial"
    fi
   done
  done
 done
done
echo COMPACT_TRAINING_COMPLETE

