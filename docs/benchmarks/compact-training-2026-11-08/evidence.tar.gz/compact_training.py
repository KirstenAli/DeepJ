"""Small decoder AMP training reference using the existing FP32 benchmark fixtures."""
import argparse
import json
import math
import statistics
import time
from pathlib import Path
import torch
import transformers
from safetensors.torch import load_file, save_file
from transformers import Gemma2Config, Gemma2ForCausalLM, Qwen3Config, Qwen3ForCausalLM


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('model', choices=['qwen', 'gemma'])
    parser.add_argument('fixture', type=Path)
    parser.add_argument('dtype', choices=['FLOAT16', 'BFLOAT16'])
    parser.add_argument('backend', choices=['cpu', 'mps'])
    parser.add_argument('output', type=Path)
    parser.add_argument('phase', choices=['audit', 'measure'])
    return parser.parse_args()


def load(args, dtype):
    config_type, model_type = (Qwen3Config, Qwen3ForCausalLM) if args.model == 'qwen' else (Gemma2Config, Gemma2ForCausalLM)
    config = config_type.from_pretrained(args.fixture, local_files_only=True)
    config._attn_implementation = 'sdpa' if args.model == 'qwen' else 'eager'
    if args.model == 'qwen': config.sliding_window = None
    model = model_type(config)
    state = load_file(args.fixture / 'model.safetensors')
    state['lm_head.weight'] = state['model.embed_tokens.weight']
    model.load_state_dict(state, strict=True); model.tie_weights()
    model.to(device=args.backend, dtype=torch.float32).train()
    with torch.no_grad():
        for parameter in model.parameters(): parameter.copy_(parameter.to(dtype).float())
    return model


def sync(backend):
    if backend == 'mps': torch.mps.synchronize()


def snapshot(values, output, name):
    save_file({key: value.detach().float().cpu().contiguous() for key, value in values.items()}, output / name)


def clip(parameters):
    norm = torch.nn.utils.get_total_norm([parameter.grad for parameter in parameters]).item()
    if not math.isfinite(norm): raise ValueError('Non-finite gradient')
    if norm > 1: torch._foreach_mul_([parameter.grad for parameter in parameters], 1 / (norm + 1e-12))


def step(model, optimizer, named, tokens, targets, args, dtype, scale):
    optimizer.zero_grad(set_to_none=False)
    with torch.autocast(args.backend, dtype=dtype):
        logits = model(tokens, use_cache=False).logits.flatten(0, 1)
        loss = torch.nn.functional.cross_entropy(logits.float(), targets)
    if args.phase == 'audit': snapshot({'logits': logits}, args.output, 'logits.safetensors')
    (loss * scale).backward()
    value = loss.item()
    if not math.isfinite(value): raise ValueError('Non-finite loss')
    if scale != 1: torch._foreach_mul_([p.grad for p in named.values()], 1 / scale)
    if args.phase == 'audit': snapshot({n: p.grad for n, p in named.items()}, args.output, 'gradients.safetensors')
    clip(list(named.values())); optimizer.step()
    return value


def measure(args, model, dtype, tokens, targets):
    named = dict(sorted(model.named_parameters()))
    optimizer = torch.optim.AdamW(named.values(), lr=1e-4, betas=(.9, .999), eps=1e-8, weight_decay=.01)
    scale = 128 if dtype == torch.float16 else 1
    warmups, samples = (0, 1) if args.phase == 'audit' else (100, 30)
    times, losses = [], []; sync(args.backend)
    for iteration in range(-warmups, samples):
        start = time.perf_counter_ns()
        value = step(model, optimizer, named, tokens, targets, args, dtype, scale)
        sync(args.backend); elapsed = (time.perf_counter_ns() - start) / 1e6
        losses.append(value)
        if iteration >= 0: times.append(elapsed)
    snapshot(named, args.output, 'masters.safetensors')
    snapshot({name: value.to(dtype) for name, value in named.items()}, args.output, 'weights.safetensors')
    return dict(engine='PyTorch AMP', backend=args.backend, model=args.model, dtype=args.dtype,
                warmups=warmups, samples=samples, ms=times, median_ms=statistics.median(times), losses=losses,
                loss_scale=scale, parameters=sum(p.numel() for p in named.values()),
                gradients_dtype='FLOAT32', optimizer_dtype='FLOAT32')


def main():
    args = arguments(); args.output.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(10); torch.set_num_interop_threads(1)
    if args.backend == 'mps' and not torch.backends.mps.is_available(): raise RuntimeError('Physical MPS required')
    dtype = torch.float16 if args.dtype == 'FLOAT16' else torch.bfloat16
    model = load(args, dtype)
    data = json.loads((args.fixture / 'input.json').read_text())
    tokens = torch.tensor([data['tokens']], device=args.backend)
    targets = torch.tensor(data['targets'], device=args.backend)
    result = measure(args, model, dtype, tokens, targets)
    result.update(torch=torch.__version__, transformers=transformers.__version__, precision_policy='autocast')
    (args.output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__': main()
