"""Untimed CPU operator diagnosis; these profiler timings are not benchmark rows."""
import json
import warnings
from pathlib import Path
from types import SimpleNamespace
import torch
import compact_training as reference

root = Path(__file__).resolve().parents[2]
output = Path(__file__).resolve().parent
torch.set_num_threads(10)
torch.set_num_interop_threads(1)
warnings.filterwarnings('ignore', message='In CPU autocast.*')
summaries = {}
for label, dtype in [('FLOAT32', torch.float32), ('FLOAT16', torch.float16), ('BFLOAT16', torch.bfloat16)]:
    args = SimpleNamespace(model='qwen', fixture=root / 'outputs/qwen-training-comparison/fixture',
                           backend='cpu', dtype=label, phase='measure', output=output)
    model = reference.load(args, dtype)
    named = dict(sorted(model.named_parameters()))
    optimizer = torch.optim.AdamW(named.values(), lr=1e-4, betas=(.9, .999), eps=1e-8, weight_decay=.01)
    data = json.loads((args.fixture / 'input.json').read_text())
    tokens, targets = torch.tensor([data['tokens']]), torch.tensor(data['targets'])
    scale = 128 if dtype == torch.float16 else 1
    for _ in range(10): reference.step(model, optimizer, named, tokens, targets, args, dtype, scale)
    with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU], record_shapes=True) as profiler:
        for _ in range(3): reference.step(model, optimizer, named, tokens, targets, args, dtype, scale)
    averages = profiler.key_averages()
    (output / f'profile-{label}.txt').write_text(averages.table(sort_by='self_cpu_time_total', row_limit=20))
    summaries[label] = [{'operator': value.key, 'self_cpu_us': value.self_cpu_time_total,
                         'total_cpu_us': value.cpu_time_total, 'calls': value.count}
                        for value in sorted(averages, key=lambda value: value.self_cpu_time_total, reverse=True)]
(output / 'cpu-operator-profile.json').write_text(json.dumps(summaries, indent=2) + '\n')
