#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/demo-compact"
python="$root/outputs/cpu-throughput/reference-env/bin/python"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
export PYTHONPATH="$root/work/deepj-qwen-thinking/src/test/python"
export PYTORCH_ENABLE_MPS_FALLBACK=0
export VECLIB_MAXIMUM_THREADS=10
"$python" "$root/outputs/cpu-throughput/run_guarded.py" --log "$out/profile-FLOAT16.jsonl" \
 --timeout 80 --rss-gib 8 --swap-mib 128 -- "$java" -Xmx6g --enable-native-access=ALL-UNNAMED \
 -Dprobe.compact=true -cp "$root/outputs/compact-performance/classes:$out/profile-candidate.jar" \
 io.github.kirstenali.deepj.nn.transformer.qwen3.FullStageProbe \
 /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B metal FLOAT16 \
 "$root/outputs/qwen3-1p7b/benchmark-input.json" 10 5 3
for dtype in FLOAT16 BFLOAT16; do
 for engine in deepj pytorch; do
  if [[ "$engine" == deepj ]]; then
   command=("$java" -Xmx6g --enable-native-access=ALL-UNNAMED -cp "$out/classes:$out/readback-candidate.jar"
    ChatDemoProbe /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B "$dtype" "$out/chat-input-$dtype.json")
  else
   command=("$python" -B "$out/chat_reference.py" /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B mps
    "$out/chat-input-$dtype.json" "$dtype")
  fi
  "$python" "$root/outputs/cpu-throughput/run_guarded.py" --log "$out/chat-$dtype-$engine.jsonl" \
   --timeout 90 --rss-gib 8 --swap-mib 128 -- "${command[@]}"
  echo "CHAT_PROBE_COMPLETE $dtype $engine"
 done
done
