#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/demo-compact"
python="$root/outputs/cpu-throughput/reference-env/bin/python"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
export PYTHONPATH="$root/work/deepj-qwen-thinking/src/test/python"
export PYTORCH_ENABLE_MPS_FALLBACK=0
export VECLIB_MAXIMUM_THREADS=10
for pair in 1 2; do
 engines=(deepj pytorch); if [[ "$pair" == 2 ]]; then engines=(pytorch deepj); fi
 for dtype in FLOAT16 BFLOAT16; do
  for engine in "${engines[@]}"; do
   stem="$out/output-only-pair$pair-$dtype-$engine"
   if [[ "$engine" == deepj ]]; then
    command=("$java" -Xmx6g --enable-native-access=ALL-UNNAMED -Dprobe.compact=true "-Dprobe.logits=$stem.bin"
     -cp "$root/outputs/compact-performance/classes:$out/output-only-candidate.jar"
     io.github.kirstenali.deepj.nn.transformer.qwen3.FullPrecisionProbe
     /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B metal "$dtype"
     "$root/outputs/qwen3-1p7b/benchmark-input.json" 10 5 5)
   else
    command=("$python" -B "$root/outputs/compact-performance/full_reference.py"
     /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B mps
     "$root/outputs/qwen3-1p7b/benchmark-input.json" "$dtype" "$stem.bin")
   fi
   "$python" "$root/outputs/cpu-throughput/run_guarded.py" --log "$stem.jsonl" \
    --timeout 80 --rss-gib 8 --swap-mib 128 -- "${command[@]}"
   echo "FINAL_MATCHED_COMPLETE $pair $dtype $engine"
  done
 done
done
for dtype in FLOAT16 BFLOAT16; do
 for engine in pytorch deepj; do
  if [[ "$engine" == deepj ]]; then
   command=("$java" -Xmx6g --enable-native-access=ALL-UNNAMED -cp "$out/classes:$out/output-only-candidate.jar"
    ChatDemoProbe /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B "$dtype" "$out/chat-input-$dtype.json")
  else
   command=("$python" -B "$out/chat_reference.py" /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B mps
    "$out/chat-input-$dtype.json" "$dtype")
  fi
  "$python" "$root/outputs/cpu-throughput/run_guarded.py" --log "$out/output-only-chat-$dtype-$engine.jsonl" \
   --timeout 90 --rss-gib 8 --swap-mib 128 -- "${command[@]}"
  echo "FINAL_CHAT_COMPLETE $dtype $engine"
 done
done
for backend in cpu metal; do
 for model in qwen loop prism; do
  "$python" "$root/outputs/cpu-throughput/run_guarded.py" --log "$out/output-only-control-$backend-$model.json" \
   --timeout 60 --rss-gib 3 --swap-mib 128 -- "$java" --enable-native-access=ALL-UNNAMED -Xmx1g \
   -Xbatch -XX:CompileThresholdScaling=0.1 -Dprobe.warmups=100 -Dprobe.samples=30 \
   -cp "$root/outputs/qwen-inference-optimizations:$out/output-only-candidate.jar" \
   QuickProbe "$backend" "$model" training
  echo "FP32_CONTROL_COMPLETE $backend $model"
 done
done
