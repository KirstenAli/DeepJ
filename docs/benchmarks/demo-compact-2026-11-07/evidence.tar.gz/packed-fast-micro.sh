#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/demo-compact"
python="$root/outputs/cpu-throughput/reference-env/bin/python"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
for variant in hardware packed-fast; do
 "$python" "$root/outputs/cpu-throughput/run_guarded.py" --log "$out/$variant-matvec.log" \
  --timeout 90 --rss-gib 4 --swap-mib 128 -- "$java" -Xbatch -XX:CompileThresholdScaling=0.1 -Xmx1g --enable-native-access=ALL-UNNAMED \
  -cp "$out/classes:$out/$variant-candidate.jar" PackedVectorProbe
 echo "PACKED_VECTOR_PROBE_COMPLETE $variant"
done
