import io.github.kirstenali.deepj.autograd.GradMode;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;
import java.util.*;

public final class PackedVectorProbe {
    public static void main(String[] args) {
        var backend = new MetalBackend();
        Tensor.setBackend(backend);
        try (var ignored = GradMode.noGrad()) {
            for (DType dtype : new DType[]{DType.FLOAT16, DType.BFLOAT16}) {
                for (int[] shape : new int[][]{{2048,2048},{2048,6144},{6144,2048},{2048,151936}}) {
                    run(dtype, shape[0], shape[1]);
                    System.gc(); backend.releaseTemporaryResources();
                }
            }
        } finally { backend.releaseResources(); }
    }
    private static void run(DType dtype, int inner, int columns) {
        Tensor input = Tensor.backend().zeros(dtype, 1, inner).addScalar(1).retainDeviceBuffer();
        Tensor weight = Tensor.backend().zeros(dtype, columns, inner).addScalar(1).transpose(0,1).retainDeviceBuffer();
        double[] times = new double[7];
        float checksum=0;
        for (int trial=-3;trial<times.length;trial++) {
            long start = System.nanoTime();
            try (var scratch=BackwardBuffers.begin()) {
                Tensor output = scratch.capture(() -> products(input, weight));
                float[] row = output.toFloatArray();
                double micros=(System.nanoTime()-start)/20000.0;
                if (trial>=0) times[trial]=micros;
                checksum += row[0];
            }
            Tensor.backend().releaseTemporaryResources();
        }
        Arrays.sort(times);
        System.out.printf(Locale.ROOT,"%s inner=%d columns=%d median_us=%.3f checksum=%.3f%n",dtype,inner,columns,times[3],checksum);
        input.releaseDeviceBufferRetention(); weight.releaseDeviceBufferRetention();
        Tensor.backend().releaseTemporaryResources();
    }
    private static Tensor products(Tensor input, Tensor weight) {
        Tensor result=null;
        for(int i=0;i<20;i++) result=Tensor.backend().matmul(input,weight);
        return result;
    }
}
