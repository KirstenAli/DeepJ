#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/demo-compact"
python="$root/outputs/cpu-throughput/reference-env/bin/python"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
for dtype in FLOAT16 BFLOAT16; do
 for variant in baseline readback executable; do
  jar="$out/$variant-candidate.jar"
  if [[ "$variant" == baseline ]]; then jar="$root/outputs/compact-followup/combined-candidate.jar"; fi
  "$python" "$root/outputs/cpu-throughput/run_guarded.py" --log "$out/initial-$dtype-$variant.jsonl" \
   --timeout 70 --rss-gib 8 --swap-mib 128 -- "$java" -Xmx6g --enable-native-access=ALL-UNNAMED \
   -Dprobe.compact=true -cp "$root/outputs/compact-performance/classes:$jar" \
   io.github.kirstenali.deepj.nn.transformer.qwen3.FullStageProbe \
   /Users/kirstenali/Documents/Codex/models/Qwen3-1.7B metal "$dtype" \
   "$root/outputs/qwen3-1p7b/benchmark-input.json" 10 2 3
  echo "INITIAL_PROBE_COMPLETE $dtype $variant"
 done
done
