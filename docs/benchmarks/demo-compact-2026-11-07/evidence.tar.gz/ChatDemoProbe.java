import io.github.kirstenali.deepj.concurrent.DeepJExecutor;
import io.github.kirstenali.deepj.nn.transformer.ContextWindowMode;
import io.github.kirstenali.deepj.nn.transformer.qwen3.Qwen3ChatModel;
import io.github.kirstenali.deepj.persistence.qwen3.Qwen3Json;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;
import io.github.kirstenali.deepj.tokenizers.qwen3.Qwen3Chat;
import java.nio.file.*;
import java.util.*;

public final class ChatDemoProbe {
    private static final String PROMPT = "Explain how Java garbage collection works, including the heap, generations, and pauses. Use clear paragraphs.";
    public static void main(String[] args) throws Exception {
        if (!MetalBackend.isAvailable()) throw new IllegalStateException("Physical Metal required");
        Tensor.setBackend(new MetalBackend());
        DeepJExecutor.setNumThreads(10);
        var chat = Qwen3ChatModel.load(Path.of(args[0]), DType.valueOf(args[1]));
        String formatted = Qwen3Chat.format(List.of(new Qwen3Chat.Message(Qwen3Chat.Role.USER, PROMPT)), true, false);
        Files.writeString(Path.of(args[2]), Qwen3Json.stringify(Map.of("prompt", PROMPT,
                "prompt_ids", Arrays.stream(chat.tokenizer().encode(formatted)).boxed().toList(), "max_new_tokens", 160, "thinking", false)));
        try {
            for (int trial = -2; trial < 2; trial++) run(chat, trial);
        } finally { Tensor.backend().releaseTemporaryResources(); DeepJExecutor.shutdown(); }
    }
    private static void run(Qwen3ChatModel chat, int trial) {
        var timestamps = new ArrayList<Long>();
        long start = System.nanoTime();
        String output = chat.stream(PROMPT, trial == -2 ? 16 : 160, .6f, 1, 42, 1,
                ContextWindowMode.REBUILD, text -> timestamps.add(System.nanoTime()));
        long finish = System.nanoTime();
        var intervals = new ArrayList<Double>();
        for (int i = 1; i < timestamps.size(); i++) intervals.add((timestamps.get(i) - timestamps.get(i - 1)) / 1e6);
        Collections.sort(intervals);
        double seconds = (timestamps.get(timestamps.size() - 1) - timestamps.get(0)) / 1e9;
        System.out.println(Qwen3Json.stringify(Map.of("engine", "DeepJ", "dtype", chat.model().parameters().get(0).value.dtype().name(),
                "trial", trial, "tokens", timestamps.size(), "tokens_per_second", (timestamps.size() - 1) / seconds,
                "first_token_ms", (timestamps.get(0) - start) / 1e6, "total_seconds", (finish - start) / 1e9,
                "median_gap_ms", intervals.get(intervals.size() / 2),
                "max_gap_ms", intervals.get(intervals.size() - 1), "response", output)));
    }
}
