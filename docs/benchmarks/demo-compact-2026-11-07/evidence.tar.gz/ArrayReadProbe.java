import io.github.kirstenali.deepj.tensor.*;
import java.util.*;

public final class ArrayReadProbe {
    private static volatile float checksum;

    public static void main(String[] args) {
        for (DType dtype : DType.values()) {
            Tensor tensor = Tensor.random(dtype, new Random(1), 1, 151936);
            measure(tensor, false);
            measure(tensor, true);
        }
    }

    private static void measure(Tensor tensor, boolean row) {
        double[] samples = new double[200];
        for (int trial = -100; trial < samples.length; trial++) {
            long start = System.nanoTime();
            float[] values = row ? tensor.rowData(0) : tensor.toFloatArray();
            double micros = (System.nanoTime() - start) / 1000.0;
            checksum += values[trial & 127];
            if (trial >= 0) samples[trial] = micros;
        }
        Arrays.sort(samples);
        System.out.printf(Locale.ROOT, "%s %s median_us=%.3f min_us=%.3f%n", tensor.dtype(),
                row ? "rowData" : "toFloatArray", samples[100], samples[0]);
    }
}
