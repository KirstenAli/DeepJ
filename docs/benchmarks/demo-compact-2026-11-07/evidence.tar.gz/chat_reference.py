"""Same reference forward/timing; restore one FP32 tensor at a time to bound peak memory."""
import json
import sys
from pathlib import Path
import torch
import transformers
from safetensors import safe_open
import qwen3_benchmark as reference

root, device, path = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
name=sys.argv[4]
dtype={'FLOAT32':torch.float32,'FLOAT16':torch.float16,'BFLOAT16':torch.bfloat16}[name]
torch.set_num_threads(10)
torch.set_num_interop_threads(1)
config = reference.Qwen3Config.from_pretrained(root, local_files_only=True)
config._attn_implementation = 'sdpa'
with torch.device('meta'):
    model = reference.Qwen3ForCausalLM(config)
names = sorted(set(json.loads((root / 'model.safetensors.index.json').read_text())['weight_map'].values()))
for shard_name in names:
    with safe_open(root / shard_name, framework='pt', device='cpu') as source:
        keys = list(source.keys())
    for key in keys:
        with safe_open(root / shard_name, framework='pt', device='cpu') as source:
            value = source.get_tensor(key).to(device).to(dtype=dtype)
        model.load_state_dict({key: value}, strict=False, assign=True)
        del value
        if device == 'mps':
            torch.mps.synchronize()
            torch.mps.empty_cache()
model.tie_weights()
model.requires_grad_(False).eval()
model.model.rotary_emb = type(model.model.rotary_emb)(config=config, device=device)
assert all(p.dtype == dtype and p.device.type == device for p in model.parameters())
assert model.lm_head.weight is model.model.embed_tokens.weight
print(json.dumps(dict(torch=torch.__version__, transformers=transformers.__version__,
    device=device, dtype=name, threads=torch.get_num_threads(),
    interop=torch.get_num_interop_threads(), attention=config._attn_implementation,
    parameters=sum(p.numel() for p in model.parameters()),
    mps_allocated=torch.mps.current_allocated_memory() if device == 'mps' else 0,
    mps_driver=torch.mps.driver_allocated_memory() if device == 'mps' else 0)), flush=True)

import time
from transformers import AutoTokenizer
from transformers.generation.streamers import BaseStreamer

data=json.loads(path.read_text())
tokenizer=AutoTokenizer.from_pretrained(root,local_files_only=True)
input_ids=torch.tensor([data['prompt_ids']],device=device)
class MeasuredStreamer(BaseStreamer):
    def __init__(self): self.timestamps=[]; self.ids=[]; self.prompt=True; self.text=''
    def put(self, value):
        if self.prompt: self.prompt=False; return
        token=int(value.item())
        if token in [151645,151643]: return
        self.ids.append(token)
        self.text=tokenizer.decode(self.ids,skip_special_tokens=False)
        self.timestamps.append(time.perf_counter())
    def end(self): pass
for trial in range(-2,2):
    streamer=MeasuredStreamer()
    start=time.perf_counter()
    with torch.inference_mode():
        model.generate(input_ids, attention_mask=torch.ones_like(input_ids),
            max_new_tokens=16 if trial==-2 else data['max_new_tokens'],
            do_sample=False, use_cache=True, logits_to_keep=1,
            eos_token_id=[151645,151643],pad_token_id=151643, streamer=streamer)
    torch.mps.synchronize()
    finish=time.perf_counter()
    times=streamer.timestamps
    gaps=sorted((b-a)*1000 for a,b in zip(times,times[1:]))
    print(json.dumps(dict(engine='PyTorch',dtype=name,trial=trial,tokens=len(times),
        tokens_per_second=(len(times)-1)/(times[-1]-times[0]),first_token_ms=(times[0]-start)*1000,
        total_seconds=finish-start,median_gap_ms=gaps[len(gaps)//2],max_gap_ms=max(gaps),
        response=streamer.text)),flush=True)
