#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/gemma-video-gap-2026-11-07"
python="$root/outputs/cpu-throughput/reference-env/bin/python"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
export JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
export PYTORCH_ENABLE_MPS_FALLBACK=0 VECLIB_MAXIMUM_THREADS=10
cd "$root/work/deepj-qwen-thinking"
/opt/homebrew/bin/mvn -o surefire:test '-Dtest=MetalCachedAttentionTest,MetalCachedAttentionValidationTest,Gemma2ReferenceTest,Gemma2PrecisionTest,Gemma2SchedulingTest,Gemma2RotaryTest,MetalNormRepeatabilityTest' -Dgemma.test.metal=true > "$out/fused-tests.log" 2>&1

"$python" "$out/run_guarded.py" --log "$out/gemma-BFLOAT16-fused-pilot.jsonl" --timeout 45 --rss-gib 8 --swap-mib 128 -- "$java" -Xmx3g -Dprobe.nochat=true -Ddeepj.metal.maxBufferBytes=7516192768 --enable-native-access=ALL-UNNAMED -cp "$out/classes:$out/fused-candidate.jar" GemmaDemoProbe "$root/outputs/sana-sprint-readme/model/text_encoder" BFLOAT16 "$out/gemma-input-BFLOAT16.json" "$out/gemma-BFLOAT16-fused-pilot.bin"
"$python" "$out/run_guarded.py" --log "$out/gemma-FLOAT16-fused-pilot.jsonl" --timeout 45 --rss-gib 8 --swap-mib 128 -- "$java" -Xmx3g -Dprobe.nochat=true -Ddeepj.metal.maxBufferBytes=7516192768 --enable-native-access=ALL-UNNAMED -cp "$out/classes:$out/fused-candidate.jar" GemmaDemoProbe "$root/outputs/sana-sprint-readme/model/text_encoder" FLOAT16 "$out/gemma-input-FLOAT16.json" "$out/gemma-FLOAT16-fused-pilot.bin"
echo FUSED_PILOT_COMPLETE
