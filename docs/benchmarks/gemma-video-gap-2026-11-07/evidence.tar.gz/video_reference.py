"""Bounded staged Diffusers SANA-Video benchmark with DeepJ's exact prompt IDs and starting noise."""
import gc,json,sys,time
from pathlib import Path
import numpy as np
from PIL import Image
import torch,diffusers,transformers
from safetensors import safe_open
from diffusers import SanaVideoTransformer3DModel,AutoencoderKLWan,DPMSolverMultistepScheduler
from diffusers.models.transformers.transformer_sana_video import WanRotaryPosEmbed
from transformers import Gemma2Config,Gemma2Model
from transformers.models.gemma2.modeling_gemma2 import Gemma2RotaryEmbedding
root=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
inputs=json.loads((out/'video-input.json').read_text());dtype=torch.bfloat16
torch.set_num_threads(10);torch.set_num_interop_threads(1)
if not torch.backends.mps.is_available():raise RuntimeError('MPS required')
def sync():torch.mps.synchronize()
def clear():gc.collect();torch.mps.empty_cache();sync()
def load(model,directory,kind):
    files=sorted(directory.glob('*.safetensors'))
    for filename in files:
        with safe_open(filename,framework='pt',device='cpu') as source:keys=list(source.keys())
        for key in keys:
            with safe_open(filename,framework='pt',device='cpu') as source:value=source.get_tensor(key).to(device='mps',dtype=kind)
            model.load_state_dict({key:value},strict=False,assign=True);del value
            sync()
    if any(p.is_meta or p.dtype!=kind or p.device.type!='mps' for p in model.parameters()):raise RuntimeError('Incomplete model assignment')
    return model.requires_grad_(False).eval()
def stage(name,start):
    sync();elapsed=time.perf_counter()-start;stages.append(dict(stage=name,seconds=elapsed));print(json.dumps(stages[-1]),flush=True)
start_all=time.perf_counter();stages=[]
with torch.inference_mode():
    start=time.perf_counter();cfg=Gemma2Config.from_pretrained(root/'text_encoder',local_files_only=True);cfg._attn_implementation='eager'
    with torch.device('meta'):model=Gemma2Model(cfg)
    load(model,root/'text_encoder',dtype);model.rotary_emb=Gemma2RotaryEmbedding(cfg).to('mps')
    if hasattr(model.embed_tokens,'embed_scale'):
        model.embed_tokens.embed_scale=torch.tensor(cfg.hidden_size**.5,device='mps',dtype=dtype)
    load_time=time.perf_counter()-start;features={};masks={}
    for name in ['positive','negative']:
        item=inputs[name]
        hidden=model(torch.tensor([item['tokens']],device='mps'),attention_mask=torch.tensor([item['valid']],device='mps'),use_cache=False).last_hidden_state
        features[name]=hidden[:,item['selected']].to(dtype);masks[name]=torch.tensor([item['mask']],device='mps')
    del hidden,model;clear();stage('Gemma load and encode',start)
    stages[-1]['load_seconds']=load_time
    start=time.perf_counter();cfg=json.loads((root/'transformer/config.json').read_text())
    with torch.device('meta'):model=SanaVideoTransformer3DModel.from_config(cfg)
    load(model,root/'transformer',dtype)
    model.rope=WanRotaryPosEmbed(cfg['attention_head_dim'],cfg['patch_size'],cfg['rope_max_seq_len']).to('mps')
    load_time=time.perf_counter()-start
    scheduler=DPMSolverMultistepScheduler.from_pretrained(root/'scheduler',local_files_only=True);scheduler.set_timesteps(1,device='mps')
    latent=torch.from_numpy(np.fromfile(out/'noise.f32',dtype='<f4').reshape(inputs['shape'])).to('mps')
    embeds=torch.cat([features['negative'],features['positive']]);mask=torch.cat([masks['negative'],masks['positive']])
    for timestep in scheduler.timesteps:
        prediction=model(torch.cat([latent]*2).to(dtype),timestep=timestep.expand(2),encoder_hidden_states=embeds,
            encoder_attention_mask=mask,return_dict=False)[0].float()
        negative,positive=prediction.chunk(2);flow=negative+6*(positive-negative)
        latent=scheduler.step(flow,timestep,latent,return_dict=False)[0]
    del model,prediction,positive,negative,features,embeds,masks,mask,flow;clear();stage('Transformer load and one guided step',start)
    stages[-1]['load_seconds']=load_time
    start=time.perf_counter();cfg=json.loads((root/'vae/config.json').read_text())
    with torch.device('meta'):model=AutoencoderKLWan.from_config(cfg)
    load(model,root/'vae',torch.float32);load_time=time.perf_counter()-start
    mean=torch.tensor(cfg['latents_mean'],device='mps').reshape(1,16,1,1,1)
    std=torch.tensor(cfg['latents_std'],device='mps').reshape(1,16,1,1,1)
    video=model.decode(latent.float()*std+mean,return_dict=False)[0]
    pixels=video[0].float().cpu().clamp(-1,1).permute(1,2,3,0).numpy()
    rgb=np.rint((pixels+1)*127.5).clip(0,255).astype('uint8')
    del model,video;clear();stage('Wan load and decode',start);stages[-1]['load_seconds']=load_time
elapsed=time.perf_counter()-start_all
for i,frame in enumerate(rgb):Image.fromarray(frame).save(out/f'python-frame-{i}.png')
result=dict(engine='PyTorch/Diffusers',torch=torch.__version__,transformers=transformers.__version__,diffusers=diffusers.__version__,
    backend='mps',dtype='BFLOAT16',frames=5,width=192,height=128,steps=1,guidance=6,stages=stages,generation_seconds=elapsed,
    guidance_batch=2,vae_dtype='FLOAT32',sampler_dtype='FLOAT32')
(out/'python-video-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
