import sys,time,json
from pathlib import Path
import numpy as np
from PIL import Image
import torch
from diffusers import AutoencoderKLWan
root=Path(sys.argv[1]);out=Path(sys.argv[3]);out.mkdir(parents=True,exist_ok=True)
torch.set_num_threads(10);torch.set_num_interop_threads(1)
if not torch.backends.mps.is_available():raise RuntimeError('MPS required')
noise=torch.from_numpy(np.fromfile(sys.argv[2],dtype='<f4').reshape(1,16,2,16,24)).to('mps')
start=time.perf_counter();model=AutoencoderKLWan.from_pretrained(root,torch_dtype=torch.float32,local_files_only=True).to('mps').requires_grad_(False).eval()
mean=torch.tensor(model.config.latents_mean,device='mps').reshape(1,16,1,1,1)
std=torch.tensor(model.config.latents_std,device='mps').reshape(1,16,1,1,1);torch.mps.synchronize();load_seconds=time.perf_counter()-start
seconds=[]
with torch.inference_mode():
 for trial in range(2):
  start=time.perf_counter();video=model.decode(noise*std+mean,return_dict=False)[0]
  pixels=video[0].float().cpu().clamp(-1,1).permute(1,2,3,0).numpy();rgb=np.rint((pixels+1)*127.5).clip(0,255).astype('uint8')
  torch.mps.synchronize();seconds.append(time.perf_counter()-start+(load_seconds if trial==0 else 0))
  if trial==1:
   for i,frame in enumerate(rgb):Image.fromarray(frame).save(out/f'frame-{i}.png')
result=dict(engine='PyTorch',torch=torch.__version__,seconds=seconds,load_seconds=load_seconds,frames=5,width=192,height=128,dtype='FLOAT32')
(out/'result.json').write_text(json.dumps(result));print(json.dumps(result),flush=True)
