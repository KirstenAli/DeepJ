#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/gemma-video-gap-2026-11-07"
python="$root/outputs/cpu-throughput/reference-env/bin/python"
java=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java
export VECLIB_MAXIMUM_THREADS=10 PYTORCH_ENABLE_MPS_FALLBACK=0

"$python" "$out/run_guarded.py" --log "$out/train-cpu-deepj-standard-1.jsonl" --timeout 30 --rss-gib 3 --swap-mib 128 -- "$java" -Xmx1g --enable-native-access=ALL-UNNAMED -cp "$out/classes:$root/work/deepj-qwen-thinking/target/deepj-cli.jar" GemmaTrainingProbe cpu "$out/tiny-gemma" "$out/train-cpu-deepj-standard-1.safetensors"
"$python" "$out/run_guarded.py" --log "$out/train-cpu-python-standard-1.jsonl" --timeout 30 --rss-gib 3 --swap-mib 128 -- "$python" -B "$out/gemma_training.py" "$out/tiny-gemma" cpu "$out/train-cpu-python-standard-1.safetensors"
"$python" "$out/run_guarded.py" --log "$out/train-cpu-python-standard-2.jsonl" --timeout 30 --rss-gib 3 --swap-mib 128 -- "$python" -B "$out/gemma_training.py" "$out/tiny-gemma" cpu "$out/train-cpu-python-standard-2.safetensors"
"$python" "$out/run_guarded.py" --log "$out/train-cpu-deepj-standard-2.jsonl" --timeout 30 --rss-gib 3 --swap-mib 128 -- "$java" -Xmx1g --enable-native-access=ALL-UNNAMED -cp "$out/classes:$root/work/deepj-qwen-thinking/target/deepj-cli.jar" GemmaTrainingProbe cpu "$out/tiny-gemma" "$out/train-cpu-deepj-standard-2.safetensors"
"$python" "$out/run_guarded.py" --log "$out/train-metal-deepj-standard-1.jsonl" --timeout 30 --rss-gib 3 --swap-mib 128 -- "$java" -Xmx1g --enable-native-access=ALL-UNNAMED -cp "$out/classes:$root/work/deepj-qwen-thinking/target/deepj-cli.jar" GemmaTrainingProbe metal "$out/tiny-gemma" "$out/train-metal-deepj-standard-1.safetensors"
"$python" "$out/run_guarded.py" --log "$out/train-metal-python-standard-1.jsonl" --timeout 30 --rss-gib 3 --swap-mib 128 -- "$python" -B "$out/gemma_training.py" "$out/tiny-gemma" mps "$out/train-metal-python-standard-1.safetensors"
"$python" "$out/run_guarded.py" --log "$out/train-metal-python-standard-2.jsonl" --timeout 30 --rss-gib 3 --swap-mib 128 -- "$python" -B "$out/gemma_training.py" "$out/tiny-gemma" mps "$out/train-metal-python-standard-2.safetensors"
"$python" "$out/run_guarded.py" --log "$out/train-metal-deepj-standard-2.jsonl" --timeout 30 --rss-gib 3 --swap-mib 128 -- "$java" -Xmx1g --enable-native-access=ALL-UNNAMED -cp "$out/classes:$root/work/deepj-qwen-thinking/target/deepj-cli.jar" GemmaTrainingProbe metal "$out/tiny-gemma" "$out/train-metal-deepj-standard-2.safetensors"
echo STANDARD_TRAINING_COMPLETE
