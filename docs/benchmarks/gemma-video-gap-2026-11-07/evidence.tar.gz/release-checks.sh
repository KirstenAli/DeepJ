#!/bin/bash
set -euo pipefail
root=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj
out="$root/outputs/gemma-video-gap-2026-11-07"
export JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
export VECLIB_MAXIMUM_THREADS=10
cd "$root/work/deepj-qwen-thinking"
/opt/homebrew/bin/mvn -o verify -Pcli -Dgemma.test.metal=true > "$out/release-verify.log" 2>&1
"$JAVA_HOME/bin/java" --enable-native-access=ALL-UNNAMED -jar target/deepj-cli.jar --help > "$out/packaged-cli-help.log" 2>&1
bash "$out/standard-training.sh"
echo RELEASE_CHECKS_COMPLETE
