"""Small FP32 Gemma complete-step comparison; never loads the full checkpoint."""
import json,sys,time,statistics,math
from pathlib import Path
import numpy as np
import torch,transformers
from transformers import Gemma2Config,Gemma2ForCausalLM
from safetensors.torch import save_file,load_file
root=Path(sys.argv[1]);mode=sys.argv[2]
torch.set_num_threads(10);torch.set_num_interop_threads(1)
if mode=='fixture':
    root.mkdir(parents=True,exist_ok=True);torch.manual_seed(2026)
    cfg=Gemma2Config(vocab_size=256,hidden_size=256,intermediate_size=512,num_hidden_layers=2,
        num_attention_heads=4,num_key_value_heads=2,head_dim=64,max_position_embeddings=128,
        sliding_window=32,query_pre_attn_scalar=64,attn_logit_softcapping=50.,final_logit_softcapping=30.,
        hidden_activation='gelu_pytorch_tanh',attention_dropout=0.,rms_norm_eps=1e-6)
    cfg._attn_implementation='eager';model=Gemma2ForCausalLM(cfg)
    cfg.save_pretrained(root);save_file({n:p.detach().contiguous() for n,p in model.named_parameters()},root/'model.safetensors')
    ids=np.random.RandomState(42).randint(0,256,65).tolist()
    (root/'input.json').write_text(json.dumps(dict(tokens=ids[:-1],targets=ids[1:])))
    print('FIXTURE_PARAMETERS',sum(p.numel() for p in model.parameters()));sys.exit()
device=mode;cfg=Gemma2Config.from_pretrained(root,local_files_only=True);cfg._attn_implementation='eager'
model=Gemma2ForCausalLM(cfg);model.load_state_dict(load_file(root/'model.safetensors'),strict=False)
model.to(device=device,dtype=torch.float32).train();model.tie_weights()
optimizer=torch.optim.AdamW(model.parameters(),lr=1e-4,betas=(.9,.999),eps=1e-8,weight_decay=.01)
data=json.loads((root/'input.json').read_text());tokens=torch.tensor([data['tokens']],device=device);targets=torch.tensor(data['targets'],device=device)
ms=[];losses=[];warmups=100;samples=30
for step in range(-warmups,samples):
    start=time.perf_counter();optimizer.zero_grad(set_to_none=True)
    logits=model(tokens,use_cache=False).logits.reshape(-1,256)
    loss=torch.nn.functional.cross_entropy(logits,targets);loss.backward()
    value=float(loss.detach().cpu())
    if not math.isfinite(value):raise RuntimeError('Non-finite loss')
    torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True)
    optimizer.step()
    if device=='mps':torch.mps.synchronize()
    elapsed=(time.perf_counter()-start)*1000;losses.append(value)
    if step>=0:ms.append(elapsed)
print(json.dumps(dict(engine='PyTorch',backend=device,dtype='FLOAT32',torch=torch.__version__,transformers=transformers.__version__,
    parameters=sum(p.numel() for p in model.parameters()),warmups=warmups,samples=samples,ms=ms,median_ms=statistics.median(ms),
    losses=losses,clipping='torch.nn.utils.clip_grad_norm_',nonfinite_checks=True,optimizer_foreach=optimizer.param_groups[0]['foreach'],optimizer_fused=optimizer.param_groups[0]['fused'])),flush=True)
if len(sys.argv)>3:save_file({n:p.detach().float().cpu().contiguous() for n,p in model.named_parameters()},sys.argv[3])
