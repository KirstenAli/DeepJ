package io.github.kirstenali.deepj.nn.diffusion.sanavideo;
import io.github.kirstenali.deepj.tokenizers.gemma.GemmaTokenizer;
import io.github.kirstenali.deepj.persistence.qwen3.Qwen3Json;
import java.nio.*;
import java.nio.file.*;
import java.util.*;
public final class VideoInputs {
 public static void main(String[] args) throws Exception {
  Path root=Path.of(args[0]),out=Path.of(args[1]);Files.createDirectories(out);
  String prompt="A small red fox walks slowly through a sunny green meadow. Clear natural daylight, detailed fur, steady camera. motion score: 30.";
  var tokenizer=new GemmaTokenizer(root.resolve("tokenizer"));
  Files.writeString(out.resolve("video-input.json"),Qwen3Json.stringify(Map.of("prompt",prompt,"positive",caption(new SanaVideoPrompt(tokenizer,prompt,true)),"negative",caption(new SanaVideoPrompt(tokenizer,"",false)),"shape",List.of(1,16,2,16,24))));
  var random=new Random(42);var bytes=ByteBuffer.allocate(16*2*16*24*4).order(ByteOrder.LITTLE_ENDIAN);
  for(int i=0;i<16*2*16*24;i++)bytes.putFloat((float)random.nextGaussian());
  Files.write(out.resolve("noise.f32"),bytes.array());
 }
 private static Map<String,Object> caption(SanaVideoPrompt p){return Map.of("tokens",ids(p.tokens()),"valid",ids(p.valid()),"selected",ids(p.selected()),"mask",ids(p.mask()));}
 private static List<Integer> ids(int[] v){return Arrays.stream(v).boxed().toList();}
}
