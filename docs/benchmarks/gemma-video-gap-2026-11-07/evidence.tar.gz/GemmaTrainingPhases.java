import io.github.kirstenali.deepj.concurrent.DeepJExecutor;
import io.github.kirstenali.deepj.data.Batch;
import io.github.kirstenali.deepj.nn.transformer.gemma2.*;
import io.github.kirstenali.deepj.persistence.qwen3.Qwen3Json;
import io.github.kirstenali.deepj.persistence.qwen3.SafeTensorWriter;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.cpu.CpuBackend;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;
import io.github.kirstenali.deepj.training.CausalLMTraining;
import java.nio.file.*;
import java.util.*;
public final class GemmaTrainingPhases {
 public static void main(String[] args) throws Exception {
  boolean metal=args[0].equals("metal");
  if(metal&&!MetalBackend.isAvailable())throw new IllegalStateException("Physical Metal required");
  Tensor.setBackend(metal?new MetalBackend():new CpuBackend());DeepJExecutor.setNumThreads(10);
  try(var model=Gemma2Pretrained.load(Path.of(args[1]),DType.FLOAT32)) {run(model,args);}
  finally{Tensor.backend().releaseTemporaryResources();DeepJExecutor.shutdown();}
 }
 private static void run(Gemma2 model,String[] args) throws Exception {
  var data=Qwen3Json.read(Path.of(args[1],"input.json"));
  int[] tokens=ids(data.get("tokens")),targets=ids(data.get("targets"));
  var optimizer=io.github.kirstenali.deepj.optimisers.AdamW.defaultAdamW(1e-4f);
  var phases=new ArrayList<java.util.List<Double>>();
  for(int step=-100;step<30;step++) {
   long start=System.nanoTime();model.zeroGrad();
   Tensor logits=model.forward(tokens);
   Tensor loss=io.github.kirstenali.deepj.loss.CrossEntropyLoss.forward(logits,targets,null);
   long forward=System.nanoTime();loss.backward();float value=loss.item();
   long backward=System.nanoTime();var params=model.parameters();
   var gradients=params.stream().map(p->p.grad()).filter(Objects::nonNull).toList();
   float norm=Tensor.backend().l2Norm(gradients);
   if(norm>model.gradClipNorm()) for(Tensor gradient:gradients)gradient.multiplyScalarInPlace(model.gradClipNorm()/(norm+1e-12f));
   long clipping=System.nanoTime();optimizer.step(params);Tensor.backend().releaseTemporaryResources();
   long update=System.nanoTime();
   if(step>=0)phases.add(java.util.List.of((forward-start)/1e6,(backward-forward)/1e6,(clipping-backward)/1e6,(update-clipping)/1e6));
  }
  System.out.println(Qwen3Json.stringify(Map.of("engine","DeepJ","backend",args[0],"phases",phases)));
  if(args.length>2)save(model,Path.of(args[2]));
 }
 private static int[] ids(Object value){return Qwen3Json.array(value).stream().mapToInt(x->Math.toIntExact(Qwen3Json.integer(x))).toArray();}
 private static void save(Gemma2 model,Path path) throws Exception {
  var state=new LinkedHashMap<String,Tensor>();model.parameters().forEach(p->state.put(p.name(),p.value));SafeTensorWriter.write(path,state);
 }
}
