import io.github.kirstenali.deepj.concurrent.DeepJExecutor;
import io.github.kirstenali.deepj.data.Batch;
import io.github.kirstenali.deepj.nn.transformer.gemma2.*;
import io.github.kirstenali.deepj.persistence.qwen3.Qwen3Json;
import io.github.kirstenali.deepj.persistence.qwen3.SafeTensorWriter;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.cpu.CpuBackend;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;
import io.github.kirstenali.deepj.training.CausalLMTraining;
import java.nio.file.*;
import java.util.*;
public final class GemmaTrainingProbe {
 public static void main(String[] args) throws Exception {
  boolean metal=args[0].equals("metal");
  if(metal&&!MetalBackend.isAvailable())throw new IllegalStateException("Physical Metal required");
  Tensor.setBackend(metal?new MetalBackend():new CpuBackend());DeepJExecutor.setNumThreads(10);
  try(var model=Gemma2Pretrained.load(Path.of(args[1]),DType.FLOAT32)) {run(model,args);}
  finally{Tensor.backend().releaseTemporaryResources();DeepJExecutor.shutdown();}
 }
 private static void run(Gemma2 model,String[] args) throws Exception {
  var data=Qwen3Json.read(Path.of(args[1],"input.json"));
  int[] tokens=ids(data.get("tokens")),targets=ids(data.get("targets"));
  var trainer=CausalLMTraining.trainer(model,n->new Batch(new int[][]{tokens},new int[][]{targets}),1e-4f);
  var times=new ArrayList<Double>();var losses=new ArrayList<Float>();
  for(int step=-100;step<30;step++) {
   long start=System.nanoTime();float loss=trainer.trainStep(1);Tensor.backend().releaseTemporaryResources();
   double ms=(System.nanoTime()-start)/1e6;losses.add(loss);if(step>=0)times.add(ms);
  }
  System.out.println(Qwen3Json.stringify(Map.of("engine","DeepJ","backend",args[0],"dtype","FLOAT32","warmups",100,"samples",30,"ms",times,"losses",losses)));
  if(args.length>2)save(model,Path.of(args[2]));
 }
 private static int[] ids(Object value){return Qwen3Json.array(value).stream().mapToInt(x->Math.toIntExact(Qwen3Json.integer(x))).toArray();}
 private static void save(Gemma2 model,Path path) throws Exception {
  var state=new LinkedHashMap<String,Tensor>();model.parameters().forEach(p->state.put(p.name(),p.value));SafeTensorWriter.write(path,state);
 }
}
