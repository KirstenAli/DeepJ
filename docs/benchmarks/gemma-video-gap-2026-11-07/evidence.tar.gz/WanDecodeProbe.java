import io.github.kirstenali.deepj.autograd.GradMode;
import io.github.kirstenali.deepj.concurrent.DeepJExecutor;
import io.github.kirstenali.deepj.nn.diffusion.sanavideo.WanVideoDecoder;
import io.github.kirstenali.deepj.persistence.safetensors.TensorWeights;
import io.github.kirstenali.deepj.persistence.qwen3.Qwen3Json;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;
import java.nio.*;
import java.nio.file.*;
import java.util.*;
import javax.imageio.ImageIO;
public final class WanDecodeProbe {
 public static void main(String[] args)throws Exception {
  if(!MetalBackend.isAvailable())throw new IllegalStateException("Metal required");
  Tensor.setBackend(new MetalBackend());DeepJExecutor.setNumThreads(10);
  Path root=Path.of(args[0]),out=Path.of(args[2]);Files.createDirectories(out);
  var bytes=ByteBuffer.wrap(Files.readAllBytes(Path.of(args[1]))).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer();
  float[] noise=new float[bytes.remaining()];bytes.get(noise);var times=new ArrayList<Double>();
  try(var ignored=GradMode.noGrad();var weights=TensorWeights.open(root,DType.FLOAT32)) {
   var model=new WanVideoDecoder(root.resolve("config.json"),weights);
   for(int trial=0;trial<2;trial++) {
    long start=System.nanoTime();
    var frames=model.images(model.denormalize(Tensor.from(noise,1,16,2,16,24)));
    times.add((System.nanoTime()-start)/1e9);
    if(trial==1)for(int i=0;i<frames.size();i++)ImageIO.write(frames.get(i),"png",out.resolve("frame-"+i+".png").toFile());
   }
   String result=Qwen3Json.stringify(Map.of("engine","DeepJ","seconds",times,"frames",5,"width",192,"height",128,"dtype","FLOAT32"));
   Files.writeString(out.resolve("result.json"),result);System.out.println(result);
  } finally {Tensor.backend().releaseTemporaryResources();DeepJExecutor.shutdown();}
 }
}
