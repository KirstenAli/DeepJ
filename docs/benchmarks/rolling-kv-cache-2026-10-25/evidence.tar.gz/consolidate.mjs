import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const physical = 'QUALIFICATION_ROOT';
const original = join(physical, 'qualification');
const recovery = join(physical, 'qualification-recovery-1');
const output = new URL('./analysis-input-1/', import.meta.url);
const marker = readFileSync(join(recovery, 'status.txt'), 'utf8').trim();
if (marker !== 'RECOVERY CASES COMPLETED; ANALYSIS REQUIRED') throw new Error(marker);
if (existsSync(output)) throw new Error('Never overwrite an analysis input');
mkdirSync(output);
const provenance = new Map();

function addSuccessfulCases(source) {
  for (const file of readdirSync(source).filter((name) => name.endsWith('.log'))) {
    const contents = readFileSync(join(source, file), 'utf8');
    if (!/^RESULT /m.test(contents)) continue;
    if (/Exception in thread|AssertionError|OutOfMemoryError|BUILD FAILURE|Terminating due/.test(contents)) {
      throw new Error(`Fatal error in ${source}/${file}`);
    }
    if (provenance.has(file)) throw new Error(`Duplicate successful case ${file}`);
    for (const suffix of ['.log', '-before.txt', '-after.txt']) {
      const name = file.replace(/\.log$/, suffix);
      copyFileSync(join(source, name), new URL(name, output));
    }
    provenance.set(file, source);
  }
}

addSuccessfulCases(original);
if (provenance.size !== 79) throw new Error(`Expected79 original cases, got${provenance.size}`);
addSuccessfulCases(recovery);
if (provenance.size !== 90) throw new Error(`Expected90 total cases, got${provenance.size}`);
writeFileSync(new URL('provenance.json', output), JSON.stringify(Object.fromEntries(provenance), null, 2) + '\n');
writeFileSync(new URL('status.txt', output), 'ALL ROLLING-CACHE QUALIFICATION CASES COMPLETED; ANALYSIS REQUIRED\n');
console.log(`Consolidated ${provenance.size} cases; originals and failed invocation preserved.`);
