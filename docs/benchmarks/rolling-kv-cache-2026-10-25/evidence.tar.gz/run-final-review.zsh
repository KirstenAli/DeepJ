#!/bin/zsh
set -euo pipefail
task_root=QUALIFICATION_ROOT
task_jdk=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
task_out="$task_root/final-review"
mkdir -p "$task_out/private" "$task_root/additional-harness"
active_case=prepare
trap 'print -r -- "FAILED $active_case line=$LINENO" > "$task_out/status.txt"' ZERR
[[ "$(< "$task_root/qualification-recovery-1/status.txt")" == 'RECOVERY CASES COMPLETED; ANALYSIS REQUIRED' ]]
shasum -a 256 -c "$task_root/qualification/frozen-source-manifest.txt" > "$task_out/source-integrity.txt"
shasum -a 256 -c "$task_root/qualification/frozen-binary-manifest.txt" > "$task_out/binary-integrity.txt"
"$task_jdk/bin/javac" -cp "$task_root/candidate/target/classes:$task_root/harness" \
  -d "$task_root/additional-harness" "$task_root/additional-source/RollingLongSamples.java"

function execute_case() {
  local case_name="$1" revision="$2" main_class="$3"
  shift 3
  active_case="$case_name"
  print -r -- "RUNNING $active_case" > "$task_out/status.txt"
  { date -u; /usr/sbin/sysctl vm.swapusage; /usr/bin/vm_stat; } > "$task_out/$active_case-before.txt"
  /usr/bin/time -l "$task_jdk/bin/java" -Xmx6g -XX:+ExitOnOutOfMemoryError \
    --enable-native-access=ALL-UNNAMED \
    -cp "$task_root/$revision/target/classes:$task_root/harness:$task_root/additional-harness" \
    "$main_class" "$@" > "$task_out/$active_case.log" 2>&1
  /usr/bin/grep -q '^RESULT ' "$task_out/$active_case.log"
  { date -u; /usr/sbin/sysctl vm.swapusage; /usr/bin/vm_stat; } > "$task_out/$active_case-after.txt"
}

# Fresh controls for every case with an original system-wide swapout event, plus old state control.
execute_case prism-state-candidate candidate RollingStateHash prism rebuild
execute_case prism-state-baseline baseline RollingStateHash prism rebuild
execute_case loop-pre-candidate-rolling candidate RollingLogits loop rolling compare \
  "$task_root/qualification/private/loop-pre.bin"
execute_case loop-pre-baseline baseline RollingLogits loop rebuild compare \
  "$task_root/qualification/private/loop-pre.bin"
execute_case loop-pre-candidate-rebuild candidate RollingLogits loop rebuild compare \
  "$task_root/qualification/private/loop-pre.bin"
execute_case frisky-long-samples candidate RollingLongSamples PRIMARY_PROJECT \
  "$task_out/private"
print -r -- 'FINAL REVIEW CONTROLS AND LONG SAMPLES COMPLETED; ANALYSIS REQUIRED' > "$task_out/status.txt"
