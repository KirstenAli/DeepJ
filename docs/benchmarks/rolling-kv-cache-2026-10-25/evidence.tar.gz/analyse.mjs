import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const root = process.argv[2] ?? 'QUALIFICATION_ROOT/qualification';
const output = process.argv[3] ?? new URL('./analysis.json', import.meta.url);
const profiles = ['prism', 'nova', 'loop'];
const review = [];
const read = (file) => readFileSync(join(root, file), 'utf8');
const require = (condition, message) => { if (!condition) throw new Error(message); };
const median = (values) => [...values].sort((a, b) => a - b)[Math.floor(values.length / 2)];

function names() {
  const cases = profiles.flatMap((p) => ['oracle-reference', 'oracle-rolling', 'pre-baseline',
    'pre-candidate-rebuild', 'pre-candidate-rolling', 'state-baseline', 'state-candidate',
    'state-after-rolling', 'real-baseline', 'real-candidate', 'endurance-rolling'].map((s) => `${p}-${s}`));
  for (const r of [1, 2, 3]) {
    for (const p of profiles) {
      cases.push(...['baseline', 'candidate', 'rolling'].map((v) => `${p}-pretime-r${r}-${v}`));
      cases.push(...['baseline', 'candidate'].map((v) => `${p}-posttime-r${r}-${v}`));
    }
    cases.push(`cpu-r${r}-baseline`, `cpu-r${r}-candidate`);
  }
  cases.push(...['baseline-rebuild', 'candidate-rebuild', 'candidate-rolling']
    .flatMap((v) => [`frisky-quality-${v}`, `frisky-samples-${v}`]));
  return cases;
}

function fields(line) {
  return Object.fromEntries([...line.matchAll(/([A-Za-z][\w]*)=([^\s]+)/g)]
    .map((match) => [match[1], /^[-+\d.e]+$/i.test(match[2]) ? Number(match[2]) : match[2]]));
}

function load(name) {
  const text = read(`${name}.log`);
  require(!/Exception in thread|AssertionError|OutOfMemoryError|BUILD FAILURE|Terminating due/.test(text),
    `Fatal error in ${name}`);
  const results = text.split('\n').filter((line) => line.startsWith('RESULT '));
  require(results.length === 1, `Missing or multiple RESULT lines in ${name}`);
  const swaps = (side) => Number(read(`${name}-${side}.txt`).match(/^Swapouts:\s+(\d+)/m)?.[1] ?? NaN);
  const swapoutPages = swaps('after') - swaps('before');
  require(Number.isFinite(swapoutPages) && swapoutPages >= 0, `Invalid OS swap counters in ${name}`);
  if (swapoutPages) review.push({ type: 'systemWideSwapouts', name, pages: swapoutPages });
  return { ...fields(results[0]), text, swapoutPages,
    footprint: Number(text.match(/(\d+)\s+peak memory footprint/)?.[1] ?? NaN),
    rss: Number(text.match(/(\d+)\s+maximum resident set size/)?.[1] ?? NaN) };
}

const cases = Object.fromEntries(names().map((name) => [name, load(name)]));
require(names().length === 90, 'Unexpected qualification case count');
require(read('status.txt').trim() === 'ALL ROLLING-CACHE QUALIFICATION CASES COMPLETED; ANALYSIS REQUIRED',
  'Qualification is not complete');

function numerics(profile) {
  for (const mode of ['candidate-rebuild', 'candidate-rolling']) {
    require(cases[`${profile}-pre-${mode}`].exact === 'true', `Pre-window mismatch: ${profile}/${mode}`);
  }
  const state = cases[`${profile}-state-baseline`];
  for (const variant of ['candidate', 'after-rolling']) {
    const actual = cases[`${profile}-state-${variant}`];
    for (const key of ['loss', 'gradients', 'weights']) {
      require(actual[key] === state[key], `Exact ${key} mismatch: ${profile}/${variant}`);
    }
  }
  require(cases[`${profile}-oracle-rolling`].maxBoundRatio <= 1, `Rolling oracle mismatch: ${profile}`);
  return { preWindowExact: true, trainingStateExact: true,
    postWindowOracle: cases[`${profile}-oracle-rolling`].maxBoundRatio };
}

function realData(profile) {
  const lines = (revision) => cases[`${profile}-real-${revision}`].text.split('\n')
    .filter((line) => /^(TRAIN|VALIDATION|GRADIENT) /.test(line)).map(fields);
  const expected = lines('baseline'), actual = lines('candidate');
  require(expected.length === actual.length && expected.length >= 205, `Missing real-data steps: ${profile}`);
  for (let index = 0; index < expected.length; index++) {
    for (const key of ['step', 'loss', 'perplexity', 'norm']) {
      require(actual[index][key] === expected[index][key], `Real-data ${key} mismatch: ${profile}/${index}`);
    }
  }
  return { updates: 200, validations: 5, exact: true };
}

function comparison(profile, phase, variant) {
  const pairs = [1, 2, 3].map((r) => {
    const baseline = cases[`${profile}-${phase}-r${r}-baseline`];
    const candidate = cases[`${profile}-${phase}-r${r}-${variant}`];
    return { round: r, baselineSeconds: baseline.medianSeconds, candidateSeconds: candidate.medianSeconds,
      ratio: candidate.medianSeconds / baseline.medianSeconds,
      nativePeakRatio: candidate.nativePeak / baseline.nativePeak,
      footprintRatio: candidate.footprint / baseline.footprint };
  });
  const ratio = median(pairs.map((pair) => pair.ratio));
  if (ratio > 1.05) review.push({ type: 'speed', profile, phase, variant, ratio });
  for (const key of ['nativePeakRatio', 'footprintRatio']) {
    const value = median(pairs.map((pair) => pair[key]));
    if (value > (key === 'nativePeakRatio' ? 1.05 : 1.1)) review.push({ type: key, profile, phase, variant, value });
  }
  return { pairs, pairedMedianRatio: ratio, timeReductionPercent: (1 - ratio) * 100 };
}

function samples() {
  const baseline = cases['frisky-samples-baseline-rebuild'].text.split('\n')
    .filter((line) => line.startsWith('SAMPLE ')).map((line) => fields(line).sha256);
  require(baseline.length === 16, 'Missing Frisky samples');
  for (const variant of ['candidate-rebuild', 'candidate-rolling']) {
    const actual = cases[`frisky-samples-${variant}`].text.split('\n')
      .filter((line) => line.startsWith('SAMPLE ')).map((line) => fields(line).sha256);
    require(JSON.stringify(actual) === JSON.stringify(baseline), `Pre-window Frisky text changed: ${variant}`);
  }
  return { prompts: 8, seeds: 2, exact: true };
}

function quality() {
  const baseline = cases['frisky-quality-baseline-rebuild'];
  const candidate = cases['frisky-quality-candidate-rebuild'];
  const rolling = cases['frisky-quality-candidate-rolling'];
  const tokens = (item) => item.text.split('\n').filter((line) => line.startsWith('TOKEN ')).map(fields);
  require(JSON.stringify(tokens(baseline)) === JSON.stringify(tokens(candidate)), 'Default Frisky losses changed');
  const delta = rolling.meanLoss - baseline.meanLoss;
  if (delta > 0.1) review.push({ type: 'qualityMeanNll', delta });
  return { defaultExact: true, tokens: 260, rebuildLoss: baseline.meanLoss,
    rollingLoss: rolling.meanLoss, rollingMinusRebuild: delta };
}

function cpu() {
  const ratios = [1, 2, 3].map((r) => cases[`cpu-r${r}-candidate`].medianSeconds
    / cases[`cpu-r${r}-baseline`].medianSeconds);
  const ratio = median(ratios);
  if (ratio > 1.05) review.push({ type: 'cpuSpeed', ratio });
  return { ratios, pairedMedianRatio: ratio };
}

const result = {
  caseCount: names().length,
  models: Object.fromEntries(profiles.map((profile) => [profile, {
    numerics: numerics(profile), realData: realData(profile),
    defaultPreWindow: comparison(profile, 'pretime', 'candidate'),
    rollingPreWindow: comparison(profile, 'pretime', 'rolling'),
    rollingPostWindow: comparison(profile, 'posttime', 'candidate'),
    endurance: Object.fromEntries(Object.entries(cases[`${profile}-endurance-rolling`])
      .filter(([key]) => key !== 'text')),
  }])),
  samples: samples(), quality: quality(), cpu: cpu(), review,
};
writeFileSync(output, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
if (review.length) process.exitCode = 2;
