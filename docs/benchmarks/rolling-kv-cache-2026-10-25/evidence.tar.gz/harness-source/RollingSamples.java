import io.github.kirstenali.deepj.models.DeepJChat;
import io.github.kirstenali.deepj.tensor.Tensor;

import java.nio.file.Path;
import java.util.HexFormat;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

/** Fixed Frisky prompts and seeds; the API applies its saved Instruction/Response template. */
public final class RollingSamples {
    private RollingSamples() {}

    public static void main(String[] args) throws Exception {
        QualificationModels.requireMetal();
        try {
            DeepJChat chat = DeepJChat.load(Path.of(args[0]));
            if (args[1].equals("rolling")) chat = rolling(chat);
            sample(chat);
            System.out.printf("RESULT mode=%s prompts=8 seeds=2 samples=16%n", args[1]);
        } finally {
            Tensor.backend().releaseResources();
        }
    }

    private static DeepJChat rolling(DeepJChat chat) throws Exception {
        Class<?> type = Class.forName("io.github.kirstenali.deepj.models.ContextWindowMode");
        return (DeepJChat) DeepJChat.class.getMethod("withContextWindow", type)
                .invoke(chat, type.getField("ROLLING").get(null));
    }

    private static void sample(DeepJChat chat) throws Exception {
        String[] prompts = {"Hello", "What is a computer?", "Why is the sky blue?",
                "London is the capital of", "What is one plus one?", "Are dogs friendly?",
                "Write a Python program to print hello world.", "What is the meaning of life?"};
        for (long seed : new long[]{1234, 2026}) {
            for (int index = 0; index < prompts.length; index++) {
                String answer = chat.generate(prompts[index], 80, 0.8f, 40, seed, 1);
                String hash = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256")
                        .digest(answer.getBytes(StandardCharsets.UTF_8)));
                System.out.printf("SAMPLE prompt=%d seed=%d sha256=%s text=%s%n",
                        index, seed, hash, answer.replace("\n", "\\n").replace("\r", "\\r"));
            }
        }
    }
}
