import io.github.kirstenali.deepj.autograd.GradMode;
import io.github.kirstenali.deepj.data.Batch;
import io.github.kirstenali.deepj.data.RandomAccessTextDataset;
import io.github.kirstenali.deepj.loss.CrossEntropyLoss;
import io.github.kirstenali.deepj.models.DecoderOnlyModel;
import io.github.kirstenali.deepj.models.ModelLoader;
import io.github.kirstenali.deepj.tensor.RollingModes;
import io.github.kirstenali.deepj.tensor.Tensor;
import io.github.kirstenali.deepj.tokenizers.bpe.BPEModelIO;
import io.github.kirstenali.deepj.tokenizers.bpe.BPETokenizer;

import java.nio.file.Path;
import java.util.Arrays;

/** Read-only Frisky held-out next-token losses before and after the first window eviction. */
public final class RollingQuality {
    private RollingQuality() {}

    public static void main(String[] args) throws Exception {
        QualificationModels.requireMetal();
        Path project = Path.of(args[0]);
        try {
            DecoderOnlyModel model = ModelLoader.load(project.resolve("checkpoints/deepj-90m/sft/model-final.dj"));
            var tokenizer = new BPETokenizer(BPEModelIO.load(
                    project.resolve("checkpoints/deepj-90m/sft/tokenizer.bpe")));
            run(model, tokenizer, project, args[1]);
        } finally {
            Tensor.backend().releaseResources();
        }
    }

    private static void run(DecoderOnlyModel model, BPETokenizer tokenizer, Path project, String mode)
            throws Exception {
        double total = 0;
        try (var data = new RandomAccessTextDataset(project.resolve("sample_data/TinyStories-valid.txt"),
                tokenizer, 1088, 2027)) {
            for (int sample = 0; sample < 4; sample++) {
                double loss = evaluate(model, data.nextBatch(1), mode, sample);
                total += loss;
                System.out.printf("BATCH sample=%d mode=%s tokens=65 loss=%.12g%n", sample, mode, loss);
            }
        }
        System.out.printf("RESULT mode=%s samples=4 tokens=260 meanLoss=%.12g perplexity=%.12g%n",
                mode, total / 4, Math.exp(total / 4));
    }

    private static double evaluate(DecoderOnlyModel model, Batch batch, String mode, int sample) throws Exception {
        double sum = 0;
        int[] tokens = batch.x()[0];
        try (var session = RollingModes.open(model, mode); var ignored = GradMode.noGrad()) {
            for (int size = 1024; size <= 1088; size++) {
                Tensor logits = session.apply(Arrays.copyOfRange(tokens, size - 1024, size));
                double loss = CrossEntropyLoss.loss(logits, new int[]{batch.y()[0][size - 1]});
                QualificationTelemetry.finite(loss);
                sum += loss;
                System.out.printf("TOKEN sample=%d mode=%s position=%d loss=%.12g%n", sample, mode, size, loss);
                Tensor.backend().releaseTemporaryResources();
            }
        }
        Tensor.backend().releaseTemporaryResources();
        return sum / 65;
    }
}
