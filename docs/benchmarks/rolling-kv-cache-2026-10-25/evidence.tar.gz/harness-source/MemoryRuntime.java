package io.github.kirstenali.deepj.tensor;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

/** Diagnostic-only delegation. Allocation and release order are not changed. */
final class MemoryRuntime implements GpuRuntime {
    final ComputeGraph graph;
    final Map<Integer, Long> buffers = new HashMap<>();
    private final GpuRuntime delegate;
    long liveBytes, peakBytes, allocatedBytes, releasedBytes, uploadedBytes, downloadedBytes, zeroedBytes;

    private MemoryRuntime(ComputeGraph graph, GpuRuntime delegate) {
        this.graph = graph;
        this.delegate = delegate;
    }

    static MemoryRuntime attach(TensorBackend backend) throws ReflectiveOperationException {
        Class<?> type = Class.forName("io.github.kirstenali.deepj.tensor.metal.MetalCoreOps");
        Field graphField = type.getDeclaredField("graph");
        graphField.setAccessible(true);
        ComputeGraph graph = (ComputeGraph) graphField.get(backend);
        MemoryRuntime result = new MemoryRuntime(graph, graph.runtime);
        Field runtimeField = GraphCore.class.getDeclaredField("runtime");
        runtimeField.setAccessible(true);
        runtimeField.set(graph, result);
        if (graph.runtime != result) throw new AssertionError("Instrumentation was not installed");
        return result;
    }

    @Override public void allocBuffers(int[] ids, int[] sizes, int count) {
        delegate.allocBuffers(ids, sizes, count);
        for (int index = 0; index < count; index++) {
            long bytes = sizes[index] * 4L;
            Long old = buffers.put(ids[index], bytes);
            if (old != null) throw new AssertionError("Repeated native buffer allocation");
            liveBytes += bytes;
            allocatedBytes += bytes;
        }
        peakBytes = Math.max(peakBytes, liveBytes);
    }

    @Override public void releaseBuffers(int[] ids, int count) {
        delegate.releaseBuffers(ids, count);
        for (int index = 0; index < count; index++) {
            Long bytes = buffers.remove(ids[index]);
            if (bytes != null) {
                liveBytes -= bytes;
                releasedBytes += bytes;
            }
        }
    }

    @Override public void uploadBuffer(int id, float[] data) {
        uploadedBytes += data.length * 4L;
        delegate.uploadBuffer(id, data);
    }

    @Override public void downloadBuffer(int id, float[] data) {
        downloadedBytes += data.length * 4L;
        delegate.downloadBuffer(id, data);
    }

    @Override public void zeroBuffer(int id, int floatCount) {
        zeroedBytes += floatCount * 4L;
        delegate.zeroBuffer(id, floatCount);
    }

    @Override public void flushOps(int[] commands, int length) { delegate.flushOps(commands, length); }
}
