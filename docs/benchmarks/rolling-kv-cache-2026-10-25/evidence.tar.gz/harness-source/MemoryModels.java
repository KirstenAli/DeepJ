package io.github.kirstenali.deepj.tensor;

import io.github.kirstenali.deepj.models.DecoderOnlyModel;
import io.github.kirstenali.deepj.models.prism.DeepJPrism;
import io.github.kirstenali.deepj.models.prism.DeepJPrismConfig;
import io.github.kirstenali.deepj.models.nova.DeepJNova;
import io.github.kirstenali.deepj.models.nova.DeepJNovaConfig;
import io.github.kirstenali.deepj.models.loop.DeepJLoop;
import io.github.kirstenali.deepj.models.loop.DeepJLoopConfig;

final class MemoryModels {
    private MemoryModels() {}

    static DecoderOnlyModel create(String name) {
        return create(name, 1024);
    }

    static DecoderOnlyModel create(String name, int capacity) {
        return switch (name) {
            case "prism" -> new DeepJPrism(new DeepJPrismConfig(
                    16_384, capacity, 768, 12, 10, 2112, 384, 192, 0.2f, 1), 100);
            case "nova" -> new DeepJNova(new DeepJNovaConfig(
                    16_384, capacity, 576, 9, 3, 24, 1664, true, 0.2f, 1), 100);
            case "loop" -> new DeepJLoop(new DeepJLoopConfig(
                    16_384, capacity, 576, 9, 3, 6, 12, 6, 2, 1664), 100);
            default -> throw new IllegalArgumentException(name);
        };
    }
}
