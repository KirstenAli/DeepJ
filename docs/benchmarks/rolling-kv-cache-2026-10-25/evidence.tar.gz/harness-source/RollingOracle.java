package io.github.kirstenali.deepj.tensor;

import io.github.kirstenali.deepj.models.DecoderOnlyModel;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Proxy;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Set;

/** Noncircular oracle: keep all KV rows and gather the newest window before each attention product. */
public final class RollingOracle {
    private RollingOracle() {}

    public static void main(String[] args) throws Exception {
        if (!MetalBackend.isAvailable()) throw new IllegalStateException("Physical Metal required");
        var metal = new MetalBackend();
        boolean reference = args[1].equals("reference");
        Tensor.setBackend(reference ? backend(metal, 1024) : metal);
        try {
            DecoderOnlyModel model = MemoryModels.create(args[0], reference ? 2048 : 1024);
            compare(model, args, reference);
        } finally {
            metal.releaseResources();
        }
    }

    private static TensorBackend backend(MetalBackend metal, int window) {
        Set<Class<?>> interfaces = new LinkedHashSet<>();
        for (Class<?> type = metal.getClass(); type != null; type = type.getSuperclass()) {
            interfaces.addAll(Arrays.asList(type.getInterfaces()));
        }
        return (TensorBackend) Proxy.newProxyInstance(TensorBackend.class.getClassLoader(),
                interfaces.toArray(Class<?>[]::new), (proxy, method, args) -> {
                    if (method.getName().equals("headPrefixMatmul") && (int) args[3] > window) {
                        return gathered(metal, args, window);
                    }
                    try { return method.invoke(metal, args); }
                    catch (InvocationTargetException failure) { throw failure.getCause(); }
                });
    }

    private static Tensor gathered(MetalBackend metal, Object[] args, int window) {
        Tensor left = (Tensor) args[0], cache = (Tensor) args[1];
        int heads = (int) args[2], length = (int) args[3], capacity = cache.rows / heads;
        int[] indices = new int[heads * window];
        for (int row = 0; row < indices.length; row++) {
            indices[row] = row / window * capacity + length - window + row % window;
        }
        Tensor selected = metal.sliceRows(cache, indices);
        return metal.batchedMatmul(left, selected, heads, false, (boolean) args[4]);
    }

    private static void compare(DecoderOnlyModel model, String[] args, boolean reference) throws Exception {
        int[] tokens = new Random(1013).ints(1088, 0, 16_384).toArray();
        Path path = Path.of(args[2]);
        double[] errors = new double[2];
        try (var session = RollingModes.open(model, reference ? "rebuild" : "rolling");
             var output = reference ? new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(path))) : null;
             var input = reference ? null : new DataInputStream(new BufferedInputStream(Files.newInputStream(path)))) {
            for (int size = 1024; size <= tokens.length; size++) {
                int start = reference ? 0 : size - 1024;
                float[] actual = session.apply(Arrays.copyOfRange(tokens, start, size)).rowData(0);
                values(actual, output, input, errors);
                Tensor.backend().releaseTemporaryResources();
            }
            if (input != null && input.read() != -1) throw new AssertionError("Trailing oracle values");
        }
        System.out.printf("RESULT model=%s mode=%s positions=65 values=1064960 maxAbs=%.12g maxBoundRatio=%.12g%n",
                args[0], args[1], errors[0], errors[1]);
    }

    private static void values(float[] actual, DataOutputStream output, DataInputStream input,
                                double[] errors) throws Exception {
        for (float value : actual) {
            if (!Float.isFinite(value)) throw new AssertionError("Nonfinite oracle value");
            if (output != null) output.writeFloat(value);
            else check(value, input.readFloat(), errors);
        }
    }

    private static void check(float actual, float expected, double[] errors) {
        double absolute = Math.abs((double) actual - expected), bound = 2e-5 + 2e-4 * Math.abs(expected);
        errors[0] = Math.max(errors[0], absolute);
        errors[1] = Math.max(errors[1], absolute / bound);
        if (!Float.isFinite(expected) || absolute > bound) throw new AssertionError("Rolling oracle bound exceeded");
    }
}
