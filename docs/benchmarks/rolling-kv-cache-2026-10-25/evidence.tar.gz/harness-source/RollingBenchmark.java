package io.github.kirstenali.deepj.tensor;

import com.sun.management.ThreadMXBean;
import io.github.kirstenali.deepj.models.DecoderOnlyModel;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;

import java.lang.management.ManagementFactory;
import java.util.Arrays;
import java.util.Random;

/** Fresh-JVM request timings, including prefill, readback, cache allocation and cleanup. */
public final class RollingBenchmark {
    private RollingBenchmark() {}

    public static void main(String[] args) throws Exception {
        if (!MetalBackend.isAvailable()) throw new IllegalStateException("Physical Metal required");
        Tensor.setBackend(new MetalBackend());
        MemoryRuntime runtime = MemoryRuntime.attach(Tensor.backend());
        try {
            run(MemoryModels.create(args[0]), args, runtime);
        } finally {
            Tensor.backend().releaseResources();
            if (runtime.liveBytes != 0) throw new AssertionError("Native buffers leaked");
        }
    }

    private static void run(DecoderOnlyModel model, String[] args, MemoryRuntime runtime) throws Exception {
        var threads = (ThreadMXBean) ManagementFactory.getThreadMXBean();
        threads.setThreadAllocatedMemoryEnabled(true);
        int prefill = Integer.parseInt(args[2]), decode = Integer.parseInt(args[3]);
        int measured = Integer.parseInt(args[4]);
        double[] times = new double[measured];
        long stable = -1;
        for (int request = 0; request < measured + 2; request++) {
            long allocated = threads.getCurrentThreadAllocatedBytes(), start = System.nanoTime();
            generate(model, args[1], prefill, decode);
            double seconds = (System.nanoTime() - start) / 1e9;
            if (request >= 2) times[request - 2] = seconds;
            if (request == 1) stable = runtime.liveBytes;
            if (request >= 2 && runtime.liveBytes != stable) throw new AssertionError("Retained cache growth");
            sample(request, seconds, threads.getCurrentThreadAllocatedBytes() - allocated, runtime);
        }
        result(args, times, runtime);
    }

    private static void generate(DecoderOnlyModel model, String mode, int prefill, int decode) throws Exception {
        int[] tokens = new Random(701).ints(prefill + decode + 1, 0, 16_384).toArray();
        try (var session = RollingModes.open(model, mode)) {
            for (int size = prefill; size <= prefill + decode; size++) {
                int[] window = Arrays.copyOfRange(tokens, Math.max(0, size - 1024), size);
                finite(session.apply(window).rowData(0));
                Tensor.backend().releaseTemporaryResources();
            }
        }
        Tensor.backend().releaseTemporaryResources();
    }

    private static void finite(float[] values) {
        for (float value : values) {
            if (!Float.isFinite(value)) throw new AssertionError("Nonfinite cached logit");
        }
    }

    private static void sample(int request, double seconds, long allocated, MemoryRuntime runtime) {
        System.out.printf("REQUEST request=%d seconds=%.9f javaAllocated=%d nativeLive=%d nativePeak=%d%n",
                request, seconds, allocated, runtime.liveBytes, runtime.peakBytes);
    }

    private static void result(String[] args, double[] times, MemoryRuntime runtime) {
        Arrays.sort(times);
        System.out.printf("RESULT model=%s mode=%s prefill=%s decode=%s measured=%d medianSeconds=%.9f "
                        + "nativeLive=%d nativePeak=%d nativeAllocated=%d uploadedBytes=%d%n",
                args[0], args[1], args[2], args[3], times.length, times[times.length / 2],
                runtime.liveBytes, runtime.peakBytes, runtime.allocatedBytes, runtime.uploadedBytes);
    }
}
