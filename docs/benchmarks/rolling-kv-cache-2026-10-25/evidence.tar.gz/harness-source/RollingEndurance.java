package io.github.kirstenali.deepj.tensor;

import io.github.kirstenali.deepj.models.DecoderOnlyModel;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;

import java.util.Arrays;
import java.util.Random;

/** Full-size repeated wraps and closed requests, with strict retained-native-storage checks. */
public final class RollingEndurance {
    private RollingEndurance() {}

    public static void main(String[] args) throws Exception {
        if (!MetalBackend.isAvailable()) throw new IllegalStateException("Physical Metal required");
        Tensor.setBackend(new MetalBackend());
        MemoryRuntime runtime = MemoryRuntime.attach(Tensor.backend());
        try {
            DecoderOnlyModel model = MemoryModels.create(args[0]);
            longWrap(model, runtime, Integer.parseInt(args[1]));
            requests(model, runtime, Integer.parseInt(args[2]));
            System.out.printf("RESULT model=%s longTokens=%s requests=%s nativeLive=%d nativePeak=%d%n",
                    args[0], args[1], args[2], runtime.liveBytes, runtime.peakBytes);
        } finally {
            Tensor.backend().releaseResources();
            if (runtime.liveBytes != 0) throw new AssertionError("Native buffers leaked");
        }
    }

    private static void longWrap(DecoderOnlyModel model, MemoryRuntime runtime, int total) throws Exception {
        int[] tokens = new Random(997).ints(total, 0, 16_384).toArray();
        long stable = -1;
        try (var session = RollingModes.open(model, "rolling")) {
            for (int size = 1024; size <= total; size++) {
                finite(session.apply(Arrays.copyOfRange(tokens, size - 1024, size)));
                Tensor.backend().releaseTemporaryResources();
                if (size == 1024) stable = runtime.liveBytes;
                if (runtime.liveBytes != stable) throw new AssertionError("Rolling cache storage grew");
                if (size % 128 == 0) sample("long", size, runtime);
            }
        }
        Tensor.backend().releaseTemporaryResources();
        sample("closed", total, runtime);
    }

    private static void requests(DecoderOnlyModel model, MemoryRuntime runtime, int count) throws Exception {
        long stable = runtime.liveBytes;
        int[] tokens = new Random(1009).ints(1040, 0, 16_384).toArray();
        for (int request = 0; request < count; request++) {
            try (var session = RollingModes.open(model, "rolling")) {
                for (int size = 1024; size <= tokens.length; size++) {
                    finite(session.apply(Arrays.copyOfRange(tokens, size - 1024, size)));
                    Tensor.backend().releaseTemporaryResources();
                }
            }
            Tensor.backend().releaseTemporaryResources();
            if (runtime.liveBytes != stable) throw new AssertionError("Closed request retained cache storage");
            sample("request", request, runtime);
        }
    }

    private static void finite(Tensor logits) {
        for (float value : logits.rowData(0)) {
            if (!Float.isFinite(value)) throw new AssertionError("Nonfinite rolling output");
        }
    }

    private static void sample(String phase, int step, MemoryRuntime runtime) {
        Runtime java = Runtime.getRuntime();
        System.out.printf("MEMORY phase=%s step=%d nativeLive=%d nativePeak=%d buffers=%d heapUsed=%d%n",
                phase, step, runtime.liveBytes, runtime.peakBytes, runtime.buffers.size(),
                java.totalMemory() - java.freeMemory());
    }
}
