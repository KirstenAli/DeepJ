import io.github.kirstenali.deepj.models.DecoderOnlyModel;
import io.github.kirstenali.deepj.tensor.Tensor;
import io.github.kirstenali.deepj.tensor.RollingModes;
import io.github.kirstenali.deepj.training.CausalLMTraining;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.OutputStream;
import java.security.DigestOutputStream;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.HexFormat;
import java.util.List;
import java.util.Random;

/** Exact gradient/updated-weight hashes; no checkpoint or weight dump is written. */
public final class RollingStateHash {
    private RollingStateHash() {}

    public static void main(String[] args) throws Exception {
        QualificationModels.requireMetal();
        try {
            DecoderOnlyModel model = QualificationModels.create(args[0], 100);
            if (args[1].equals("rolling")) exercise(model);
            float loss = train(model);
            String gradients = hash(model.parameters().stream().map(parameter -> parameter.grad()).toList());
            String weights = hash(model.parameters().stream().map(parameter -> parameter.value).toList());
            System.out.printf("RESULT model=%s mode=%s steps=3 loss=%.9g gradients=%s weights=%s%n",
                    args[0], args[1], loss, gradients, weights);
        } finally {
            Tensor.backend().releaseResources();
        }
    }

    private static void exercise(DecoderOnlyModel model) throws Exception {
        int[] tokens = new Random(991).ints(1032, 0, 16_384).toArray();
        try (var session = RollingModes.open(model, "rolling")) {
            for (int size = 1024; size <= tokens.length; size++) {
                session.apply(Arrays.copyOfRange(tokens, size - 1024, size)).materialize();
                Tensor.backend().releaseTemporaryResources();
            }
        }
        Tensor.backend().releaseTemporaryResources();
    }

    private static float train(DecoderOnlyModel model) {
        var random = new Random(2026);
        var trainer = CausalLMTraining.trainer(model, ignored -> QualificationData.synthetic(random), 1e-4f);
        float loss = 0;
        for (int step = 0; step < 3; step++) {
            loss = trainer.trainStep(1);
            QualificationTelemetry.finite(loss);
            System.out.printf("TRAIN step=%d loss=%.9g%n", step, loss);
            if (step < 2) Tensor.backend().releaseTemporaryResources();
        }
        return loss;
    }

    private static String hash(List<Tensor> tensors) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (var output = new DataOutputStream(new BufferedOutputStream(
                new DigestOutputStream(OutputStream.nullOutputStream(), digest), 65536))) {
            for (Tensor tensor : tensors) write(output, tensor);
        }
        return HexFormat.of().formatHex(digest.digest());
    }

    private static void write(DataOutputStream output, Tensor tensor) throws Exception {
        tensor.materialize();
        output.writeInt(tensor.rows);
        output.writeInt(tensor.cols);
        for (float value : tensor.data) {
            QualificationTelemetry.finite(value);
            output.writeInt(Float.floatToRawIntBits(value));
        }
    }
}
