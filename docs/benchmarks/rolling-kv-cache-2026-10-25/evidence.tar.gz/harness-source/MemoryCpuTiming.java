import io.github.kirstenali.deepj.models.DecoderOnlyModel;
import io.github.kirstenali.deepj.models.prism.*;
import io.github.kirstenali.deepj.models.nova.*;
import io.github.kirstenali.deepj.models.loop.*;
import io.github.kirstenali.deepj.data.Batch;
import io.github.kirstenali.deepj.tensor.Tensor;
import io.github.kirstenali.deepj.tensor.cpu.CpuBackend;
import io.github.kirstenali.deepj.training.CausalLMTraining;
import java.util.Arrays;
import java.util.Random;

public final class MemoryCpuTiming {
    private MemoryCpuTiming() {}

    public static void main(String[] args) {
        Tensor.setBackend(new CpuBackend());
        DecoderOnlyModel model = model(args[0]);
        Random random = new Random(2026);
        var trainer = CausalLMTraining.trainer(model, ignored -> batch(random), 1e-4f);
        int warmup = args.length > 1 ? Integer.parseInt(args[1]) : 300;
        double[] samples = new double[args.length > 2 ? Integer.parseInt(args[2]) : 1000];
        for (int step = 0; step < warmup + samples.length; step++) {
            long started = System.nanoTime();
            float loss = trainer.trainStep(1);
            double seconds = (System.nanoTime() - started) / 1e9;
            if (!Float.isFinite(loss)) throw new AssertionError("Nonfinite CPU loss");
            if (step >= warmup) samples[step - warmup] = seconds;
            if (step % 100 == 0) System.out.printf("STEP step=%d loss=%.9g%n", step, loss);
        }
        Arrays.sort(samples);
        System.out.printf("RESULT model=%s backend=CpuBackend medianSeconds=%.9f%n",
                args[0], (samples[(samples.length - 1) / 2] + samples[samples.length / 2]) / 2);
    }

    private static DecoderOnlyModel model(String name) {
        return switch (name) {
            case "prism" -> new DeepJPrism(new DeepJPrismConfig(128, 32, 32, 4, 2, 64, 16, 8), 100);
            case "nova" -> new DeepJNova(new DeepJNovaConfig(128, 32, 32, 4, 2, 2, 64), 100);
            case "loop" -> new DeepJLoop(new DeepJLoopConfig(128, 32, 32, 4, 2, 1, 1, 1, 2, 64), 100);
            default -> throw new IllegalArgumentException(name);
        };
    }

    private static Batch batch(Random random) {
        int[] input = random.ints(32, 0, 128).toArray();
        int[] target = Arrays.copyOfRange(input, 1, 33);
        return new Batch(new int[][]{input}, new int[][]{target});
    }
}
