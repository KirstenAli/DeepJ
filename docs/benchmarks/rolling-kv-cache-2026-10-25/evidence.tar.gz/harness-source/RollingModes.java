package io.github.kirstenali.deepj.tensor;

import io.github.kirstenali.deepj.models.DecoderOnlyModel;
import io.github.kirstenali.deepj.models.GenerationSession;

/** Reflection keeps this identical harness loadable against the frozen pre-feature classes. */
public final class RollingModes {
    private RollingModes() {}

    public static GenerationSession open(DecoderOnlyModel model, String mode) throws Exception {
        if (mode.equals("rebuild")) return model.openGeneration();
        if (!mode.equals("rolling")) throw new IllegalArgumentException(mode);
        Class<?> type = Class.forName("io.github.kirstenali.deepj.models.ContextWindowMode");
        Object value = type.getField("ROLLING").get(null);
        return (GenerationSession) model.getClass().getMethod("openGeneration", type).invoke(model, value);
    }
}
