import io.github.kirstenali.deepj.models.DecoderOnlyModel;
import io.github.kirstenali.deepj.tensor.Tensor;
import io.github.kirstenali.deepj.tensor.RollingModes;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Random;

/** Exact pre-eviction logits compared between frozen master and both candidate modes. */
public final class RollingLogits {
    private RollingLogits() {}

    public static void main(String[] args) throws Exception {
        QualificationModels.requireMetal();
        try {
            run(QualificationModels.create(args[0], 100), args);
        } finally {
            Tensor.backend().releaseResources();
        }
    }

    private static void run(DecoderOnlyModel model, String[] args) throws Exception {
        int[] tokens = new Random(991).ints(1024, 0, 16_384).toArray();
        Path path = Path.of(args[3]);
        try (var session = RollingModes.open(model, args[1]);
             var output = args[2].equals("write") ? writer(path) : null;
             var input = args[2].equals("compare") ? reader(path) : null) {
            for (int size : new int[]{32, 33, 34, 127, 128, 255, 256, 511, 512, 1023, 1024}) {
                float[] logits = session.apply(Arrays.copyOf(tokens, size)).rowData(0);
                compare(logits, output, input, size);
                Tensor.backend().releaseTemporaryResources();
            }
            if (input != null && input.read() != -1) throw new AssertionError("Trailing logits");
        }
        System.out.printf("RESULT model=%s mode=%s action=%s positions=11 values=180224 exact=true%n",
                args[0], args[1], args[2]);
    }

    private static void compare(float[] values, DataOutputStream output, DataInputStream input,
                                 int position) throws Exception {
        for (int index = 0; index < values.length; index++) {
            if (!Float.isFinite(values[index])) throw new AssertionError("Nonfinite logit");
            int bits = Float.floatToRawIntBits(values[index]);
            if (output != null) output.writeInt(bits);
            else if (input.readInt() != bits) {
                throw new AssertionError("Pre-eviction bit mismatch at position=" + position + " index=" + index);
            }
        }
    }

    private static DataOutputStream writer(Path path) throws Exception {
        return new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(path)));
    }

    private static DataInputStream reader(Path path) throws Exception {
        return new DataInputStream(new BufferedInputStream(Files.newInputStream(path)));
    }
}
