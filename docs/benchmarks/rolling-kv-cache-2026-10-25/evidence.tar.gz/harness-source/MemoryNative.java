package io.github.kirstenali.deepj.tensor;

final class MemoryNative {
    private MemoryNative() {}
    static native long[] snapshot();
}
