# Qualification recovery1

The original runner stopped at frisky-samples-baseline-rebuild before executing generation.
Its harness passed the sft directory to DeepJChat.load(), which looks for model.dj in a directory;
the actual existing checkpoint is model-final.dj. The NoSuchFileException is preserved in the
original log. This is a harness argument error, not a numerical or model-runtime failure.

Original qualification/ and its frozen source/binary manifests remain unchanged. The recovery
runner verifies both manifests, passes the real existing checkpoint file explicitly and runs
only the11 remaining cases in qualification-recovery-1/. No model is renamed, copied or edited.
No production code, frozen binary, test bound or acceptance criterion changes.

Current physical runner: run-recovery-1.zsh, IntelliJ Local(3), with caffeinate.
Latest status: QUALIFICATION_ROOT/qualification-recovery-1/status.txt
Exact recovery marker: RECOVERY CASES COMPLETED; ANALYSIS REQUIRED.

Once complete, assemble an analysis input from the79 successful original cases plus11 successful
recovery cases, retaining provenance and the original failure. Verify90 total RESULT summaries;
do not feed the original failed sample log into a claimed successful aggregate. Then run the
existing strict analysis and complete the separate long-output quality check before any PR.
