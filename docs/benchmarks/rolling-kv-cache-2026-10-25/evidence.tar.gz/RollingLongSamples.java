import io.github.kirstenali.deepj.data.RandomAccessTextDataset;
import io.github.kirstenali.deepj.models.ContextWindowMode;
import io.github.kirstenali.deepj.models.DecoderOnlyModel;
import io.github.kirstenali.deepj.models.ModelLoader;
import io.github.kirstenali.deepj.models.TextGenerator;
import io.github.kirstenali.deepj.tensor.Tensor;
import io.github.kirstenali.deepj.tokenizers.bpe.BPEModelIO;
import io.github.kirstenali.deepj.tokenizers.bpe.BPETokenizer;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

/** Bounded free-generation check using the unchanged saved prompt template and EOS policy. */
public final class RollingLongSamples {
    private RollingLongSamples() {}

    public static void main(String[] args) throws Exception {
        QualificationModels.requireMetal();
        Path project = Path.of(args[0]);
        try {
            DecoderOnlyModel model = ModelLoader.load(project.resolve("checkpoints/deepj-90m/sft/model-final.dj"));
            var tokenizer = new BPETokenizer(BPEModelIO.load(
                    project.resolve("checkpoints/deepj-90m/sft/tokenizer.bpe")));
            run(model, tokenizer, project, Path.of(args[1]));
        } finally {
            Tensor.backend().releaseResources();
        }
    }

    private static void run(DecoderOnlyModel model, BPETokenizer tokenizer, Path project, Path output)
            throws Exception {
        String[] prompts = prompts(model, tokenizer, project);
        for (int index = 0; index < prompts.length; index++) {
            for (long seed : new long[]{1234, 2026}) {
                for (var mode : ContextWindowMode.values()) {
                    sample(model, tokenizer, prompts[index], index, seed, mode, output);
                }
            }
        }
        System.out.println("RESULT prompts=2 seeds=2 modes=2 samples=8 maxNewTokens=160");
    }

    private static String[] prompts(DecoderOnlyModel model, BPETokenizer tokenizer, Path project)
            throws Exception {
        String[] result = new String[2];
        try (var data = new RandomAccessTextDataset(project.resolve("sample_data/TinyStories-valid.txt"),
                tokenizer, 1200, 2028)) {
            for (int index = 0; index < result.length; index++) {
                String passage = tokenizer.decode(Arrays.copyOf(data.nextBatch(1).x()[0], 1100));
                result[index] = fit(model, tokenizer, passage, index);
            }
        }
        return result;
    }

    private static String fit(DecoderOnlyModel model, BPETokenizer tokenizer, String passage, int index) {
        String request = index == 0 ? "Continue the following story:\n" : "Summarize the following passage:\n";
        passage = passage.replace("<EOS>", "").replace("<|endoftext|>", "");
        String prompt = model.promptFormat().apply(request + passage);
        while (tokenizer.encode(prompt).length > 1024) {
            passage = passage.substring(0, passage.length() - 1);
            prompt = model.promptFormat().apply(request + passage);
        }
        if (tokenizer.encode(prompt).length < 1016) throw new AssertionError("Prompt too short");
        return prompt;
    }

    private static void sample(DecoderOnlyModel model, BPETokenizer tokenizer, String prompt,
                               int index, long seed, ContextWindowMode mode, Path output) throws Exception {
        int[] counts = new int[2];
        String text;
        try (var session = model.openGeneration(mode)) {
            text = TextGenerator.stream(tokens -> {
                counts[0]++;
                return session.apply(tokens);
            }, 1024, tokenizer, prompt, 160, 0.8f, 40, seed, 1.0f, ignored -> counts[1]++);
        }
        Tensor.backend().releaseTemporaryResources();
        String prefix = tokenizer.decode(tokenizer.encode(prompt));
        if (!text.startsWith(prefix)) throw new AssertionError("Prompt prefix changed");
        String name = "prompt-" + index + "-seed-" + seed + "-" + mode.name().toLowerCase();
        Files.writeString(output.resolve(name + ".txt"), prompt + "\n\nGENERATED:\n" + text.substring(prefix.length()));
        int promptTokens = tokenizer.encode(prompt).length;
        int shifted = Math.max(0, promptTokens + counts[0] - 1 - 1024);
        System.out.printf("LONG prompt=%d seed=%d mode=%s promptTokens=%d generatedTokens=%d calls=%d shiftedSteps=%d%n",
                index, seed, mode, promptTokens, counts[1], counts[0], shifted);
    }
}
