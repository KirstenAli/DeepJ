import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const physical = 'QUALIFICATION_ROOT';
const read = (folder, name) => readFileSync(join(physical, folder, name), 'utf8');
const require = (condition, message) => { if (!condition) throw new Error(message); };
const fields = (line) => Object.fromEntries([...line.matchAll(/([A-Za-z]\w*)=([^\s]+)/g)]
  .map(([, key, value]) => [key, /^[-+\d.e]+$/i.test(value) ? Number(value) : value]));
const swaps = (text) => Number(text.match(/^Swapouts:\s+(\d+)/m)[1]);
const result = (folder, name) => {
  const text = read(folder, `${name}.log`);
  require(!/Exception in thread|AssertionError|OutOfMemoryError|BUILD FAILURE/.test(text), name);
  require((text.match(/^RESULT /gm) ?? []).length === 1, `Missing result ${name}`);
  return { fields: fields(text.match(/^RESULT .*/m)[0]), text,
    globalSwapoutPages: swaps(read(folder, `${name}-after.txt`)) - swaps(read(folder, `${name}-before.txt`)) };
};

require(read('final-review', 'status.txt').trim() ===
  'FINAL REVIEW CONTROLS AND LONG SAMPLES COMPLETED; ANALYSIS REQUIRED', 'Final review incomplete');
require(read('memory-review', 'status.txt').trim() ===
  'MEMORY REVIEW CONTROLS COMPLETED; ANALYSIS REQUIRED', 'Memory review incomplete');

const controls = {};
for (const name of ['prism-state-candidate', 'prism-state-baseline', 'loop-pre-candidate-rolling',
  'loop-pre-baseline', 'loop-pre-candidate-rebuild']) {
  const item = result('final-review', name);
  controls[name] = { ...item.fields, globalSwapoutPages: item.globalSwapoutPages };
}
for (const key of ['loss', 'gradients', 'weights']) {
  require(controls['prism-state-candidate'][key] === controls['prism-state-baseline'][key], key);
}
for (const name of Object.keys(controls).filter((name) => name.startsWith('loop-'))) {
  require(controls[name].exact === 'true', `Loop exact control ${name}`);
}

const memory = {};
for (const revision of ['candidate', 'baseline']) {
  const item = result('memory-review', revision);
  const rows = item.text.split('\n').filter((line) => line.startsWith('MEMORY ')).map(fields);
  require(rows.length === 4 && rows.every((row) => row.nativeLive === 407794176), 'Retained memory changed');
  require(rows[0].flash === 'true' && rows[1].flash === 'false', 'Shape-selection control failed');
  memory[revision] = { rows, globalSwapoutPages: item.globalSwapoutPages };
}
for (let index = 0; index < 4; index++) {
  for (const key of ['length', 'flash', 'nativeLive', 'nativePeak', 'buffers']) {
    require(memory.candidate.rows[index][key] === memory.baseline.rows[index][key], `Memory mismatch ${key}`);
  }
}

const longResult = result('final-review', 'frisky-long-samples');
const longSamples = longResult.text.split('\n').filter((line) => line.startsWith('LONG ')).map(fields);
require(longSamples.length === 8 && longSamples.every((sample) => sample.shiftedSteps > 0), 'Window not crossed');
const input = new URL('./analysis-input-1/', import.meta.url);
const quality = (mode) => readFileSync(new URL(`frisky-quality-${mode}.log`, input), 'utf8')
  .split('\n').filter((line) => /^(BATCH|TOKEN .*position=1024 )/.test(line)).map(fields);
const rebuild = quality('candidate-rebuild'), rolling = quality('candidate-rolling');
const perBatch = [];
for (let index = 0; index < 4; index++) {
  require(rebuild[2 * index].loss === rolling[2 * index].loss, 'First pre-eviction token changed');
  perBatch.push({ sample: index, rebuildLoss: rebuild[2 * index + 1].loss,
    rollingLoss: rolling[2 * index + 1].loss,
    delta: rolling[2 * index + 1].loss - rebuild[2 * index + 1].loss });
}

const report = { controls, memory, longSamples, longSamplesGlobalSwapoutPages: longResult.globalSwapoutPages,
  perBatch, resolution: 'Original swap findings preserved. Loop fallback peak reproduces on both revisions; no new native-memory regression or retained-buffer growth. OS counters are system-wide and do not attribute which process was paged out.' };
writeFileSync(new URL('./review-resolution.json', import.meta.url), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
