package io.github.kirstenali.deepj.tensor;

import io.github.kirstenali.deepj.models.DecoderOnlyModel;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;

import java.lang.management.ManagementFactory;
import java.util.Random;

/** Isolates the existing aligned Flash / unaligned fallback prefill memory difference. */
public final class RollingMemoryDiagnostic {
    private RollingMemoryDiagnostic() {}

    public static void main(String[] args) throws Exception {
        if (!MetalBackend.isAvailable()) throw new IllegalStateException("Physical Metal required");
        Tensor.setBackend(new MetalBackend());
        MemoryRuntime runtime = MemoryRuntime.attach(Tensor.backend());
        try {
            run(MemoryModels.create("loop"), runtime);
        } finally {
            Tensor.backend().releaseResources();
            if (runtime.liveBytes != 0) throw new AssertionError("Native buffers leaked");
        }
    }

    private static void run(DecoderOnlyModel model, MemoryRuntime runtime) throws Exception {
        long retained = -1;
        for (int length : new int[]{1024, 1023, 1023, 1024}) {
            runtime.peakBytes = runtime.liveBytes;
            sample(model, length);
            Tensor.backend().releaseTemporaryResources();
            if (retained != -1 && runtime.liveBytes != retained) throw new AssertionError("Retained growth");
            retained = runtime.liveBytes;
            var heap = ManagementFactory.getMemoryMXBean().getHeapMemoryUsage();
            System.out.printf("MEMORY length=%d flash=%s nativeLive=%d nativePeak=%d buffers=%d heapUsed=%d%n",
                    length, flash(length), runtime.liveBytes, runtime.peakBytes, runtime.buffers.size(), heap.getUsed());
        }
        System.out.println("RESULT model=loop requests=4 retainedStable=true finalReleaseChecked=true");
    }

    private static void sample(DecoderOnlyModel model, int length) throws Exception {
        int[] tokens = new Random(991).ints(length, 0, 16_384).toArray();
        try (var session = RollingModes.open(model, "rebuild")) {
            for (float value : session.apply(tokens).rowData(0)) {
                if (!Float.isFinite(value)) throw new AssertionError("Nonfinite logit");
            }
        }
    }

    private static boolean flash(int length) {
        Tensor query = new Tensor(9 * length, 64);
        Tensor key = new Tensor(3 * length, 64);
        return ((CausalAttentionBackend) Tensor.backend()).supportsCausalAttention(query, key, key, 9, 3, 0.125f);
    }
}
