#!/bin/zsh
set -euo pipefail
task_root=QUALIFICATION_ROOT
task_jdk=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
task_out="$task_root/qualification"
mkdir -p "$task_out/private"
active_case=prepare
trap 'print -r -- "FAILED $active_case line=$LINENO" > "$task_out/status.txt"' ZERR
[[ "$(< "$task_root/initial/status.txt")" == 'INITIAL FULL BUILD PASSED; REVIEW REQUIRED' ]]
[[ "$(< "$task_root/preflight/status.txt")" == 'PREFLIGHT BUILD AND BENCHMARK HARNESS PASSED' ]]
"$task_jdk/bin/javac" -cp "$task_root/candidate/target/classes" \
  -d "$task_root/harness" "$task_root"/harness-source/*.java
find "$task_root/candidate/src" "$task_root/candidate/native" "$task_root/harness-source" \
  -type f -exec shasum -a 256 {} \; > "$task_out/frozen-source-manifest.txt"
find "$task_root/candidate/target/classes" "$task_root/baseline/target/classes" "$task_root/harness" \
  -type f -exec shasum -a 256 {} \; > "$task_out/frozen-binary-manifest.txt"

function execute_case() {
  local case_name="$1" revision="$2" main_class="$3"
  shift 3
  active_case="$case_name"
  print -r -- "RUNNING $active_case" > "$task_out/status.txt"
  { date -u; /usr/sbin/sysctl vm.swapusage; /usr/bin/vm_stat; } > "$task_out/$active_case-before.txt"
  /usr/bin/time -l "$task_jdk/bin/java" -Xmx6g -XX:+ExitOnOutOfMemoryError \
    --enable-native-access=ALL-UNNAMED \
    -cp "$task_root/$revision/target/classes:$task_root/harness" \
    "$main_class" "$@" > "$task_out/$active_case.log" 2>&1
  /usr/bin/grep -q '^RESULT ' "$task_out/$active_case.log"
  { date -u; /usr/sbin/sysctl vm.swapusage; /usr/bin/vm_stat; } > "$task_out/$active_case-after.txt"
}

for profile in prism nova loop; do
  execute_case "$profile-oracle-reference" candidate io.github.kirstenali.deepj.tensor.RollingOracle \
    "$profile" reference "$task_out/private/$profile-oracle.bin"
  execute_case "$profile-oracle-rolling" candidate io.github.kirstenali.deepj.tensor.RollingOracle \
    "$profile" rolling "$task_out/private/$profile-oracle.bin"
  execute_case "$profile-pre-baseline" baseline RollingLogits \
    "$profile" rebuild write "$task_out/private/$profile-pre.bin"
  execute_case "$profile-pre-candidate-rebuild" candidate RollingLogits \
    "$profile" rebuild compare "$task_out/private/$profile-pre.bin"
  execute_case "$profile-pre-candidate-rolling" candidate RollingLogits \
    "$profile" rolling compare "$task_out/private/$profile-pre.bin"
  execute_case "$profile-state-baseline" baseline RollingStateHash "$profile" rebuild
  execute_case "$profile-state-candidate" candidate RollingStateHash "$profile" rebuild
  execute_case "$profile-state-after-rolling" candidate RollingStateHash "$profile" rolling
  baseline_state=$(/usr/bin/grep '^RESULT ' "$task_out/$profile-state-baseline.log" | /usr/bin/sed 's/mode=[^ ]* //')
  for case_suffix in candidate after-rolling; do
    candidate_state=$(/usr/bin/grep '^RESULT ' "$task_out/$profile-state-$case_suffix.log" | /usr/bin/sed 's/mode=[^ ]* //')
    [[ "$baseline_state" == "$candidate_state" ]]
  done
done

for round in 1 2 3; do
  order=(baseline candidate)
  if (( round == 2 )); then order=(candidate baseline); fi
  pre_order=(baseline candidate rolling)
  if (( round == 2 )); then pre_order=(rolling baseline candidate); fi
  if (( round == 3 )); then pre_order=(candidate rolling baseline); fi
  for profile in prism nova loop; do
    for entry in $pre_order; do
      revision="$entry"
      mode=rebuild
      if [[ "$entry" == rolling ]]; then revision=candidate; mode=rolling; fi
      execute_case "$profile-pretime-r$round-$entry" "$revision" \
        io.github.kirstenali.deepj.tensor.RollingBenchmark "$profile" "$mode" 128 16 7
    done
    for revision in $order; do
      mode=rebuild
      if [[ "$revision" == candidate ]]; then mode=rolling; fi
      execute_case "$profile-posttime-r$round-$revision" "$revision" \
        io.github.kirstenali.deepj.tensor.RollingBenchmark "$profile" "$mode" 1024 16 7
    done
  done
done

for profile in prism nova loop; do
  for revision in baseline candidate; do
    execute_case "$profile-real-$revision" "$revision" QualificationTraining \
      "$profile" 100 PRIMARY_PROJECTFlashQualification/data
  done
  total=2048
  requests=50
  if [[ "$profile" == loop ]]; then total=4096; requests=200; fi
  execute_case "$profile-endurance-rolling" candidate \
    io.github.kirstenali.deepj.tensor.RollingEndurance "$profile" "$total" "$requests"
done

for revision in baseline candidate; do
  execute_case "frisky-quality-$revision-rebuild" "$revision" RollingQuality \
    PRIMARY_PROJECT rebuild
  execute_case "frisky-samples-$revision-rebuild" "$revision" RollingSamples \
    PRIMARY_PROJECT/checkpoints/deepj-90m/sft rebuild
done
execute_case frisky-quality-candidate-rolling candidate RollingQuality \
  PRIMARY_PROJECT rolling
execute_case frisky-samples-candidate-rolling candidate RollingSamples \
  PRIMARY_PROJECT/checkpoints/deepj-90m/sft rolling

for round in 1 2 3; do
  order=(baseline candidate)
  if (( round == 2 )); then order=(candidate baseline); fi
  for revision in $order; do
    execute_case "cpu-r$round-$revision" "$revision" MemoryCpuTiming prism 3000 3000
  done
done
print -r -- 'ALL ROLLING-CACHE QUALIFICATION CASES COMPLETED; ANALYSIS REQUIRED' > "$task_out/status.txt"
