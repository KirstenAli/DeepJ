#!/bin/zsh
set -euo pipefail
task_root=QUALIFICATION_ROOT
task_jdk=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
task_out="$task_root/qualification-recovery-1"
mkdir -p "$task_out"
active_case=prepare
trap 'print -r -- "FAILED $active_case line=$LINENO" > "$task_out/status.txt"' ZERR
[[ "$(< "$task_root/qualification/status.txt")" == 'FAILED frisky-samples-baseline-rebuild line=6' ]]
shasum -a 256 -c "$task_root/qualification/frozen-source-manifest.txt" > "$task_out/source-integrity.txt"
shasum -a 256 -c "$task_root/qualification/frozen-binary-manifest.txt" > "$task_out/binary-integrity.txt"

function execute_case() {
  local case_name="$1" revision="$2" main_class="$3"
  shift 3
  active_case="$case_name"
  print -r -- "RUNNING $active_case" > "$task_out/status.txt"
  { date -u; /usr/sbin/sysctl vm.swapusage; /usr/bin/vm_stat; } > "$task_out/$active_case-before.txt"
  /usr/bin/time -l "$task_jdk/bin/java" -Xmx6g -XX:+ExitOnOutOfMemoryError \
    --enable-native-access=ALL-UNNAMED \
    -cp "$task_root/$revision/target/classes:$task_root/harness" \
    "$main_class" "$@" > "$task_out/$active_case.log" 2>&1
  /usr/bin/grep -q '^RESULT ' "$task_out/$active_case.log"
  { date -u; /usr/sbin/sysctl vm.swapusage; /usr/bin/vm_stat; } > "$task_out/$active_case-after.txt"
}

# The failed harness invocation passed a directory without a model.dj file.
# Pass the real existing checkpoint explicitly; do not rename or copy the user's model.
execute_case frisky-samples-baseline-rebuild baseline RollingSamples \
  PRIMARY_PROJECT/checkpoints/deepj-90m/sft/model-final.dj rebuild
execute_case frisky-quality-candidate-rebuild candidate RollingQuality \
  PRIMARY_PROJECT rebuild
execute_case frisky-samples-candidate-rebuild candidate RollingSamples \
  PRIMARY_PROJECT/checkpoints/deepj-90m/sft/model-final.dj rebuild
execute_case frisky-quality-candidate-rolling candidate RollingQuality \
  PRIMARY_PROJECT rolling
execute_case frisky-samples-candidate-rolling candidate RollingSamples \
  PRIMARY_PROJECT/checkpoints/deepj-90m/sft/model-final.dj rolling
for round in 1 2 3; do
  order=(baseline candidate)
  if (( round == 2 )); then order=(candidate baseline); fi
  for revision in $order; do
    execute_case "cpu-r$round-$revision" "$revision" MemoryCpuTiming prism 3000 3000
  done
done
print -r -- 'RECOVERY CASES COMPLETED; ANALYSIS REQUIRED' > "$task_out/status.txt"
