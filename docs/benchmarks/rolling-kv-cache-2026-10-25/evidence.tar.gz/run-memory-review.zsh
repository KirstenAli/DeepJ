#!/bin/zsh
set -euo pipefail
task_root=QUALIFICATION_ROOT
task_jdk=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
task_out="$task_root/memory-review"
mkdir -p "$task_out"
active_case=prepare
trap 'print -r -- "FAILED $active_case line=$LINENO" > "$task_out/status.txt"' ZERR
"$task_jdk/bin/javac" -cp "$task_root/candidate/target/classes:$task_root/harness" \
  -d "$task_root/additional-harness" "$task_root/additional-source/RollingMemoryDiagnostic.java"
for revision in candidate baseline; do
  active_case="$revision"
  print -r -- "RUNNING $active_case" > "$task_out/status.txt"
  { date -u; /usr/sbin/sysctl vm.swapusage; /usr/bin/vm_stat; } > "$task_out/$revision-before.txt"
  /usr/bin/time -l "$task_jdk/bin/java" -Xmx6g -XX:+ExitOnOutOfMemoryError \
    --enable-native-access=ALL-UNNAMED \
    -cp "$task_root/$revision/target/classes:$task_root/harness:$task_root/additional-harness" \
    io.github.kirstenali.deepj.tensor.RollingMemoryDiagnostic > "$task_out/$revision.log" 2>&1
  /usr/bin/grep -q '^RESULT ' "$task_out/$revision.log"
  { date -u; /usr/sbin/sysctl vm.swapusage; /usr/bin/vm_stat; } > "$task_out/$revision-after.txt"
done
print -r -- 'MEMORY REVIEW CONTROLS COMPLETED; ANALYSIS REQUIRED' > "$task_out/status.txt"
