package io.github.kirstenali.deepj.nn.diffusion.sana;
import io.github.kirstenali.deepj.tokenizers.gemma.GemmaTokenizer;
import io.github.kirstenali.deepj.persistence.qwen3.Qwen3Json;
import java.nio.*;
import java.nio.file.*;
import java.util.*;
public final class ImageInputs {
 public static void main(String[] args)throws Exception {
  Path out=Path.of(args[1]);Files.createDirectories(out);
  var prompt=new SanaPrompt(new GemmaTokenizer(Path.of(args[0]).resolve("tokenizer")),
   "A red fox in a snowy forest, soft morning light, detailed wildlife photograph");
  Files.writeString(out.resolve("image-input.json"),Qwen3Json.stringify(Map.of("tokens",Arrays.stream(prompt.tokens()).boxed().toList(),"valid",Arrays.stream(prompt.valid()).boxed().toList(),"selected",Arrays.stream(prompt.selected()).boxed().toList(),"mask",Arrays.stream(prompt.mask()).boxed().toList())));
  Random random=new Random(42);
  for(int sample=0;sample<2;sample++) {
   ByteBuffer data=ByteBuffer.allocate(32*32*32*4).order(ByteOrder.LITTLE_ENDIAN);
   for(int i=0;i<32*32*32;i++)data.putFloat((float)random.nextGaussian());
   Files.write(out.resolve("image-noise-"+sample+".f32"),data.array());
  }
 }
}
