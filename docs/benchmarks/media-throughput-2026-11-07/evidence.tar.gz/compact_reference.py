import sys,json
from pathlib import Path
import torch
from safetensors.torch import load_file,save_file
from diffusers import SanaTransformer2DModel,AutoencoderDC
root=Path(sys.argv[1]);reference=load_file(root/'model.safetensors');outputs={}
torch.set_num_threads(2)
with torch.inference_mode():
 for label,dtype in [('float16',torch.float16),('bfloat16',torch.bfloat16)]:
  config=json.loads((root/'transformer/config.json').read_text())
  model=SanaTransformer2DModel.from_config(config)
  model.load_state_dict(load_file(root/'transformer/model.safetensors'));model=model.to(dtype).eval()
  outputs[label+'.transformer']=model(reference['transformer.input'].to(dtype),encoder_hidden_states=reference['transformer.text'].to(dtype),encoder_attention_mask=reference['transformer.mask'].long().reshape(1,-1),timestep=torch.tensor([.6]),guidance=torch.tensor([4.5*config['guidance_embeds_scale']]),return_dict=False)[0].float().contiguous()
  config=json.loads((root/'vae/config.json').read_text())
  model=AutoencoderDC.from_config(config);model.load_state_dict(load_file(root/'vae/model.safetensors'));model=model.to(dtype).eval()
  for size in [2,4]:outputs[label+'.vae'+str(size)]=model.decode(reference['vae'+str(size)+'.input'].to(dtype),return_dict=False)[0].float().contiguous()
(root/'compact').mkdir(exist_ok=True)
save_file(outputs,str(root/'compact/model.safetensors'))
print({key:list(value.shape) for key,value in outputs.items()})
