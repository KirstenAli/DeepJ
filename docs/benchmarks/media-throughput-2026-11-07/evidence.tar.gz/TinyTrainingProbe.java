import io.github.kirstenali.deepj.concurrent.DeepJExecutor;
import io.github.kirstenali.deepj.data.Batch;
import io.github.kirstenali.deepj.nn.transformer.CausalLM;
import io.github.kirstenali.deepj.nn.transformer.loop.*;
import io.github.kirstenali.deepj.nn.transformer.prism.*;
import io.github.kirstenali.deepj.nn.transformer.qwen3.*;
import io.github.kirstenali.deepj.persistence.qwen3.Qwen3Json;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.cpu.CpuBackend;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;
import io.github.kirstenali.deepj.training.CausalLMTraining;
import java.security.MessageDigest;
import java.util.*;

public final class TinyTrainingProbe {
 public static void main(String[] args) throws Exception {
  Tensor.setBackend(args[0].equals("metal") ? new MetalBackend() : new CpuBackend());
  DeepJExecutor.setNumThreads(Integer.getInteger("probe.threads",10));
  try { run(args); }
  finally { Tensor.backend().releaseResources(); DeepJExecutor.shutdown(); }
 }
 private static void run(String[] args) throws Exception {
  CausalLM model=switch(args[1]) {
   case "loop" -> new DeepJLoop(new DeepJLoopConfig(128,64,64,4,2,0,1,0,2,128),2026L);
   case "prism" -> new DeepJPrism(new DeepJPrismConfig(128,64,64,4,1,128,32,16),2026L);
   case "qwen" -> new Qwen3(new Qwen3Config(128,64,64,4,2,1,128,16,1000000,0.02f,1),2026L);
   default -> throw new IllegalArgumentException();
  };
  int[][] x=new int[1][32],y=new int[1][32];
  for(int i=0;i<32;i++){x[0][i]=(i*7+11)%128;y[0][i]=((i+1)*7+11)%128;}
  var trainer=CausalLMTraining.trainer(model,ignored->new Batch(x,y),1e-4f);
  var milliseconds=new ArrayList<Double>();
  var losses=new ArrayList<Float>();
  for(int run=-Integer.getInteger("deepj.probe.warmups",20);run<Integer.getInteger("deepj.probe.runs",11);run++) {
   long start=System.nanoTime();float loss=trainer.trainStep(1);
   Tensor.backend().releaseTemporaryResources();
   if(run>=0) milliseconds.add((System.nanoTime()-start)/1e6);
   losses.add(loss);
  }
  MessageDigest values=MessageDigest.getInstance("SHA-256"),gradients=MessageDigest.getInstance("SHA-256");
  for(var parameter:model.parameters()) {
   hash(values,parameter.value.toFloatArray());
   if(parameter.grad()!=null) hash(gradients,parameter.grad().toFloatArray());
  }
  System.out.println(Qwen3Json.stringify(Map.of("backend",args[0],"model",args[1],"milliseconds",milliseconds,"losses",losses,"parameters_sha256",HexFormat.of().formatHex(values.digest()),"gradients_sha256",HexFormat.of().formatHex(gradients.digest()))));
 }
 private static void hash(MessageDigest digest,float[] array) {
  for(float f:array) {
   int v=Float.floatToRawIntBits(f);
   digest.update((byte)(v>>>24));digest.update((byte)(v>>>16));digest.update((byte)(v>>>8));digest.update((byte)v);
  }
 }
}
