#!/bin/bash
set -euo pipefail
root=$WORKSPACE
out="$root/outputs/media-throughput-2026-11-07"
export JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
export PYTORCH_ENABLE_MPS_FALLBACK=0
jdk="$JAVA_HOME/bin"
py="$root/outputs/sana-video-recovery/reference-env/bin/python"
cd "$root/work/deepj-qwen-thinking"
/opt/homebrew/bin/mvn -q -Dtest=ModelSiluTest,ModelNormTest,ModelLinearAttentionTest,ModelRmsTest,MetalComposedRmsTest,MetalCompactNormalizationTest,MetalConvolutionTest,MetalConvolutionValidationTest,MetalNdIndexTest,MetalStorageCopyTest,MetalLayoutCopyTest,MetalDenseLayoutAddressTest,Gemma2BatchTest,Gemma2ReferenceTest,DepthwiseConv2DTest,SanaCompactReferenceTest,SanaReferenceTest,SanaAutogradTest,ModelInferenceTest,VideoPrecisionTest,VideoGuidanceTest,SanaVideoReferenceTest,SanaVideoPipelineTest,VideoWeightCacheTest -Dgemma.test.metal=true -Dsanavideo.test.metal=true -Dsana.test.metal=true surefire:test > "$out/accepted-physical-tests.log" 2>&1
"$jdk/javac" -cp "$out/candidate.jar" -d "$out" "$out/MediaDemoProbe.java" "$out/ImageInputs.java"
"$jdk/java" -cp "$out/candidate.jar:$out" io.github.kirstenali.deepj.nn.diffusion.sana.ImageInputs "$root/outputs/sana-sprint-readme/model" "$out"
image_run() {
 engine="$1";dtype="$2";trial="$3";result="$out/accepted-image-$dtype-$engine-$trial"
 if [[ "$engine" == deepj ]]; then
  "$py" -B "$out/run_guarded.py" --timeout 90 --rss-gib 9 --swap-mib 64 --log "$result.log" -- "$jdk/java" -Xmx2g -Ddeepj.metal.maxBufferBytes=6442450944 -cp "$out/candidate.jar:$out" MediaDemoProbe image "$root/outputs/sana-sprint-readme/model" "$result" "$dtype"
 else
  "$py" -B "$out/run_guarded.py" --timeout 90 --rss-gib 10 --swap-mib 64 --log "$result.log" -- "$py" -B "$out/image_reference.py" "$root/outputs/sana-sprint-readme/model" "$out" "$result" "$dtype"
 fi
}
for trial in 1 2; do
 for dtype in FLOAT32 FLOAT16 BFLOAT16; do
  if [[ "$trial" == 1 ]]; then image_run deepj "$dtype" "$trial"; image_run python "$dtype" "$trial"
  else image_run python "$dtype" "$trial"; image_run deepj "$dtype" "$trial"; fi
 done
done
for dtype in BFLOAT16 FLOAT16 FLOAT32; do
 result="$out/accepted-video-$dtype-python";mkdir -p "$result"
 cp "$out/noise.f32" "$out/video-input.json" "$result/"
 "$py" -B "$out/run_guarded.py" --timeout 60 --rss-gib 10 --swap-mib 64 --log "$result.log" -- "$py" -B "$out/video_reference.py" "$root/outputs/sana-video-model" "$result" "$dtype" --safe-fp16
 result="$out/accepted-video-$dtype-deepj"
 "$py" -B "$out/run_guarded.py" --timeout 60 --rss-gib 9 --swap-mib 64 --log "$result.log" -- "$jdk/java" -Xmx2g -Ddeepj.metal.maxBufferBytes=6442450944 -cp "$out/candidate.jar:$out" MediaDemoProbe video "$root/outputs/sana-video-model" "$result" "$dtype"
done
echo FINAL_MATCHED_COMPLETE
/opt/homebrew/bin/mvn -q clean verify -Pfull-coverage > "$out/accepted-full-verify.log" 2>&1
echo ACCEPTED_FULL_VERIFY_COMPLETE
