import io.github.kirstenali.deepj.concurrent.DeepJExecutor;
import io.github.kirstenali.deepj.nn.TensorJoin;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.cpu.CpuBackend;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;
import io.github.kirstenali.deepj.autograd.GradMode;
import io.github.kirstenali.deepj.persistence.qwen3.Qwen3Json;
import java.util.*;
public final class ProjectionProbe {
 public static void main(String[]args)throws Exception{
  boolean metal=args[0].equals("metal");if(metal&&!MetalBackend.isAvailable())throw new IllegalStateException();
  Tensor.setBackend(metal?new MetalBackend():new CpuBackend());DeepJExecutor.setNumThreads(10);
  try{run(args);}finally{Tensor.backend().releaseResources();DeepJExecutor.shutdown();}
 }
 static Tensor values(int rows,int cols, int seed){var r=new Random(seed);float[]v=new float[rows*cols];for(int i=0;i<v.length;i++)v[i]=r.nextFloat()*.1f-.05f;return Tensor.from(v,rows,cols).retainDeviceBuffer();}
 static void run(String[]args){
  boolean train=args[2].equals("training");int rows=Integer.parseInt(args[3]);String mode=args[1];
  Tensor x=values(rows,512,12).requiresGrad(train);Tensor[] w={values(512,512,13).requiresGrad(train),values(512,256,14).requiresGrad(train),values(512,256,15).requiresGrad(train)};
  Tensor packed;try(var no=GradMode.noGrad()){packed=TensorJoin.concatenate(1,w).retainDeviceBuffer();packed.toFloatArray();}
  var times=new ArrayList<Double>();float loss=0;
  for(int i=-100;i<30;i++){
   if(train){x.gradientState().bindGradient(null);for(Tensor weight:w)weight.gradientState().bindGradient(null);}
   long start=System.nanoTime();
   try(var scope=TensorScope.open();var no=train?null:GradMode.noGrad()){
    Tensor result;
    if(mode.equals("separate")){result=x.matmul(w[0]).sumTensor().add(x.matmul(w[1]).sumTensor()).add(x.matmul(w[2]).sumTensor());}
    else{Tensor joined=mode.equals("cached")?packed:TensorJoin.concatenate(1,w);result=x.matmul(joined).sumTensor();}
    if(train)result.backward();loss=result.item();
   }
   Tensor.backend().releaseTemporaryResources();if(i>=0)times.add((System.nanoTime()-start)/1e6);
  }
  System.out.println(Qwen3Json.stringify(Map.of("backend",args[0],"mode",mode,"training",train,"rows",rows,"ms",times,"loss",loss)));
 }
}
