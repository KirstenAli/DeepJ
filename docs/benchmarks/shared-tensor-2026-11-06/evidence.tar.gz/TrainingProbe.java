import io.github.kirstenali.deepj.concurrent.DeepJExecutor;
import io.github.kirstenali.deepj.nn.FNN;
import io.github.kirstenali.deepj.activations.ReLU;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.cpu.CpuBackend;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;
import io.github.kirstenali.deepj.optimisers.*;
import io.github.kirstenali.deepj.loss.MSELoss;
import io.github.kirstenali.deepj.autograd.GradMode;
import io.github.kirstenali.deepj.persistence.qwen3.Qwen3Json;
import java.util.*;
import java.io.*;
public final class TrainingProbe {
 public static void main(String[] args)throws Exception{
  boolean metal=args[0].equals("metal");if(metal&&!MetalBackend.isAvailable())throw new IllegalStateException("Metal unavailable");
  Tensor.setBackend(metal?new MetalBackend():new CpuBackend());DeepJExecutor.setNumThreads(10);
  try{run(args);}finally{Tensor.backend().releaseResources();DeepJExecutor.shutdown();}
 }
 static void run(String[]args)throws Exception{
  var model=new FNN(256,new int[]{512,512},128,ReLU::new,new Random(123));var ps=model.parameters();
  var rng=new Random(456);var x=values(rng,64,256);var y=values(rng,64,128);
  try(var stream=new DataOutputStream(new FileOutputStream(args[2]+".input"))){write(stream,x);write(stream,y);for(var p:ps)write(stream,p.value);}
  var opt=AdamW.defaultAdamW(1e-4f);var objective=new MSELoss();var times=new ArrayList<Double>();var losses=new ArrayList<Float>();
  for(int run=-50;run<20;run++){
   long start=System.nanoTime();float loss;
   try(var scope=TensorScope.open()){
    if(args[1].equals("training")){for(var p:ps)p.zeroGrad();var value=objective.forward(model.forward(x),y);value.backward();opt.step(ps);loss=value.item();}
    else try(var no=GradMode.noGrad()){loss=objective.forward(model.forward(x),y).item();}
   }
   Tensor.backend().releaseTemporaryResources();
   if(run>=0)times.add((System.nanoTime()-start)/1e6);losses.add(loss);
  }
  try(var stream=new DataOutputStream(new FileOutputStream(args[2]+".final"))){for(var p:ps)write(stream,p.value);}
  System.out.println(Qwen3Json.stringify(Map.of("backend",args[0],"mode",args[1],"ms",times,"losses",losses)));
 }
 static Tensor values(Random r,int rows,int cols){float[]v=new float[rows*cols];for(int i=0;i<v.length;i++)v[i]=r.nextFloat()*.2f-.1f;return Tensor.from(v,rows,cols).retainDeviceBuffer();}
 static void write(DataOutputStream s,Tensor t)throws Exception{for(float v:t.toFloatArray())s.writeFloat(v);}
}
