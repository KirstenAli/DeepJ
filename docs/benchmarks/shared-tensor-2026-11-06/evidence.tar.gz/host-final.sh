#!/bin/bash
set -euo pipefail
export JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
cd /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/work/deepj-qwen-thinking
"$JAVA_HOME/bin/jar" cf /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/final.jar -C target/classes .
for iteration in 1 2; do
 revisions="baseline candidate"
 if [ "$iteration" = 2 ]; then revisions="candidate baseline"; fi
 for model in loop qwen prism; do
  for mode in inference training; do
   for revision in $revisions; do
    source_dir=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/baseline.jar
    if [ "$revision" = candidate ]; then source_dir=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/final.jar; fi
    "$JAVA_HOME/bin/java" -Xmx1g -Xbatch -XX:CompileThresholdScaling=0.1 -Dprobe.warmups=100 -Dprobe.samples=30 --enable-native-access=ALL-UNNAMED -cp "$source_dir:/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations" QuickProbe metal "$model" "$mode" > /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/final-metal-$model-$mode-$revision-$iteration.json
   done
  done
 done
done
for iteration in 1 2; do
 prefix=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/final-fnn-metal-training-candidate-$iteration
 "$JAVA_HOME/bin/java" -Xmx1g -Xbatch -XX:CompileThresholdScaling=0.1 --enable-native-access=ALL-UNNAMED -cp /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/final.jar:/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations TrainingProbe metal training "$prefix" > "$prefix.json"
 target=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/final-fnn-metal-training-pytorch-$iteration
 /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/cpu-throughput/reference-env/bin/python /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/training_reference.py metal training "$prefix.input" "$target" > "$target.json"
done
printf 'FINAL_PROBES_DONE\n'
bash /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/host-verify.sh
