import io.github.kirstenali.deepj.concurrent.DeepJExecutor;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.cpu.CpuBackend;
import io.github.kirstenali.deepj.persistence.qwen3.Qwen3Json;
import java.util.*;
public final class OperatorProbe {
 public static void main(String[]args){Tensor.setBackend(new CpuBackend());DeepJExecutor.setNumThreads(10);try{run(args);}finally{DeepJExecutor.shutdown();}}
 static void run(String[]args){
  int rows=Integer.parseInt(args[1]),width=Integer.parseInt(args[2]);var r=new Random(2026);float[]v=new float[rows*width];for(int i=0;i<v.length;i++)v[i]=r.nextFloat()*2-1;
  Tensor x=Tensor.from(v,rows,width),g=Tensor.from(Arrays.copyOf(v,width),1,width);var norm=Tensor.backend().normalize(x,g,null,1e-5f,false);var times=new ArrayList<Double>();double check=0;
  for(int run=-50;run<30;run++){
   long start=System.nanoTime();Tensor result=switch(args[0]){
    case "norm"->Tensor.backend().normalize(x,g,null,1e-5f,false).output();
    case "backward"->Tensor.backend().normalizationBackward(x,norm.normalized(),norm.denominator(),g,false);
    case "softmax"->Tensor.backend().causalSoftmax(x,width,.125f);
    default->throw new IllegalArgumentException();};
   check+=result.rawData()[0];if(run>=0)times.add((System.nanoTime()-start)/1e6);
  }
  System.out.println(Qwen3Json.stringify(Map.of("op",args[0],"rows",rows,"width",width,"ms",times,"check",check)));
 }
}
