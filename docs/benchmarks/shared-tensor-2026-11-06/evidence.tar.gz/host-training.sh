#!/bin/bash
set -euo pipefail
export JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
cd /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/work/deepj-qwen-thinking
for backend in cpu metal; do
 for mode in inference training; do
  for iteration in 1 2; do
   revisions="baseline candidate"
   if [ "$iteration" = 2 ]; then revisions="candidate baseline"; fi
   for revision in $revisions; do
    source_dir=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/baseline.jar
    if [ "$revision" = candidate ]; then source_dir=target/classes; fi
    prefix=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/fnn-$backend-$mode-$revision-$iteration
    "$JAVA_HOME/bin/java" -Xmx1g -Xbatch -XX:CompileThresholdScaling=0.1 --enable-native-access=ALL-UNNAMED -cp "$source_dir:/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations" TrainingProbe "$backend" "$mode" "$prefix" > "$prefix.json"
   done
   prefix=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/fnn-$backend-$mode-pytorch-$iteration
   /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/cpu-throughput/reference-env/bin/python /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/training_reference.py "$backend" "$mode" /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/fnn-$backend-$mode-baseline-$iteration.input "$prefix" > "$prefix.json"
  done
 done
done
printf 'TRAINING_PROBES_DONE\n'
