import io.github.kirstenali.deepj.concurrent.DeepJExecutor;
import io.github.kirstenali.deepj.nn.transformer.*;
import io.github.kirstenali.deepj.nn.transformer.qwen3.*;
import io.github.kirstenali.deepj.nn.transformer.loop.*;
import io.github.kirstenali.deepj.nn.transformer.prism.*;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.cpu.CpuBackend;
import io.github.kirstenali.deepj.tensor.metal.MetalBackend;
import io.github.kirstenali.deepj.data.Batch;
import io.github.kirstenali.deepj.training.CausalLMTraining;
import io.github.kirstenali.deepj.persistence.qwen3.Qwen3Json;
import java.util.*;
import java.security.MessageDigest;

public final class QuickProbe {
 public static void main(String[] args) throws Exception {
  boolean metal=args[0].equals("metal");
  if(metal&&!MetalBackend.isAvailable())throw new IllegalStateException("Physical Metal required");
  Tensor.setBackend(metal?new MetalBackend():new CpuBackend());DeepJExecutor.setNumThreads(10);
  try{run(args[1],args[2]);}finally{Tensor.backend().releaseResources();DeepJExecutor.shutdown();}
 }
 static CausalLM model(String name) {
  return switch(name) {
   case "qwen" -> new Qwen3(new Qwen3Config(256,128,256,4,2,2,512,128,1000000,0.02f,1),2026);
   case "loop" -> new DeepJLoop(new DeepJLoopConfig(256,128,256,4,2,0,1,0,2,512),2026);
   case "prism" -> new DeepJPrism(new DeepJPrismConfig(256,128,256,4,2,512,128,64),2026);
   default -> throw new IllegalArgumentException(name);
  };
 }
 static void run(String name,String mode) throws Exception {
  CausalLM model=model(name);int[] tokens=new Random(3).ints(64,0,256).toArray();
  int[] targets=new Random(4).ints(64,0,256).toArray();
  var times=new ArrayList<Double>();var losses=new ArrayList<Float>();
  var trainer=CausalLMTraining.trainer(model,n->new Batch(new int[][]{tokens},new int[][]{targets}),1e-4f);
  var hash=MessageDigest.getInstance("SHA-256");
  for(int run=-Integer.getInteger("probe.warmups",10);run<Integer.getInteger("probe.samples",7);run++) {
   long start=System.nanoTime();
   if(mode.equals("training")){float loss=trainer.trainStep(1);losses.add(loss);if(!Float.isFinite(loss))throw new AssertionError();}
   else try(var session=model.openGeneration()) {
    float[] logits=session.apply(tokens).toFloatArray();add(hash,logits);
    for(int j=0;j<4;j++){int[] next=Arrays.copyOf(tokens,65+j);for(int k=64;k<next.length;k++)next[k]=k%256;add(hash,session.apply(next).toFloatArray());}
   }
   Tensor.backend().releaseTemporaryResources();
   if(run>=0)times.add((System.nanoTime()-start)/1e6);
  }
  if(mode.equals("training"))for(var p:model.parameters()){add(hash,p.value.toFloatArray());add(hash,p.grad().toFloatArray());}
  System.out.println(Qwen3Json.stringify(Map.of("model",name,"mode",mode,"ms",times,"losses",losses,"sha256",HexFormat.of().formatHex(hash.digest()))));
 }
 static void add(MessageDigest hash,float[] values){for(float v:values){int x=Float.floatToRawIntBits(v);for(int k=0;k<4;k++)hash.update((byte)(x>>>(k*8)));}}
}
