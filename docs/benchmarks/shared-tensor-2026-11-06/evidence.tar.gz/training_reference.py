import os, sys, json, time
import numpy as np
import torch
backend, mode, source, destination=sys.argv[1:]
torch.set_num_threads(10)
torch.set_num_interop_threads(1)
device="mps" if backend=="metal" else "cpu"
v=np.fromfile(source,dtype=">f4").astype(np.float32)
shapes=[(64,256),(64,128),(256,512),(1,512),(512,512),(1,512),(512,128),(1,128)]
arrays=[];offset=0
for shape in shapes:
 count=int(np.prod(shape));arrays.append(torch.tensor(v[offset:offset+count].reshape(shape),device=device));offset+=count
assert offset==len(v)
x,y,*p=arrays
for a in p:a.requires_grad_(True)
opt=torch.optim.AdamW(p,lr=1e-4,betas=(.9,.999),eps=1e-8,weight_decay=.01)
def sync():
 if device=="mps":torch.mps.synchronize()
def forward():
 h=torch.relu(x@p[0]+p[1]);h=torch.relu(h@p[2]+p[3]);return h@p[4]+p[5]
times=[];losses=[]
for i in range(-50,20):
 sync();start=time.perf_counter()
 if mode=="training":
  opt.zero_grad(set_to_none=False);loss=torch.mean((forward()-y)**2);loss.backward();opt.step()
 else:
  with torch.no_grad():loss=torch.mean((forward()-y)**2)
 scalar=loss.item();sync();elapsed=(time.perf_counter()-start)*1000
 if i>=0:times.append(elapsed)
 losses.append(scalar)
np.concatenate([a.detach().cpu().numpy().reshape(-1) for a in p]).astype(">f4").tofile(destination+".final")
print(json.dumps(dict(engine="PyTorch",version=torch.__version__,backend=backend,mode=mode,ms=times,losses=losses)))
