#!/bin/bash
set -euo pipefail
export JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
for iteration in 1 2; do
 for model in loop qwen prism; do
  variants="candidate original"
  if [ "$iteration" = 2 ]; then variants="original candidate"; fi
  for variant in $variants; do
   source_dir=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/optimized.jar
   if [ "$variant" = original ]; then source_dir=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/no-head-views:$source_dir; fi
   "$JAVA_HOME/bin/java" -Xmx1g -Xbatch -XX:CompileThresholdScaling=0.1 -Dprobe.warmups=100 -Dprobe.samples=30 --enable-native-access=ALL-UNNAMED -cp "$source_dir:/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations" QuickProbe metal "$model" inference > /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/layout-$model-$variant-$iteration.json
  done
 done
done
printf 'LAYOUT_CONTROLS_DONE\n'
