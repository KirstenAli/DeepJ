#!/bin/bash
set -euo pipefail
export JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
cd /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/work/deepj-qwen-thinking
"$JAVA_HOME/bin/javac" -cp target/classes -d /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/OperatorProbe.java
for op in softmax; do
 for shape in "256 256" "4096 512"; do
  for revision in baseline candidate; do
   source_dir=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/baseline.jar
   if [ "$revision" = candidate ]; then source_dir=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/optimized.jar; fi
   "$JAVA_HOME/bin/java" -Xmx1g -Xbatch -XX:CompileThresholdScaling=0.1 --enable-native-access=ALL-UNNAMED -cp "$source_dir:/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations" OperatorProbe "$op" $shape > "/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/operator-$op-$shape-$revision.json"
  done
 done
done
printf 'OPERATOR_PROBES_DONE\n'
