#!/bin/bash
set -euo pipefail
export JAVA_HOME=/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home
cd /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/work/deepj-qwen-thinking
"$JAVA_HOME/bin/javac" -cp target/classes -d /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/QuickProbe.java /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/ProjectionProbe.java
for iteration in 1 2; do
 revisions="baseline candidate"
 if [ "$iteration" = 2 ]; then revisions="candidate baseline"; fi
 for backend in cpu metal; do
  for model in qwen loop prism; do
   for mode in inference training; do
    for revision in $revisions; do
     source_dir=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/baseline.jar
     if [ "$revision" = candidate ]; then source_dir=/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/optimized.jar; fi
     "$JAVA_HOME/bin/java" -Xmx1g -Xbatch -XX:CompileThresholdScaling=0.1 -Dprobe.warmups=100 -Dprobe.samples=30 --enable-native-access=ALL-UNNAMED -cp "$source_dir:/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations" QuickProbe "$backend" "$model" "$mode" > /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/balanced-$backend-$model-$mode-$revision-$iteration.json
    done
   done
  done
 done
done
for mode in inference training; do
 DEEPJ_METAL_DISABLE_BUFFER_REUSE=1 "$JAVA_HOME/bin/java" -Xmx1g -Xbatch -XX:CompileThresholdScaling=0.1 -Dprobe.warmups=100 -Dprobe.samples=30 --enable-native-access=ALL-UNNAMED -cp /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/optimized.jar:/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations QuickProbe metal qwen "$mode" > /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/pool-off-qwen-$mode.json
done
for backend in cpu metal; do
 for mode in inference training; do
  variants="separate joined"
  if [ "$mode" = inference ]; then variants="separate joined cached"; fi
  for rows in 1 64; do
   for variant in $variants; do
    "$JAVA_HOME/bin/java" -Xmx1g -Xbatch -XX:CompileThresholdScaling=0.1 --enable-native-access=ALL-UNNAMED -cp /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/optimized.jar:/Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations ProjectionProbe "$backend" "$variant" "$mode" "$rows" > /Users/kirstenali/Documents/Codex/2026-11-01/users-kirstenali-ideaprojects-deepj/outputs/qwen-inference-optimizations/projection-$backend-$mode-$rows-$variant.json
   done
  done
 done
done
printf 'BALANCED_PROBES_DONE\n'
