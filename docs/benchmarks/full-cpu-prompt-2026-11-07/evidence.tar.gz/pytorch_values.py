"""Same reference forward/timing; restore one FP32 tensor at a time to bound peak memory."""
import json
import sys
from pathlib import Path
import torch
import transformers
from safetensors import safe_open
import qwen3_benchmark as reference

root, device, path = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
torch.set_num_threads(10)
torch.set_num_interop_threads(1)
config = reference.Qwen3Config.from_pretrained(root, local_files_only=True)
config._attn_implementation = 'sdpa'
with torch.device('meta'):
    model = reference.Qwen3ForCausalLM(config)
import struct
index = json.loads((root/'model.safetensors.index.json').read_text())['weight_map']
entries = {}
for name in sorted(set(index.values())):
    with (root/name).open('rb') as file:
        header_size = struct.unpack('<Q',file.read(8))[0]
        header = json.loads(file.read(header_size))
    for key,entry in header.items():
        if key != '__metadata__':entries[key] = (name,header_size+8,entry)
left = entries['model.embed_tokens.weight'];right = entries.get('lm_head.weight')
if right is not None:
    assert config.tie_word_embeddings
    assert left[2]['dtype']==right[2]['dtype'] and left[2]['shape']==right[2]['shape']
    size = left[2]['data_offsets'][1]-left[2]['data_offsets'][0]
    assert size == right[2]['data_offsets'][1]-right[2]['data_offsets'][0]
    with (root/left[0]).open('rb') as a,(root/right[0]).open('rb') as b:
        a.seek(left[1]+left[2]['data_offsets'][0]);b.seek(right[1]+right[2]['data_offsets'][0])
        for offset in range(0,size,1048576):
            count = min(1048576,size-offset)
            assert a.read(count)==b.read(count),'Tied checkpoint weights differ'
names = sorted(set(index.values()))
for name in names:
    with safe_open(root / name, framework='pt', device='cpu') as source:
        keys = [key for key in source.keys() if key != 'lm_head.weight']
    for key in keys:
        with safe_open(root / name, framework='pt', device='cpu') as source:
            value = source.get_tensor(key).to(device).to(dtype=torch.float32)
        model.load_state_dict({key: value}, strict=False, assign=True)
        del value
        if device == 'mps':
            torch.mps.synchronize()
            torch.mps.empty_cache()
model.tie_weights()
model.requires_grad_(False).eval()
model.model.rotary_emb = type(model.model.rotary_emb)(config=config, device=device)
assert all(p.dtype == torch.float32 and p.device.type == device for p in model.parameters())
assert model.lm_head.weight is model.model.embed_tokens.weight
print(json.dumps(dict(torch=torch.__version__, transformers=transformers.__version__,
    device=device, dtype='FLOAT32', threads=torch.get_num_threads(),
    interop=torch.get_num_interop_threads(), attention=config._attn_implementation,
    parameters=sum(p.numel() for p in model.parameters()),
    mps_allocated=torch.mps.current_allocated_memory() if device == 'mps' else 0,
    mps_driver=torch.mps.driver_allocated_memory() if device == 'mps' else 0)), flush=True)
import gc, subprocess, re

def counters():
    text = subprocess.check_output(['/usr/bin/vm_stat'], text=True)
    return {key:int(re.search(key+r':\s*(\d+)',text)[1]) for key in ['Swapins','Swapouts','Pageins','Decompressions']}

gc.collect()
data = json.loads(path.read_text())
for number in range(-8,5):
    before=counters()
    result=reference.trial(model,data,device,number)
    result.update(prefill_ms=result['prefill_seconds']*1000,logits=model.config.vocab_size,
                  vm_before=before,vm_after=counters())
    print(json.dumps(result),flush=True)
