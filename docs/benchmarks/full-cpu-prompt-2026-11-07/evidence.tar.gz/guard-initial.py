import json, os, re, signal, subprocess, sys, time, resource
from pathlib import Path

log = Path(sys.argv[1])
command = sys.argv[2:]
def swapouts():
    text = subprocess.check_output(['/usr/bin/vm_stat'], text=True)
    page = int(re.search(r'page size of (\d+) bytes', text)[1])
    return int(re.search(r'Swapouts:\s*(\d+)', text)[1]) * page / 1048576

start = time.monotonic()
initial = swapouts()
reason = None
with log.open('w') as stream:
    child = subprocess.Popen(['/usr/bin/time', '-l', *command], stdout=stream,
                             stderr=subprocess.STDOUT, start_new_session=True)
    while child.poll() is None:
        time.sleep(.5)
        if (log.parent/'STOP').exists(): reason = 'requested cancellation'
        elif time.monotonic()-start > 100: reason = 'time limit'
        elif swapouts()-initial > 512: reason = 'loading/warm-up swap growth cap'
        if reason:
            os.killpg(child.pid, signal.SIGTERM)
            try: child.wait(timeout=5)
            except subprocess.TimeoutExpired: os.killpg(child.pid, signal.SIGKILL)
            break
    code = child.wait()
data = [json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
trials = [item for item in data if item.get('trial', -1) >= 0]
clean = len(trials) == 5 and all(
    item['vm_after'][key] == item['vm_before'][key]
    for item in trials for key in ['Swapouts', 'Swapins'])
metrics = dict(returncode=code, elapsed_seconds=time.monotonic()-start,
               swap_before_mib=initial, swap_after_mib=swapouts(), stopped_for=reason,
               measured_trials=len(trials), measured_trials_swap_free=clean)
log.with_suffix('.metrics.json').write_text(json.dumps(metrics, indent=2)+'\n')
print(json.dumps(metrics), flush=True)
sys.exit(0 if code == 0 and clean else 1)
