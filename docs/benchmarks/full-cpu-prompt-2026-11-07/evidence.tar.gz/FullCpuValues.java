package io.github.kirstenali.deepj.nn.transformer.qwen3;

import io.github.kirstenali.deepj.concurrent.DeepJExecutor;
import io.github.kirstenali.deepj.persistence.qwen3.Qwen3Json;
import io.github.kirstenali.deepj.tensor.*;
import io.github.kirstenali.deepj.tensor.cpu.CpuBackend;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Pattern;

public final class FullCpuValues {
    public static void main(String[] args) throws Exception {
        Tensor.setBackend(new CpuBackend());
        DeepJExecutor.setNumThreads(10);
        emit(Map.of("phase", "loading"));
        Qwen3 model = Qwen3Pretrained.load(Path.of(args[0]), DType.FLOAT32);
        System.gc();
        emit(Map.of("phase", "loaded", "parameters", model.config().parameterCount(),
                "heap_used", Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()));
        var input = Qwen3Json.read(Path.of(args[1]));
        int[] prompt = Qwen3Json.array(input.get("prompt")).stream()
                .mapToInt(v -> Math.toIntExact(Qwen3Json.integer(v))).toArray();
        try {
            for (int run = -8; run < 5; run++) trial(model, prompt, run);
        } finally { DeepJExecutor.shutdown(); }
    }

    private static void trial(Qwen3 model, int[] prompt, int number) throws Exception {
        Map<String, Long> before = counters();
        try (var session = model.openGeneration()) {
            long start = System.nanoTime();
            float[] logits = session.apply(prompt).toFloatArray();
            double milliseconds = (System.nanoTime() - start) / 1e6;
            emit(Map.of("engine", "DeepJ", "trial", number, "prefill_ms", milliseconds,
                    "checksum", logits[0], "logits", logits.length,
                    "vm_before", before, "vm_after", counters()));
        }
    }

    private static Map<String, Long> counters() throws Exception {
        Process command = new ProcessBuilder("/usr/bin/vm_stat").start();
        String output = new String(command.getInputStream().readAllBytes());
        if (command.waitFor() != 0) throw new IllegalStateException("vm_stat failed");
        var result = new LinkedHashMap<String, Long>();
        for (String key : List.of("Swapins", "Swapouts", "Pageins", "Decompressions")) {
            var matcher = Pattern.compile(key + ":\\s*(\\d+)").matcher(output);
            if (!matcher.find()) throw new IllegalStateException("Missing VM counter: " + key);
            result.put(key, Long.parseLong(matcher.group(1)));
        }
        return result;
    }

    private static void emit(Map<String, ?> value) {
        System.out.println(Qwen3Json.stringify(value));
        System.out.flush();
    }
}
