import os, subprocess, sys
from pathlib import Path

p = Path(__file__).resolve().parent
root = p.parents[1]
model = '/Users/kirstenali/Documents/Codex/models/Qwen3-1.7B'
env = dict(os.environ, VECLIB_MAXIMUM_THREADS='10', TOKENIZERS_PARALLELISM='false',
           PYTHONPATH=str(root/'work/deepj-qwen-thinking/src/test/python'))
commands = [
    ['pytorch-tied-3.jsonl', str(root/'outputs/cpu-throughput/reference-env/bin/python'),
     '-B', 'pytorch_values.py', model, 'cpu', 'input.json'],
    ['deepj-serial-2.jsonl', '/Users/kirstenali/Library/Java/JavaVirtualMachines/temurin-20.0.2/Contents/Home/bin/java',
     '-Xmx9g', '-XX:+UseSerialGC', '-XX:NewRatio=8', '--enable-native-access=ALL-UNNAMED',
     '-cp', 'deepj.jar:classes', 'io.github.kirstenali.deepj.nn.transformer.qwen3.FullCpuValues',
     model, 'input.json']
]
for command in commands:
    subprocess.run([sys.executable, '-B', 'guard.py', *command], cwd=p, env=env, check=True)
print('REVERSE_PAIR_COMPLETE', flush=True)
